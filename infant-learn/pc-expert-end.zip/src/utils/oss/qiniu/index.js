/**
 * Created by QiHan Wang on 2017/9/12.
 * Qinniu
 */
import uploader from './uploader';
export default {
  uploader
}
