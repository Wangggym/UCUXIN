import download from './download';
import uploader from './uploader';

export default {
  download,
  uploader
}
