import Topic from './Topic'
export default Topic