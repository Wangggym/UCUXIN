import moment from 'moment'


const showTime = (time, format = 'YYYY-MM-DD HH:mm:ss', showTimeFormat = 'YYYY-MM-DD') => moment(time, format).format(showTimeFormat) || moment(time).format(showTimeFormat)

export default showTime
