/**
 * Created by QiHan Wang on 2017/8/12.
 */
import React from 'react';
import { AsyncComponent } from '../components';
import breadcrumbNameMap from './breadcrumb';
import NotFoundPage from '../views/other/NotFoundPage';

const MyHomepage = AsyncComponent(() => import('../views/expert/my-homepage'));
const MyCourse = AsyncComponent(() => import('../views/expert/my-course'));
const StartCourses = AsyncComponent(() => import('../views/expert/start-courses'));
const TrainingPlan = AsyncComponent(() => import('../views/expert/training-plan'))
const MessageManagement = AsyncComponent(() => import('../views/expert/message-management'));
const EditorTest = AsyncComponent(() => import('../views/resource/editor-test'));
const SourceVideo = AsyncComponent(() => import('../views/resource/source-video'));
const SourceFile = AsyncComponent(() => import('../views/resource/source-file'));
const PaperList = AsyncComponent(() => import('../views/resource/test-paper'));
const PaperDetail = AsyncComponent(() => import('../views/resource/test-paper/PaperDetail'));

const Exercises = AsyncComponent(() => import('../views/resource/exercises'));
const CreateQuestion = AsyncComponent(() => import('../views/resource/exercises/create-questions/CreateQuestion'));
const LearnManagement = AsyncComponent(() => import('../views/expert/my-course/LearnManagement/LearnManagement'));
const DiscussManagement = AsyncComponent(() => import('../views/expert/my-course/DiscussManagement/DiscussManagement'));

const CreateResource = AsyncComponent(() => import('../views/expert/organize-resource/createResource'));

const routers = [
  {
    path: '/',
    exact: true,
    // component: () => <div>资源组织平台</div>
    component: MyHomepage
  },
  // {
  //   path: '/my-homepage',
  //   component: MyHomepage,
  // },
  {
    path: '/my-course',
    component: MyCourse,
  },
  {
    path: '/learn-managemanet/:courseID',
    component: LearnManagement,
  }, {
    path: '/discuss-managemanet/:courseID',
    component: DiscussManagement,
  },
  {
    path: '/editor-test',
    component: EditorTest,
  },
  //培训计划(by xj)
  {
    path: '/training-plan',
    component: TrainingPlan,
  },
  //消息管理(by xj)
  {
    path: '/message-management',
    component: MessageManagement,
  },

  // ==================================

  {
    path: '/start-courses',
    component: StartCourses,
  },
  // 组织资源
  {
    path: '/organize-resource/:id',
    component: CreateResource,
  },
  {
    path: '/source-video',
    component: SourceVideo,
  },
  {
    path: '/source-file',
    component: SourceFile,
  },
  {
    path: '/my-paper-list',
    component: PaperList
  },
  {
    path: '/paper-detail',
    component: PaperDetail
  },
  {
    path: '/organize-resource',
    component: CreateResource,
  },
  {
    path: '/organize-resource/:id',
    component: CreateResource,
  },
  {
    path: '/404',
    component: NotFoundPage
  },
  // ==================================
  //选择试题

  {
    path: '/exercises',
    exact: true,
    component: Exercises
  },
  {
    path: '/exercises/create-question',
    component: CreateQuestion
  },

];
export default routers;
export { breadcrumbNameMap };
