/**
 * Created by QiHan Wang on 2017/8/15.
 * breadcrumb
 */
export default {
  '/': '我的主页',
  '/my-course': '我的课程',
  '/training-plan':'培训计划',
  '/message-management': '消息管理',
  '/start-courses': '开设课程',
  '/exercises': '试题',
  '/exercises/create-question': '新增试题',
  '/organize-resource':'创建专辑',
  '/404':'404',
  '/my-paper-list':'试卷',
  '/paper-detail':'试卷详情',
  '/source-video':'视频资源',
  '/source-file':'文件资源',
}
