/**
 *  Create by xj on 2017/12/11.
 *  fileName: index
 */
import React, {Component} from 'react';
import {Form, Button, Radio, Pagination, DatePicker, Spin, Input, message} from 'antd';
import './ItemBank.scss';
import Api from '../../../api';
import {Token} from "../../../utils";
import TestPaperList from './TestPaperList';
import moment from 'moment';

const FormItem = Form.Item;
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';
const token = Token();


class TestPaper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      testPaperList: [],//试卷列表
      PIndex: 1,//第几页
      PSize: 10,//返回多少条数
      name: "",//试卷名称
      st:"",
      et:"",
      loading: false
    }
  }

  componentDidMount() {
    this.getTestPaperList()
  }
//获取试卷列表
  getTestPaperList() {
    this.setState({loading:true});
    const {PIndex,PSize,name,st,et}=this.state;
    const getDataConfig = {
      token,
      pIndex:PIndex,
      pSize:PSize,
      name:name,
      st:st,
      et:et,
    };
    Api.Resource.GetYLSPapersByQuery(getDataConfig).then(res=>{
      if(res.Ret===0){
        this.setState({
          testPaperList:res.Data,
          loading:false
        })
      }else{
        message.warning(res.Msg);
        this.setState({loading:false})
      }
    })
  }
  //查询
  handleSearch = (e) => {
    e.preventDefault();
    this.setState({loading: true});
    this.state.PIndex = 1;
    this.props.form.validateFields((err, values) => {
      let st = values.SeartchSEDate && values.SeartchSEDate.length !== 0 && moment(values.SeartchSEDate[0]).format(dateFormat)||"";
      let et = values.SeartchSEDate && values.SeartchSEDate.length !== 0 && moment(values.SeartchSEDate[1]).format(dateFormat)||"";
      this.setState({
        name:values.ItemName||"",
        st:st,
        et:et
      },()=>this.getTestPaperList())
    });

  }
  //改变页码，获取试卷列表
  changePage(page) {
    this.setState({loading:true,PIndex: page},()=>this.getTestPaperList())
  }
  render() {
    const {getFieldDecorator} = this.props.form;
    const {testPaperList} = this.state;
    const {ViewModelList} = this.state.testPaperList;
    return (
      <Spin spinning={this.state.loading}>
        <Form layout="inline" className="form-search-group" onSubmit={this.handleSearch}>
          <FormItem style={{marginLeft: "2.2rem"}} label="试卷名称">
            {getFieldDecorator(`ItemName`)(
              <Input placeholder="请输入试卷名称"/>
            )}
          </FormItem>

          <FormItem label="查询起止时间">
            {getFieldDecorator(`SeartchSEDate`)(<RangePicker format={dateFormat}/>)}
          </FormItem>
          <FormItem>
            <Button type="primary" style={{marginLeft: 8}} htmlType="submit">查询</Button>
          </FormItem>

          <FormItem>
            <Button type="primary" onClick={() => this.props.history.push('/editor-test')} style={{marginLeft: 8}}>
              新增
            </Button>
          </FormItem>

          <div className="line-cute">
            {
              ViewModelList && ViewModelList.length ? ViewModelList.map((item, index) => {
                return (
                  <TestPaperList key={index} item={item}/>
                )
              }) : <NoData/>
            }

          </div>
          <Pagination
            showTotal={total => `共 ${total} 条`}
            total={testPaperList.TotalRecords}
            current={this.state.PIndex}
            pageSize={this.state.PSize}
            onChange={(pages) => this.changePage(pages)}
            showQuickJumper={testPaperList.Pages > 10}
            style={{marginTop:"1rem"}}
          />
        </Form>
      </Spin>
    )
  }
}

//无数据
class NoData extends Component {
  render() {
    return (
      <div className="no-data">
        暂无数据
      </div>
    )
  }
}

export default Form.create()(TestPaper);
