/**
 * create by xj 2017/8/19
 * */
import React, {Component} from 'react';
import QuestionsList from './QuestionsList';

class PartList extends Component{
  static defalutProps={

  }
  constructor(props){
    super(props)
    this.state={
      data:this.props.data
    }
  }
componentDidMount(){
  //console.log(this.state.data)
}

  render(){
  const{data} = this.state;

    return(
      <div>
        {
          data&&data.length&&data.map((item,index)=>{
            return(
              <div className="part-list" key={index}>
                <div className="part-list-title">{parseInt(item.Seq)+1}、{item.Name}</div>
                <div className="part-list-title">{data.Remark}</div>
                <div className="part-list-content">
                  {
                    <QuestionsList data={item.Questions} key={index} index={index}/>
                  }
                </div>
              </div>
            )
          })
        }

      </div>
    )
  }
}
export default PartList;
