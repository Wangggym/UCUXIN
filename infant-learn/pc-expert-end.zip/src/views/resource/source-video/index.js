/**
 *  Create by xj on 2017/11/29.
 *  fileName: index
 */
import React from 'react'
import FileVideoComponent from '../FileVideoComponent';

const SourceVideo = ()=>{
  return(
    <div className='source-file'>
      {/*资源类型(type) 1-文件 2-视频 4-试卷 5-试题*/}
      <FileVideoComponent type="2"/>
    </div>
  )
}
export default SourceVideo;
