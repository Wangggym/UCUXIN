/**
 *  Create by xj on 2017/11/30.
 *  fileName: FileVideoModalDetail
 */
import React,{Component} from 'react'
import {Modal,message,Table} from 'antd'

import {Plyr} from '../../components/index.js'
import {Token} from "../../utils";
import Api from '../../api';

const token = Token();

export default class FileVideoModalDetail extends Component {
  constructor(props){
    super(props);
    this.state={
      visible:false,
      modalData:{},
      videoPreviewUrl:''
    }
    this.columns = [
      {
        title: '引用的课程名称',
        dataIndex: 'CourseName',

      },
      {
        title: '课程类型',
        dataIndex: 'Type',

      },
      {
        title: '引用时间',
        dataIndex: 'CDate',

      },
    ]
  }

//查看
  searchDetail=()=>{
    let getDataConfig = {
      token,
      resourceID:this.props.resourceID
    }
    Api.Resource.GetMyResourceDetail({...getDataConfig}).then(res=>{
      if(res.Ret===0){
        //视频资源需要再根据resourceID获取播放地址，文件资源不需要
        if(this.props.type==="1"){
          this.setState({modalData:res.Data,visible:true})
        }else {
          this.setState({modalData:res.Data},()=>this.handlePreview(this.state.modalData.ResourceID))
        }
      }else{
        message.warning(res.Msg)
      }
    })
  };
  //视频播放
  handlePreview = (ResourceID) => {
    Api.Base.getVideoRes({resourceID: ResourceID}).then(res => {
      if (res.Ret === 0) {
        this.setState({videoPreviewUrl: res.Data.PlayUrl, visible: true});
      } else {
        message.error(res.Msg);
      }
    });
  }
  handleCancel=()=>{
    this.setState({visible:false})
  };
  render(){
    const {modalData} = this.state;
    return(
      <div className='FileVideoModalDetail' onClick={()=>this.searchDetail()}>
        {this.props.children}
        <Modal onOk={this.handleOk} onCancel={this.handleCancel} visible={this.state.visible} title='查看详情' width={800}
               footer={null}>
          {
            this.props.type==="2"&&<Plyr
              url={this.state.videoPreviewUrl}
              isClose={this.state.visible}
            />
          }
          <div className='source-intro'>
            <div className='file-icon'>
              <img src={modalData.Icon} alt=""/>
            </div>
            <div className='text-intro'>
              <p>{modalData.Name}</p>
              <p>资源大小 : {modalData.Size >= 1024 ? (modalData.Size / 1024).toFixed(2) + "M" : (modalData.Size) + "KB"}</p>
              <p>上传时间 : {modalData.CDate}</p>
            </div>
          </div>

          <span className='quote-time'>引用次数:{modalData.RefCount}</span>
          <Table rowKey="ID" bordered columns={this.columns}
            dataSource={this.state.modalData.CourseLists}
                 pagination={{defaultPageSize:3}}
          />

        </Modal>
      </div>
    )
  }
}
