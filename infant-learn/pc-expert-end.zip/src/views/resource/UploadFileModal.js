/**
 *  Create by xj on 2017/12/1.
 *  fileName: UploadVideoModal
 */
import React, {Component} from 'react'
import {Modal, Form, Input, Upload, Button, Icon, message} from 'antd'
import oss from '../../utils/oss/';

import {Token} from "../../utils";
import Api from '../../api';

const token = Token();
const FormItem = Form.Item;
const TextArea = Input.TextArea;
const videoFormat = ['webm', 'mp4', 'ogg', 'avi', 'rmvb', 'rm', 'asf', 'divx', 'mpg', 'mpeg', 'mpe', 'wmv', 'mkv', 'vob'];

class UploadFileModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      uploading: false
    }
  }

  //显示模态框
  showVideoModal = () => {
    this.setState({visible: true})
  };
  //取消模态框
  hideVideoModal = () => {
    this.setState({visible: false})
  };
  // 文件上传组件值更新时
  handleUploadChange = (info) => {
    let fileList = info.fileList;

    // 1. Limit the number of uploaded files
    //    Only to show two recent uploaded files, and old ones will be replaced by the new
    fileList = fileList.slice(-1);

    // 2. read from response and show file link
    fileList = fileList.map((file) => {
      if (file.response) {
        // Component will show file.url as link
        file.url = file.response.url;
      }
      return file;
    });

    // 3. filter successfully uploaded files according to response from server
    fileList = fileList.filter((file) => {
      if (file.response) {
        return file.response.res.status === 200;
      }
      return true;
    });
    this.setState({fileList});
  };

  // 文件组件自定义上传
  handleCustomRequest = (options) => oss.ali.uploader(options.file, 'k12', options);
  // 上传文件类型检测
  beforeUpload = (file) => {
    const isVideo = videoFormat.includes(file.name.slice(file.name.lastIndexOf('.') + 1).toLowerCase());
    if (isVideo) {
      message.error(`请选择非视频文件`);
    }
    const isLtSize = file.size / 1024 / 1024 < 50;
    if (!isLtSize) {
      message.error('上传文件最大不能超过50M！');
    }
    return !isVideo && isLtSize;
  };
  //上传文件
  handleUpload = () => {
    const {onOk, form, visible} = this.props;
    form.validateFields((err, values) => {
      const {catalog} = this.props;
      const file = this.state.fileList.slice(-1)[0];
      if (err) {
        message.error('请将表单填写完整！');
        return
      }
      this.setState({uploading: true});

      const body = {
        ID: 0,
        SuffixName: file.name.slice(file.name.lastIndexOf('.') + 1).toLowerCase(),
        Url: file.url,
        Length: file.size,
        Type: 1,
        Name: values.name,
        Desc: values.description,
        CourseCatalogID: '0',
      };

      Api.StartCourses.saveResourceFile({token, body}).then(res => {
        if (res.Ret === 0) {
          message.success('上传成功！');
          this.props.form.resetFields();
          this.setState({fileList: [],visible:false});
          this.props.getPageData();
        } else {
          message.error(res.Msg);
        }
        this.setState({uploading: false});
      })
    })
  };

  render() {
    const {uploading, fileList} = this.state;
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: {span: 24},
        sm: {span: 6},
      },
      wrapperCol: {
        xs: {span: 24},
        sm: {span: 14},
      },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        xs: {
          span: 24,
          offset: 0,
        },
        sm: {
          span: 14,
          offset: 6,
        },
      },
    };
    return (
      <div className='upload-file' onClick={() => this.showVideoModal()}>
        {this.props.children}
        <Modal width={600} title='上传文件' visible={this.state.visible} footer={null} onCancel={this.hideVideoModal}>
          <Form>
            <FormItem {...formItemLayout} label="文件名称" hasFeedback>
              {getFieldDecorator('name', {rules: [{required: true, message: '请填写文件名称！'}]})(
                <Input/>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="文件描述" hasFeedback>
              {getFieldDecorator('description', {rules: [{required: true, message: '请填写文件描述信息！'}]})(
                <TextArea/>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="上传文件" extra="请选择小于50M的非视频文件">
              {getFieldDecorator('file', {rules: [{required: true, message: '请上传文件！'}]})(
                <Upload
                  name='file'
                  onChange={this.handleUploadChange}
                  customRequest={this.handleCustomRequest}
                  beforeUpload={this.beforeUpload}
                  fileList={fileList}
                >
                  <Button><Icon type="upload"/> 点击上传</Button>
                </Upload>
              )}
            </FormItem>
            <FormItem {...tailFormItemLayout}>
              <Button type="primary"
                      onClick={this.handleUpload}
                      loading={uploading}
              >{uploading ? '上传中...' : '开始上传'}</Button>
            </FormItem>
          </Form>
        </Modal>
      </div>
    )
  }
}

export default Form.create()(UploadFileModal)
