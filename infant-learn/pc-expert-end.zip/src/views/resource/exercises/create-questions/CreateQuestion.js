/**
 * Created by QiHan Wang on 2017/8/14.
 * QeustionIntro
 */
import React, {Component} from 'react';
import Api from '../../../../api';
import {Token} from '../../../../utils';

import './create-question.scss';
// --
import CreateOption from './CreateOption';

// -- Ant Design Component
import {Form, Radio, Input, Button, Modal} from 'antd';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const TextArea = Input.TextArea;

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

const token = Token();

class CreateQuestion extends Component {
  constructor(props) {
    super(props);
    this.state = {}
  }

  componentDidMount() {
    this.getBasicData().then(res => this.setState({...res}));
  }

  getBasicData = async () => {
    const [questionType, difficulty] = await Promise.all([
      Api.Resource.getQuestionType(),
      Api.Resource.getDifficulty()
    ]);

    let result = {};
    // 问题类型数据处理
    if (questionType.Ret === 0) {
      if (questionType.Data && questionType.Data.length) {
        result.questionType = questionType.Data;
      }
    }

    // 问题难度数据处理
    if (difficulty.Ret === 0) {
      if (difficulty.Data && difficulty.Data.length) {
        result.difficulty = difficulty.Data;
      }
    }
    return result;
  };

  // 提交试题
  handleSubmit = () => {
    this.props.form.validateFields((err, values) => {

      if (err) {
        Modal.error({title: '错误提示！', content: '试题填写不完整！'});
      } else {

        // 构建选项数组
        const questionJson = values.answerOptions.map((item, i) => {
          return {
            ID: item.id,
            Section: alphabet[i],
            Name: item.value,
            Sort: i,
            IsAnswer: item.checked
          };
        });
        const questionData = {
          Name: values.questionDesc,
          Type: values.questionTypeSelected,
          Difficulty: values.difficulty,
          SolveThink: values.guide,
          Analysis: values.analysis,
          QuestionJson:JSON.stringify(questionJson),
        };

        Api.Resource.addQuestion({token,body: questionData}).then(res => {
          if (res.Ret === 0) {
            this.showConfirmSuccess();
          } else {
            this.showError(res.Msg);
          }
        });

        /*switch (+values.questionTypeSelected) {
          case 1:
          case 2:
            const choiceData = {
              Name: values.questionDesc,
              Type: values.questionTypeSelected,
              Difficulty: values.difficulty,
              SolveThink: values.guide,
              Analysis: values.analysis,
              Options: values.answerOptions.map((item, i) => {
                return {
                  ID: item.id,
                  Section: alphabet[i],
                  Name: item.value,
                  Sort: 4,
                  IsAnswer: item.checked
                };
              }),
            };
            Api.Resource.addChoiceQuestion({token, body: choiceData}).then(res => {
              if (res.Ret === 0) {
                this.showConfirmSuccess();
              } else {
                this.showError(res.Msg);
              }
            });
            break;
          case 3:
            const judgeData = {
              Name: values.questionDesc,
              Type: values.questionTypeSelected,
              Difficulty: values.difficulty,
              SolveThink: values.guide,
              Analysis: values.analysis,
              Options: values.answerOptions.map((item, i) => {
                return {
                  ID: item.id,
                  Section: alphabet[i],
                  Name: item.value,
                  Sort: 4,
                  IsAnswer: item.checked
                };
              }),
            };
            Api.Resource.addJudgeQuestion(token,{body: judgeData}).then(res => {
              if (res.Ret === 0) {
                this.showConfirmSuccess();
              } else {
                this.showError(res.Msg);
              }
            })
            break;
          default:
        }*/
      }
    })
  }

  showConfirmSuccess = () => {
    /*Modal.confirm({
      title: '试题添加成功！',
      content: '是否继续添加？',
      onOk: () => {
        this.props.form.resetFields(['questionDesc', 'answerOptions', 'guide', 'analysis']);
      },
      onCancel: () => {
        this.handleGoBack();
      },
    });*/

    Modal.success({
      title: '试题添加成功',
      okText:'确定',
      onOk: () => {
        this.handleGoBack();
      },
    });
  }

  showError = (content) => {
    Modal.error({title: '试题添加错误！', content});
  }

  // 返回到试题列表
  handleGoBack = () => {
    this.props.history.goBack();
  }

  render() {
    const {getFieldDecorator, getFieldsValue} = this.props.form;
    const {questionType, difficulty} = this.state;
    const {questionTypeSelected} = getFieldsValue();
    const extraAnswer = () => {
      switch (+questionTypeSelected) {
        case 1:
          return '单选题的选项个数范围 2 到 26 ，正确选项个数为 1';
        case 2:
          return '多选题的选项个数范围 3 到 26 ，正确选项个数不少于 2';
        case 3:
          return '判断题的答案个数固定为 2 个 ，正确答案个数为 1个';
        default:
          return ''
      }
    }
    const Tip = () => {
      switch (+questionTypeSelected) {
        case 1:
          return '请填写选项';
        case 2:
          return '请填写选项';
        case 3:
          return '请填写正确答案  正确：√/T  错误：×/';
        default:
          return ''
      }
    }
    const formItemLayout = {
      labelCol: {span: 4},
      wrapperCol: {span: 14},
    }
    const formItemLayoutWithOutLabel = {
      wrapperCol: {
        span: 14, offset: 4
      },
    };

    return (
      <div style={{width: '80%', maxWidth: 960, margin: '0 auto'}}>
        <Form layout="horizontal" className="create-question">
          <FormItem  {...formItemLayout} label="题型">
            {getFieldDecorator(`questionTypeSelected`, {
              initialValue: '1',
              rules: [{required: true}]
            })(
              <RadioGroup>
                {
                  questionType && questionType.map(item => <Radio value={item.Value}
                                                                  key={item.Value}>{item.Text}</Radio>)
                }
              </RadioGroup>
            )}
          </FormItem>

          <FormItem  {...formItemLayout} label="题干">
            {
              getFieldDecorator(`questionDesc`, {
                rules: [{
                  required: true,
                  message: '请填写题干信息'
                }]
              })(
                <TextArea rows="3" placeholder="请输入试题题干信息"/>
              )
            }
          </FormItem>

          <FormItem  {...formItemLayout} label="答案" extra={extraAnswer()}>
            {
              getFieldDecorator(`answerOptions`, {
                rules: [
                  {
                    required: true,
                    validateTrigger: ['onBlur', 'onChange'],
                    message: '请将选项填写完整',
                    validator: (rule, value, callback) => {

                      if (!value) {
                        callback(`选项未设置`);
                        return;
                      }

                      let num = 0;
                      for (let [index, answer] of value.entries()) {
                        if (!answer.value) {
                          callback(`第${index + 1}条选项，填写不完整！`);
                          return;
                        } else {
                          if (answer.checked) {
                            num++;
                          }
                        }
                      }

                      // 验证答案正确个数是否满足
                      switch (+questionTypeSelected) {
                        case 1:
                          if (num < 1) {
                            rule.message = `当前题型正确答案至少一个！`;
                            callback('正确答案至少一个');
                          }
                          break;
                        case 2:
                          if (num < 2) {
                            rule.message = `当前题型正确答案至少二个！`;
                            callback('正确答案至少二个');
                          }
                          break;
                        case 3:
                          if (num < 1) {
                            rule.message = `当前题型正确答案至少一个！`;
                            callback('正确答案至少一个');
                          }
                          break;
                        default:
                          callback();
                      }
                      callback();
                    }
                  }
                ]
              })(<CreateOption type={questionTypeSelected} tip={Tip()} aa='dsf'/>)
            }
          </FormItem>

          <FormItem {...formItemLayout} label="难度">
            {getFieldDecorator(`difficulty`, {
              initialValue: '3',
              rules: [{required: true}]
            })(
              <RadioGroup>
                {
                  difficulty && difficulty.map(item => <Radio value={item.Value} key={item.Value}>{item.Text}</Radio>)
                }
              </RadioGroup>
            )}
          </FormItem>

          <FormItem  {...formItemLayout} label="解题思路">
            {
              getFieldDecorator(`guide`)(
                <TextArea rows="3" placeholder="考生/学员做题时可查看该信息，达到提醒点拨的作用"/>
              )
            }
          </FormItem>
          <FormItem  {...formItemLayout} label="试题解析">
            {
              getFieldDecorator(`analysis`, {
                initialValue: ''
              })(
                <TextArea rows="3" placeholder="考生/学员提交作业后可查看该信息，达到巩固学习的目的"/>
              )
            }
          </FormItem>
          <FormItem {...formItemLayoutWithOutLabel}>
            <Button type="primary" onClick={this.handleSubmit}>确认</Button>
            <Button style={{marginLeft: 8}} onClick={this.handleGoBack}>取消</Button>
          </FormItem>
        </Form>
      </div>
    )
  }
}

export default Form.create()(CreateQuestion);
