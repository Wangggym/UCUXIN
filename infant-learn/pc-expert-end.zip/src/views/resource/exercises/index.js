/**
 * Created by xj on 2017/9/2.
 */
import React, {Component} from 'react';
import {Form, Button, Radio, Pagination, Spin, Input, message} from 'antd';
import {Link} from 'react-router-dom';
import Api from '../../../api';
import {Token} from "../../../utils";
import SelectSubjectList from './SelectSubjectList';
import SubjectList from './SubjectList';
import "./ItemBank.scss";

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const token = Token();


class SelectItem extends Component {
  constructor(props) {
    super(props)
    this.state = {
      data: {},
      pagination: {pageSize: 10, current: 1},
      name: "",//试卷名称
      loading: false
    }
  }

  componentDidMount() {
    this.setState({loading: true})
    //默认获取试题列表
    this.getPageData()
  }

  getPageData() {
    const {pageSize, current} = this.state.pagination;
    let data = {
      token,
      name: this.state.name||"",
      pIndex: current,
      pSize: pageSize
    }
    Api.EditorTest.GetMyQuestions(data).then(res => {
      if (res.Ret === 0) {
        // const pagination = {...this.state.pagination};
        // pagination.total = res.Data.TotalRecords;
        // pagination.current = res.Data.PageIndex;
        this.setState({
          data: res.Data,
          loading: false
        })
      }else {
        message.warn(res.Msg,this.setState({loading:false}))
      }
    })
  }

  //页码改变
  onChangePage(NowPages) {
    this.setState({
      pagination:Object.assign({},this.state.pagination,{
        current:NowPages
      }),
      loading:true
    },()=>this.getPageData())
  }
//查询
  handleSearch=(e)=>{
    this.setState({loading:true})
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      this.setState({
        name:values.ItemName,
          pagination:Object.assign({},this.state.pagination,{
            current:1
          })
      },()=>this.getPageData())
     })
  }
  render() {
    const formItemLayout = {
      labelCol: {span: 6},
      wrapperCol: {span: 18},
    };
    const {getFieldDecorator} = this.props.form;
    return (
      <Spin spinning={this.state.loading}>
        <div className="item-bank">
          <Form layout="inline" className="form-search-group" onSubmit={this.handleSearch}>
            <FormItem style={{marginLeft: "2.2rem"}} label="试题名称">
              {getFieldDecorator(`ItemName`)(
                <Input placeholder="请输入试题名称"/>
              )}

            </FormItem>
            <FormItem>
              <Button type="primary" style={{marginLeft: 8}} htmlType="submit">查询</Button>
            </FormItem>

            <FormItem>
              <Button type="primary" onClick={()=>this.props.history.push('/exercises/create-question')} style={{marginLeft: 8}}>
                新增
              </Button>
            </FormItem>


          </Form>
          {
            this.props.location.state ? <SelectSubjectList data={this.state.data}/> :
              <SubjectList data={this.state.data} order={(this.state.pagination.current -1) * this.state.pagination.pageSize}/>
          }
          <Pagination
            showTotal={total => `共 ${total} 条`}
            total={this.state.data.TotalRecords}
            current={this.state.pagination.current}
            pageSize={this.state.pagination.pageSize}
            onChange={(pages) => this.onChangePage(pages)}
            showQuickJumper={this.state.data.Pages > 10}
          />
          {/*<Pagination defaultCurrent={1} defaultPageSize={this.state.pagination.current} total={this.state.data.Pages}*/}
                      {/*onChange={(pages) => this.onChangePage(pages)} style={{marginTop: "0.5rem"}}/>*/}
        </div>
      </Spin>
    )
  }
}

export default Form.create()(SelectItem);
