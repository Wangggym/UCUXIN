/**
 *  Create by xj on 2017/11/29.
 *  fileName: index
 */
import React from 'react'
import FileVideoComponent from '../FileVideoComponent';

const SourceFile = ()=>{
  return(
    <div className='source-file'>
      {/*资源类型(type) 1-文件 2-视频 4-试卷 5-试题*/}
      <FileVideoComponent type="1"/>
    </div>
  )
}
export default SourceFile;
