/**
 *  Create by xj on 2017/12/1.
 *  fileName: UploadVideoModal
 */
import React,{Component} from 'react'
import {Modal,Form, Input,Upload,Button,Icon,message} from 'antd'
import oss from '../../utils/oss/';

import {Token} from "../../utils";
import Api from '../../api';

const token = Token();
const FormItem = Form.Item;
const TextArea = Input.TextArea;
const videoFormat = ['webm', 'mp4', 'ogg', 'avi', 'rmvb', 'rm', 'asf', 'divx', 'mpg', 'mpeg', 'mpe', 'wmv', 'mkv', 'vob'];

class UploadVideoModal extends Component{
  constructor(props){
    super(props);
    this.state={
      visible:false,
      uploading: false,
      fileList: [],
    }
  }
  //显示模态框
  showVideoModal=()=>{
    this.setState({visible:true})
  };
  //取消模态框
  hideVideoModal=()=>{
    this.setState({visible:false})
  };
  // 文件上传组件值更新时
  handleUploadChange = (info) => {
    let fileList = info.fileList;

    // 1. Limit the number of uploaded files
    //    Only to show two recent uploaded files, and old ones will be replaced by the new
    fileList = fileList.slice(-1);

    // 2. read from response and show file link
    fileList = fileList.map((file) => {
      if (file.response) {
        // Component will show file.url as link
        file.key = file.response.key;
        file.hash = file.response.hash;
        file.vid = file.response.vid;
      }
      return file;
    });
    // 3. filter successfully uploaded files according to response from server
    fileList = fileList.filter((file) => {
      if (file.response) {
        return file.response.res.status === 200;
      }
      return true;
    });
    this.setState({fileList});
  };
  // 文件组件自定义上传
  handleCustomRequest = (options) => oss.qiniu.uploader(options.file, 'k12', options);
  // 上传文件类型检测
  beforeUpload = (file) => {
    const isVideo = videoFormat.includes(file.name.slice(file.name.lastIndexOf('.') + 1).toLowerCase());
    if (!isVideo) {
      message.error(`请选择视频格为：*.${videoFormat.join(' *.')}的视频文件`);
    }
    const isLt2G = file.size / 1024 / 1024 / 1024 < 2;
    if (!isLt2G) {
      message.error('上传视频最大不能超过2G！');
    }
    return isVideo && isLt2G;
  };
  //开始上传
  handleUpload = () => {
    const {onOk, form, visible} = this.props;
    form.validateFields((err, values) => {
      const {catalog} = this.props;
      const file = this.state.fileList.slice(-1)[0];
      if (err) {
        message.error('请将表单填写完整！');
        return
      }
      this.setState({uploading: true});

      const body = {
        ID: 0,
        SuffixName: file.name.slice(file.name.lastIndexOf('.') + 1).toLowerCase(),
        Name: values.name,
        Desc: values.description,
        CourseCatalogID: "0",
        key: file.key,
        VideoID: file.vid
      };

      Api.StartCourses.saveResourceVideo({token, body}).then(res => {
        if (res.Ret === 0) {
          message.success('上传成功！');
          this.props.form.resetFields();
          this.setState({fileList:[],visible:false});
          this.props.getPageData();
        } else {
          message.error(res.Msg);
        }
        this.setState({uploading: false});
      })
    })
  };

  render(){
    const {uploading,fileList} =this.state;
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: {span: 24},
        sm: {span: 6},
      },
      wrapperCol: {
        xs: {span: 24},
        sm: {span: 14},
      },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        xs: {
          span: 24,
          offset: 0,
        },
        sm: {
          span: 14,
          offset: 6,
        },
      },
    };
    return(
      <div className='upload-file' onClick={()=>this.showVideoModal()}>
        {this.props.children}
        <Modal width={600} title='上传视频' visible={this.state.visible} footer={null} onCancel={this.hideVideoModal}>
          <Form>
            <FormItem {...formItemLayout} label="视频名称" hasFeedback>
              {getFieldDecorator('name', {rules: [{required: true, message: '请填写视频名称！'}]})(
                <Input/>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="视频描述" hasFeedback>
              {getFieldDecorator('description', {rules: [{required: true, message: '请填写视频描述信息！'}]})(
                <TextArea/>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="上传视频" extra={<span>建议上传格式为*.webm *.mp4 *.ogg的视频<br/>支持上传视频格有：*.{videoFormat.join(' *.')}</span>}>
              {getFieldDecorator('file', {rules: [{required: true, message: '请上传文件！'}]})(
                <Upload
                  name='file'
                  onChange={this.handleUploadChange}
                  customRequest={this.handleCustomRequest}
                  beforeUpload={this.beforeUpload}
                  fileList={fileList}
                >
                  <Button><Icon type="upload"/> 点击上传</Button>
                </Upload>
              )}
            </FormItem>
            <FormItem {...tailFormItemLayout}>
              <Button type="primary"
                      onClick={this.handleUpload}
                      loading={uploading}
              >{uploading ? '上传中...' : '开始上传'}</Button>
            </FormItem>
          </Form>
        </Modal>
      </div>
    )
  }
}

export default Form.create()(UploadVideoModal)
