/**
 *  Create by xj on 2017/11/29.
 *  fileName: index
 */
import React, {Component} from 'react'
import {Form, Input, Button, Select, DatePicker, Table, message, Icon} from 'antd';
import FileVideoModalDetail from './FileVideoModalDetail';
import UploadVideoModal from './UploadVideoModal';
import UploadFileModal from './UploadFileModal';
import {Token} from "../../utils";
import Api from '../../api';
import moment from 'moment';
import './FileVideoModal.scss'


const token = Token();
const FormItem = Form.Item;
const Option = Select.Option;
const {RangePicker} = DatePicker;
const dateFormat = 'YYYY-MM-DD';

class FileVideoComponent extends Component {
  constructor(props) {
    super(props)
    this.state = {
      loding: false,
      pagination: {pageSize: 10, current: 1},
      dataSource: {},
    };
    this.columns = [
      {
        title: '资源名称',
        dataIndex: 'Name',

      },
      {
        title: '资源大小',
        dataIndex: 'Size',

      },
      {
        title: '上传时间',
        dataIndex: 'CDate',

      },
      {
        title: '资源类型',
        dataIndex: 'ResourceTypeDesc',

      },
      {
        title: '引用次数',
        dataIndex: 'RefCount',

      },

      {
        title: '操作',
        dataIndex: 'operation',
        render: (text, record, index) => {
          return (
            <FileVideoModalDetail resourceID={record.ID} type={this.props.type}>
              <Button type='primary'>查看</Button>
            </FileVideoModalDetail>
          )
        }
      }
    ]
  }

  componentDidMount() {
    this.getPageData()
  }

//查询
  searchSource = () => {
    //const pager = {...this.state.pagination};
    this.state.pagination.current = 1;
    this.props.form.validateFields((err, values) => {
      let sDate = values.SeartchSEDate && values.SeartchSEDate.length !== 0 && moment(values.SeartchSEDate[0]).format(dateFormat);
      let eDate = values.SeartchSEDate && values.SeartchSEDate.length !== 0 && moment(values.SeartchSEDate[1]).format(dateFormat);
      this.getPageData(values.resourceName, sDate, eDate)
    })
  };
  //上传资源成功后重新获取数据并重置页码为第一页
  uploadSuccess=()=>{
    this.setState({
      pagination:Object.assign({},this.state.pagination,{current:1})
    },()=>this.getPageData())
  }
  //获取分页数据
  getPageData = (resourceName, sDate, eDate) => {
    const {pageSize, current} = this.state.pagination;
    let NewViewModelList = [];
    this.setState({loading: false});
    const sendData = {
      token,
      pIndex: current,
      pSize: pageSize,
      type: this.props.type,
      name: resourceName || "",
      sDate: sDate || "",
      eDate: eDate || "",
    }
    Api.Resource.GetMyResourceInfoByType({...sendData}).then(res => {
      if (res.Ret === 0) {
        const pagination = {...this.state.pagination};
        pagination.total = res.Data.TotalRecords;
        pagination.current = res.Data.PageIndex;
        //处理数据
        res.Data.ViewModelList.forEach((item, index) => {
          let obj = {
            Name: <div className='table-icon'>
              <img src={item.Icon} style={{background: item.Icon}}/>
              {/*<i style={{backgroundImage: `url(${item.Icon})`, backgroundSize: 'cover', display: 'inline-block',width:14,height:14} }/>*/}
              <span>{item.Name}</span>
            </div>,
            ResourceID: item.ResourceID,
            ID: item.ID,
            ResourceTypeDesc: item.ResourceTypeDesc,
            CDate: item.CDate,
            Size: item.Size >= 1024 ? (item.Size / 1024).toFixed(2) + "M" : (item.Size) + "KB",
            SuffixName: item.SuffixName,
            RefCount: item.RefCount
          }
          NewViewModelList.push(obj)
        })
        this.setState({
          dataSource: Object.assign({}, this.state.dataSource, {
            ViewModelList: NewViewModelList
          }),
          pagination,
          loading: false
        })
      } else {
        message.warning(res.Msg)
        this.setState({loading: false})
      }
    })
  };

//分页改变时触发
  onChangePage(pagination, filters, sorter) {
    const pager = {...this.state.pagination};
    pager.current = pagination.current;
    this.setState({pagination: pager, loading: true}, () => this.props.form.validateFields((err, values) => {
      let sDate = values.SeartchSEDate && values.SeartchSEDate.length !== 0 && moment(values.SeartchSEDate[0]).format(dateFormat);
      let eDate = values.SeartchSEDate && values.SeartchSEDate.length !== 0 && moment(values.SeartchSEDate[1]).format(dateFormat);
      this.getPageData(values.resourceName, sDate, eDate)
    }));
  }

  render() {
    const {getFieldDecorator} = this.props.form;
    const {type} = this.props
    return (
      <div className="file-video">
        <Form layout="inline" className="form-search-group resource-list">
          <FormItem label={'资源名称'}>
            {getFieldDecorator(`resourceName`)(
              <Input placeholder="请输入资源名称字查询"/>
            )}
          </FormItem>
          <FormItem label="查询起止时间">
            {getFieldDecorator(`SeartchSEDate`)(<RangePicker format={dateFormat}/>)}
          </FormItem>
          <FormItem>
            <Button type="primary" onClick={this.searchSource}>查询</Button>
          </FormItem>
          <FormItem>
            {
              type === '2' ?
                <UploadVideoModal getPageData={this.uploadSuccess}>
                  <Button type="primary" size='large'>
                    <Icon type="plus"/>添加视频资源
                  </Button>
                </UploadVideoModal>
                :
                <UploadFileModal getPageData={this.uploadSuccess}>
                  <Button type="primary" size='large'>
                    <Icon type="plus"/>添加文件资源
                  </Button>
                </UploadFileModal>
            }

          </FormItem>
          <Table rowKey="ResourceID" bordered columns={this.columns}
                 style={{marginTop: "0.5rem"}}
                 loading={this.state.loading}
                 pagination={this.state.pagination}
                 dataSource={this.state.dataSource.ViewModelList}
                 onChange={(pagination, filters, sorter) => {
                   this.onChangePage(pagination, filters, sorter)
                 }}
          />
        </Form>
      </div>
    )
  }
}

export default Form.create()(FileVideoComponent);
