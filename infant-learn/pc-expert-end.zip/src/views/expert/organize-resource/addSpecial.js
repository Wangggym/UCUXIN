/**
 * Created by 王彬 on 2017/9/28.
 * 新增专辑
 */

import React, {Component} from 'react';
import {StorageService, Token, AppToken} from '../../../utils';
import Config from '../../../config';
import moment from 'moment';
import Api from '../../../api';
import './../start-courses/course-content.scss';
import './index.scss';


// -- Ant Design
import {Modal, Button, message, Icon, Input, Tabs, Table, Tooltip} from 'antd';

const TabPane = Tabs.TabPane;
let token, selectVideoResource, selectFileResource, totalVideo, totalFile;
const fileType = [
  {
    suffix: ['webm', 'mp4', 'ogg', 'avi', 'rmvb', 'rm', 'asf', 'mov', 'mpeg', 'mpe', 'wmv', 'mkv'],
    icon: 'video'
  },
  {
    suffix: ['pdf'],
    icon: 'pdf'
  },
  {
    suffix: ['doc', 'docx'],
    icon: 'doc'
  },
  {
    suffix: ['xls', 'xlsx'],
    icon: 'xls'
  },
  {
    suffix: ['ppt', 'pptx'],
    icon: 'ppt'
  },
  {
    suffix: ['jpg', 'jpeg', 'gif', 'bmp', 'png'],
    icon: 'pic'
  },
  {
    suffix: ['mp3', 'ogg', 'wav', 'ape', 'cda', 'au', 'midi', 'mac', 'aac', 'aif'],
    icon: 'music'
  },
  {
    suffix: ['rar', 'zip', '7-zip', 'ace', 'arj', 'bz2', 'cab', 'gzip', 'iso', 'jar', 'lzh', 'tar', 'uue', 'xz', 'z'],
    icon: 'rar'
  }
];

class AddSpecial extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      pagination: {
        current: 1,
        total: null,
        pageSize: 5,
        onChange: (page) => this.pageChange(1, page),
      },
      pagination1: {
        current: 1,
        total: null,
        pageSize: 5,
        onChange: (page) => this.pageChange(2, page),
      },
      activeKey: '1',
      videoList: [],
      fileList: [],
      loading: undefined,
      selectedRowKeys: [],
      selectedRowKeys1: [],
      selectSource:[],
    };
  }

  componentWillMount() {
    token = Token();
    selectVideoResource = [];
    selectFileResource = [];
    totalVideo = [];
    totalFile = [];
  }

  componentDidMount() {
    this.getVideoList();
    this.getFileSource();
    setTimeout(()=>{
      this.getCourseInfo();
    },1000)
  }

  // 选择页码
  pageChange(type, page) {
    let {pagination, pagination1} = this.state;
    if (type == 1) {
      this.setState({
        pagination: Object.assign(pagination, {current: page})
      }, () => {
        this.getVideoList();
      });
    } else {
      this.setState({
        pagination: Object.assign(pagination1, {current: page})
      }, () => {
        this.getFileSource();
      });
    }
  }

  // 关闭模态框
  handleCancel() {
    this.setState({
      visible: false,
    });
  }

  // 获取视屏资源
  getVideoList() {
    let {pagination,selectedRowKeys} = this.state;
    this.setState({
      loading: true
    });
    Api.StartCourses.getMyResource({
      token,
      type: 2,
      pIndex: pagination.current,
      pSize: pagination.pageSize
    }).then(res => {
      this.setState({
        loading: false
      });
      if (res.Ret === 0) {
        totalVideo = totalVideo.concat(res.Data.ViewModelList);
        this.setState({
          videoList: res.Data.ViewModelList,
          pagination: Object.assign(pagination, {total: res.Data.TotalRecords})
        });
      }
    });
  }
  // 获取课程详情
  getCourseInfo(){
    const resource = this.props.resource;
    Api.StartCourses.getCourse({
      token,
      courseID:resource.specialId
    }).then(res => {
      if (res.Ret === 0) {
        let {selectSource,videoList,fileList,selectedRowKeys,selectedRowKeys1} = this.state;
        let hasSelect = [],arr1 = [],arr2 = [];
        hasSelect = res.Data.CourseCatalogs[0].CourseResourceDetails;
        hasSelect.map((item,e)=>{
          if(item.ResourceType === 2){
            arr1.push(item);
          }else {
            arr2.push(item);
          }
        });
        arr1.map((item,e)=>{
          videoList.map((elet,i)=>{
            if(item.ResourceID == elet.ResourceID){
              selectedRowKeys.push(elet.ResourceID);
              selectVideoResource.push(elet);
            }
          })
        });
        arr2.map((item,e)=>{
          fileList.map((elet,i)=>{
            if(item.ResourceID == elet.ResourceID){
              selectedRowKeys1.push(elet.ResourceID);
              selectFileResource.push(elet);
            }
          })
        });
        selectSource  = selectVideoResource.concat(selectFileResource);
        // let seletListInfo = JSON.parse(sessionStorage.getItem(this.props.resource.specialId+'selectSource'));
        // if(seletListInfo){
        //   selectSource = selectSource.concat(seletListInfo);
        // }
        this.setState({
          selectSource:selectSource,
          selectedRowKeys:selectedRowKeys,
          selectedRowKeys1:selectedRowKeys1,
        })
      }
    })
  }
  // 获取文件资源
  getFileSource = () => {
    let {pagination1} = this.state;
    Api.StartCourses.getMyResource({
      token,
      type: 1,
      pIndex: pagination1.current,
      pSize: pagination1.pageSize
    }).then(res => {
      if (res.Ret === 0) {
        totalFile = totalFile.concat(res.Data.ViewModelList);
        this.setState({
          fileList: res.Data.ViewModelList,
          pagination1: Object.assign(pagination1, {total: res.Data.TotalRecords})
        })
      }
    });
  };

  //  用户选择资源
  handleTableChange(type, selectedRowKeys, selectedRows) {
    if (type == 1) {
      let data = [];
      selectedRowKeys.map((item, e) => {
        totalVideo.map((elet, i) => {
          if (elet.ResourceID == item) {
            data.push(elet);
          }
        })
      });
      selectVideoResource = data;
      this.setState({
        selectedRowKeys: selectedRowKeys
      })
    } else {
      let data = [];
      selectedRowKeys.map((item, e) => {
        totalFile.map((elet, i) => {
          if (elet.ResourceID == item) {
            data.push(elet);
          }
        })
      });
      selectFileResource = data;
      this.setState({
        selectedRowKeys1: selectedRowKeys
      })
    }
  }

  // 确定选择
  handleOk = () => {
    let {selectSource} = this.state;
    selectSource = [];
    selectSource = selectSource.concat(selectVideoResource, selectFileResource);
    this.setState({
      selectSource: selectSource,
      visible: false,
    },()=>{
      this.addResuorce();
    });
  };
  // 删除选择
  delet = (obj, index) => {
    let {selectSource, selectedRowKeys, selectedRowKeys1} = this.state;
    if(obj.ResourceType === 1){
      selectedRowKeys1.map((item, e) => {
        if (item == obj.ResourceID) {
          selectedRowKeys1.splice(e, 1);
        }
      });
      selectFileResource.map((item, e) => {
        if (item.ResourceID == obj.ResourceID) {
          selectFileResource.splice(e,1);
        }
      });
    }else {
      selectedRowKeys.map((item, e) => {
        if (item == obj.ResourceID) {
          selectedRowKeys.splice(e,1);
        }
      });
      selectVideoResource.map((item, e) => {
        if (item.ResourceID == obj.ResourceID) {
          selectVideoResource.splice(e,1);
        }
      });
    }
    console.log(selectFileResource);
    console.log(selectVideoResource);
    selectSource.splice(index, 1);
    this.setState({
      selectedRowKeys: selectedRowKeys,
      selectedRowKeys1: selectedRowKeys1,
      selectSource: selectSource
    },()=>{
      this.upDateCourse(2);
    });
  };
  // 返回上一步
  goPre(){
    const resource = this.props.resource;
    this.props.history.push('/organize-resource/'+resource.specialId);
    this.props.setCurent();
  }
  // 完成添加资源
  addResuorce() {
    let {selectSource} = this.state;
    let list = [];
    if(selectSource.length===0){
      message.error('请选择资源！',0.9);
      return;
    }
    this.upDateCourse();
    return;
    const resource = this.props.resource;
    selectSource.map((item, e) => {
      let obj = {
        ID: 0,
        CourseCatalogID: resource.catalogId,
        ResourceID: item.ID,
      };
      list.push(obj);
    });
    Api.StartCourses.saveCatalogResource({
      token,
      body: {
        CourseID: resource.specialId,
        CourseCatalogID: resource.catalogId,
        CatalogResourceList: list
      }
    }).then(res => {
      if (res.Ret == 0) {
        message.success('添加成功！');
      }
    })
  }
  // 改变发布状态
  publishCourse(){
    const resource = this.props.resource;
    Api.StartCourses.updateCourseStatus({
      token,
      courseID:resource.specialId,
    }).then(res =>{
      if(res.Ret == 0){
        this.props.history.push({pathname: '/my-course', state: '3'});
      }else {
        alert(res.Msg);
      }
    })
  }
  // 编辑更新
  upDateCourse(type){
    const resource = this.props.resource;
    let {selectSource} = this.state;
    let list = [];
    selectSource.map((item,e) => {
      list.push(item.ID);
    });
    Api.StartCourses.updateCourseAlbum({
      token,
      body: {
        CourseID: resource.specialId,
        IDs: list
      }
    }).then(res => {
      if (res.Ret == 0) {
        if(type===2){
          message.success('删除成功！');
        }else {
          message.success('添加成功！');
        }
      }
    })
  }
  render() {
    const {visible, activeKey, videoList, selectedRowKeys, selectedRowKeys1, selectSource, fileList, loading, pagination, pagination1} = this.state;
    const resource = this.props.resource;
    const columns = [
      {
        title: '名称',
        dataIndex: 'Name',
        width: '50%'
      },
      {
        title: '大小',
        dataIndex: 'Size',
        width: '25%',
        render: text => `${(+text / 1024 / 1024).toFixed(2)}M`
      },
      {
        title: '时长',
        dataIndex: 'Duration',
        width: '25%',
        render: text => {
          let h = Number.parseInt(text / 3600).toString();
          if (h < 10) h = h.padStart(2, '0');
          let m = Number.parseInt((text % 3600) / 60).toString().padStart(2, '0');
          let s = ((text % 3600) % 60).toString().padStart(2, '0');
          return [h, m, s].join(':');
        }
      }
    ];
    const columns1 = [
      {
        title: '名称',
        dataIndex: 'Name',
        width: '40%'
      },
      {
        title: '大小',
        dataIndex: 'Size',
        width: '30%',
        render: text => `${(+text / Math.pow(1024, 2)).toFixed(2)}M`
      },
      {
        title: '类型',
        dataIndex: 'SuffixName',
        width: '30%',
      }
    ];
    let rowSelection = {
      selectedRowKeys:selectedRowKeys,
      onChange: (val, selectedRows) => this.handleTableChange(1, val, selectedRows),
    };
    let rowSelection1 = {
      selectedRowKeys: selectedRowKeys1,
      onChange: (val, selectedRows) => this.handleTableChange(2, val, selectedRows),
    };
    return (
      <div className="add-special">
        <div className="add-special-contain">
          <Modal
            title={<div>添加资源</div>}
            width={680}
            visible={visible}
            onCancel={() => this.handleCancel()}
            maskClosable={false}
            footer={null}
          >
            <Tabs activeKey={activeKey} onChange={(val) => {
              this.setState({activeKey: val})
            }}>
              <TabPane tab={<span><Icon type="video-camera" style={{marginRight: 8}}/>视频</span>} key='1'>
                {
                  <Table
                    rowKey="ResourceID"
                    locale={{
                      emptyText: <span><Icon type="frown-o"/>暂时没有可用视频哦~！</span>
                    }}
                    columns={columns}
                    rowSelection={rowSelection}
                    dataSource={videoList}
                    pagination={pagination}
                    loading={loading}
                    size="small"/>
                }
              </TabPane>
              <TabPane tab={<span><Icon type="appstore-o" style={{marginRight: 8}}/>文件</span>} key='2'>
                <Table
                  locale={{
                    emptyText: <span><Icon type="frown-o"/>暂时没有可用文件哦~！</span>
                  }}
                  rowKey="ResourceID"
                  columns={columns1}
                  rowSelection={rowSelection1}
                  dataSource={fileList}
                  pagination={pagination1}
                  loading={loading}
                  size="small"/>
              </TabPane>
            </Tabs>
            <div style={{textAlign: 'center'}}>
              {videoList && videoList.length ? <Button type="primary" onClick={this.handleOk}>确定</Button> : null}
            </div>
          </Modal>
          <div className="add-special-content">
            <div className="source-info">
              <img src={resource.imageUrl} alt=""/>
              <span>{resource.name}</span>
              <Button onClick={() => this.setState({visible: true})}>添加资源<Icon type="plus-circle-o"/></Button>
            </div>
            {
              selectSource.length > 0 ? <Resource data={selectSource} delet={this.delet}/> : ''
            }
            <Button style={{marginRight:'65px'}} onClick={() => this.goPre()} className="sure-btn" type="primary"
                    size="large">上一步</Button>
            <Button onClick={()=>this.publishCourse()}  className="sure-btn" type="primary"
                    size="large">确定</Button>
            {/*onClick={() => this.addResuorce()}*/}
          </div>
        </div>
      </div>
    )
  }
}


class Resource extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  // 资源基本信息，不同资源显示不同信息
  renderResourceInfo = (data) => {
    switch (data.ResourceType) {
      case 1:
        return <div className="course-list-desc">
          <span>大小：{(data.Size / 1024 / 1024).toFixed(2)}M</span><span style={{paddingLeft:'15px'}}>类型：{data.SuffixName}</span></div>;
      case 2:
        return (
          <div className="course-list-desc">
            {
              <span>大小：{(data.Size / 1024 / 1024).toFixed(2)}M</span>
            }
            {
              data.Duration && <span style={{paddingLeft:'15px'}}>时长：{this.formatTimeLong(data.Duration)}</span>
            }
          </div>
        );
      case 3:
        return (
          <div className="course-list-desc">
            {
              data.SDate && <span>日期：{data.SDate.split(' ')[0]}</span>
            }
            {
              (data.SDate && data.EDate) &&
              <span>时间：{`${moment(data.SDate).format('HH:mm')}~${moment(data.EDate).format('HH:mm')}`}</span>
            }
          </div>
        );
      case 4:
        return (
          <div className="course-list-desc">
            {
              data.Count && <span>题数：共{data.Count}道试题</span>
            }
          </div>
        );
      case 6:
        return (
          <div className="course-list-desc">
            {
              data.SDate && <span>日期：{data.SDate.split(' ')[0]}</span>
            }
            {
              (data.SDate && data.EDate) &&
              <span>时间：{`${moment(data.SDate).format('HH:mm')}~${moment(data.EDate).format('HH:mm')}`}</span>
            }
            {
              data.Addr &&
              <Tooltip title={data.Addr}>地址：详细</Tooltip>
            }
          </div>
        )
    }
  };

  // 格式化视频时间
  formatTimeLong = (text) => {
    let h = Number.parseInt(text / 3600).toString();
    if (h < 10) h = h.padStart(2, '0');
    let m = Number.parseInt((text % 3600) / 60).toString().padStart(2, '0');
    let s = ((text % 3600) % 60).toString().padStart(2, '0');
    return [h, m, s].join(':');
  };

  // 资源类型
  renderResourceTypeIcon = (type, suffix) => {
    switch (type) {
      case 1:
        //return <span><Icon type="paper-clip" style={{marginRight: 5}}/>文件</span>;
        //return <span><i style={{backgroundImage:'url("http://lapp.test.ucuxin.com/test/svg/1.svg")', width: 14, height:14, display:'inline-block',verticalAlign:'text-bottom',marginRight:8}} />文件</span>;

        for (let i = 0; i < fileType.length; i++) {
          if (fileType[i].suffix.includes(suffix)) {
            return <Tooltip title="文件" placement="left"><i
              className={`rs-icon rs-icon-${fileType[i].icon}`}/></Tooltip>;
          }
        }
        return <Tooltip title="文件" placement="left"><i className="rs-icon rs-icon-file"/></Tooltip>;
      case 2:
        //return <span className="rs-type"><Icon type="video-camera" style={{marginRight: 5}}/>视频</span>;
        return <Tooltip title="视频" placement="left"><i className="rs-icon rs-icon-video"/></Tooltip>;
      case 3:
        //return <span className="rs-type"><Icon type="laptop" style={{marginRight: 5}}/>直播</span>;
        return <Tooltip title="直播" placement="left"><i className="rs-icon rs-icon-camera"/></Tooltip>;
      case 4:
        //return <Tooltip title="试卷"><Icon type="file-text" style={{fontSize: 28}}/></Tooltip>;
        return <Tooltip title="试卷" placement="left"><i className="rs-icon rs-icon-file-text"/></Tooltip>;

      case 6:
        //return <span className="rs-type"><Icon type="schedule" style={{marginRight: 5}}/>面授</span>;
        return <Tooltip title="面授" placement="left"><i className="rs-icon rs-icon-teach"/></Tooltip>;
      default:
        //return <span className="rs-type"><Icon type="file" style={{marginRight: 5}}/>其它</span>;
        return <Tooltip title="其它" placement="left"><i className="rs-icon rs-icon-file"/></Tooltip>;
    }
  };
  // 删除资源
  // deletResource(item){
  //   if(item.ID){
  //
  //   }
  //   Api.StartCourses.delCatalogCourse({
  //     token,
  //     courseResourceID:item.ID,
  //     body: {
  //
  //     }
  //   }).then(res => {
  //     if (res.Ret == 0) {
  //       message.success('删除成功！');
  //     }
  //   })
  // }
  render() {
    let {data, delet} = this.props;
    return (
      <div className="course-catalog course-list bordered">
        {
          data.map((item, e) =>
            <div className="course-list-item" key={e}>
              <div className="course-list-hd">{this.renderResourceTypeIcon(item.ResourceType, item.SuffixName)}</div>
              <div className="course-list-bd">{item.Name}</div>
              <div className="course-list-ft">
                {this.renderResourceInfo(item)}
              </div>
              <div className="course-list-opr">
                {/*{
              data.ResourceType !== 3 && <span><a onClick={this.handlePreviewResource}>预览</a><span className="ant-divider"/></span>
            }*/}
                {/*<a>查看</a>*/}
                <a onClick={() => delet(item, e)}>删除</a>
              </div>
            </div>
          )
        }
      </div>
    )
  }
}

export default AddSpecial;
