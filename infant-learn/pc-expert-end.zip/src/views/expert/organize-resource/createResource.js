/**
 * Created by wangbin on 2017/9/26.
 * 创建资源信息
 */

import React, {Component} from 'react';
import moment from 'moment';
import {StorageService, Token, AppToken} from '../../../utils';
import Config from '../../../config';
import Api from '../../../api';
import './index.scss';
import AddSpecial from './addSpecial';

// -- Ant Design
import { Steps, Button, message,Form,Input,DatePicker,Icon,Radio,Upload,InputNumber} from 'antd';
const Step = Steps.Step;
const FormItem = Form.Item;
const TextArea = Input.TextArea;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;
let token;
class CreatResourceForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      imageUrl:undefined,
      name:undefined,
      intro:undefined,
      startDate:null,
      endDate:null,
      priceType:undefined,
      credit:undefined,
      price:undefined,
      desPeopleList:undefined,
      userInfo:undefined,
      catalogId:undefined,
      specialId:this.props.match.params.id||undefined,
      current:0,

    };
  }
  componentWillMount() {
    token=Token();
  }
  componentDidMount(){
    this.getUserList();
    this.getUserinfo();
    if(this.props.match.params.id){
      this.getCoureInfo();
      // if(sessionStorage.getItem('current') == 1){
      //   this.setState({
      //     current:1
      //   })
      // }
    }
  }
  // 获取专辑详细信息
  getCoureInfo(){
    let {specialId} = this.state;
    Api.StartCourses.getCourseBaseInfo({token,courseID:specialId}).then(res =>{
      if(res.Ret === 0){
        this.setState({
          name:res.Data.Name,
          imageUrl:res.Data.CoverImg,
          intro:res.Data.Instro,
          startDate:moment(res.Data.SDate),
          endDate:moment(res.Data.EDate),
          priceType:res.Data.Price?2:1,
          price:res.Data.Price,
          credit:res.Data.Credit,
        })
      }
    })
  }
  // 講師基本信息
  getUserinfo(){
    Api.StartCourses.getLecturerInfo({token}).then(res=>{
          if(res.Ret === 0){
            this.setState({
              userInfo:res.Data
            });
          }
      })
  }
  // 获取适用对象
  getUserList(){
    Api.StartCourses.getCrowd({token, mTypeID: 11, phase: 30010, isGetManager: false}).then(res => {
      if (res.Ret === 0) {
        this.setState({
          desPeopleList:res.Data
        });
      }
    })
  }
  // 获取时间
  setTime(values){
    this.setState({
      startDate:values[0],
      endDate:values[1],
    });
  }
  //moment(values[0]).format('YYYY-MM-DD')
// 封面上传前验证
  beforeUpload = (file) => {
    const mimeType = ['image/gif', 'image/png', 'image/jpeg', 'image/bmp', 'image/webp'];
    const isJPG = mimeType.includes(file.type);
    if (!isJPG) {
      message.error('您只能上传图片类型为jpg、png、bmp、webp、gif的图片');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('图片大小必须小于2M！');
    }
    return isJPG && isLt2M;
  };

  // 自定义封面上传
  handleCustomRequest = (options, callback) => {
    // 获取应用Token
    AppToken().then(res => {
      if (typeof res === 'string') {
        callback(options.file, res);
      } else {
        let token = res.Data.Token;
        StorageService('session').set('AppToken', token);
        Config.setToken({name: 'appToken', value: token});
        callback(options.file, token);
      }
    })
  };

// 上传封面
  handleUploadHeadPic = (file, token) => {
    const fd = new FormData();
    fd.append('filename', file);
    const attachmentStr = '{"Path": "youls","AttachType": 1, "ExtName": ".jpg","ResizeMode": 1,"SImgResizeMode": 2, "CreateThumb": true, "Width": 100, "Height": 100,"SHeight": 50,"SWidth": 50 }';
    this.setState({uploadPicLoading: true});
    Api.Base.upload({
      token,
      attachmentStr,
      body: fd
    }).then(res => {
      if (res.Ret === 0) {
        message.success('上传成功！');
        this.setState({
          imageUrl:res.Data.ThumbUrl
        })
      } else {
        message.error('上传失败！');
      }
    })
  };
// 数据完整性验证
   confirm(){
     let {imageUrl,name,intro,startDate,endDate,price,priceType,credit} = this.state;
     let parnt;
     if(!name||name ===''){
       message.error('请填写专辑名称！');
       return;
     }
     if(!imageUrl||imageUrl ===''){
       message.error('请上传图片！');
       return;
     }
     if(!intro||intro===''){
       message.error('请填写专辑简介！');
       return;
     }
     if(!startDate||!endDate){
       message.error('请选择学习有效日期！');
       return;
     }
     if(!priceType){
       message.error('请选择收费类型！');
       return;
     }
     if(priceType===2&&!price){
       message.error('请填写课程费用！');
       return;
     }
     // parnt = /^[1-9]\d*(\.\d+)?$/;
     // if(priceType===2&&!parnt.exec(price)){
     //   message.error('请填写大于0的课程费用！');
     //   return ;
     // }
     this.addSpecial();
   };
// 新增专辑
 addSpecial() {
   let {imageUrl,name,intro,startDate,endDate,price,desPeopleList,userInfo,credit} = this.state;
   let object =  {
     ID:this.props.match.params.id?this.props.match.params.id:0,
     Name:name,
     TeachWay: 1,
     IsExam: false,
     CoverImg:imageUrl,
     Instro: intro,
     Credit: credit?credit:0,
     DestPeople: desPeopleList,
     SDate: moment(startDate).format('YYYY-MM-DD'),
     EDate: moment(endDate).format('YYYY-MM-DD'),
     LecturerID: userInfo.ID,
     LecturerName: userInfo.Name,
     LecturerInstro: userInfo.LecturerLevelDesc,
     TrainPlanID:0, // 培训计划编号 0-为自主课程 非0-关联的培训计划(国培)
     QtyLimit: 0,   // 参培人数限定 当为国培时只能修改为小于最初值
     CourseType:4,  // 课程类型 1-培训课程(国培) 2-专家讲座 3-名师课程
     // 非国培才有后面两字段
     Price: price?price:0,
     YoungCoin: 0,
     IsSortLearn: false,
   };
   Api.StartCourses.saveCourseInfo({token,body:object}).then(res => {
     if (res.Ret === 0) {
       this.setState({
         specialId:res.Data,
       });
       if(!this.props.match.params.id){
         this.addCatalog(name,res.Data);
       }else {
         this.props.history.push('/organize-resource/'+res.Data);
         this.setState({
           current:1,
         })
       }
     }else{
       message.error(res.Msg);
     }
   });
 };
 // 新增目录
  addCatalog(name,courseId){
    let object1;
    object1 = {
      ID:0,
      CourseID:courseId,
      Name:name,
      PID:0,
      Level:1,
      Sort:1,
      edit:true,
    };
    Api.StartCourses.saveCourseCatalog({token,body:object1}).then(res => {
      if (res.Ret === 0) {
        this.setState({
          catalogId:res.Data,
          current:1,
        })
      }
    })
  };
  //
  setCurrent(){
    this.setState({
      current:0
    })
  }
  //限制学习有效日期
  disabledRangeDate = (current) => {
    return current && current.valueOf() < Date.now()-24*60*60*1000;
  };


  render() {
    const {price,name,imageUrl,priceType,current,credit,intro,startDate,endDate,id} = this.state;
    return (
      <div className="creat-resource">
          <div className="creat-resource-contain">
            <div className="header-content">
              <div className="header">
                <Steps current={current}>
                  <Step title="创建资源信息" />
                  <Step title="添加资源" />
                </Steps>
              </div>
            </div>
            {
              current==0?<div>
                <div className="form-content">
                  <Form
                    layout="horizontal"
                  >
                    <FormItem
                      label="资源专辑名称"
                      labelCol={{ span: 6 }}
                      wrapperCol={{ span: 18}}
                      hasFeedback
                      required={true}
                    >
                      <Input value={name} onChange={(value)=>{this.setState({name:value.target.value});}}  placeholder="请输入资源专辑名称" />
                    </FormItem>
                    <FormItem
                      className ="img-up"
                      label="资源封面上传"
                      labelCol={{ span: 6 }}
                      wrapperCol={{ span: 18}}
                      hasFeedback
                      required={true}
                      extra="课程封面格式为jpg, png, gif, webp, bmp且大小不超过2M，画面清晰"
                    >
                      <div className="img-conten">
                        <Upload
                          className="album-thumb-uploader"
                          name="avatar"
                          showUploadList={false}
                          beforeUpload={this.beforeUpload}
                          customRequest={(options) => this.handleCustomRequest(options, (file, token) => this.handleUploadHeadPic(file, token))}
                          accept="image/gif,image/png,image/jpeg,image/bmp,image/webp"
                        >
                          {
                            imageUrl?<img src={imageUrl} alt="" className="avatar" /> :
                              <Icon type="plus" className="album-thumb-uploader-trigger" />
                          }
                        </Upload>
                      </div>
                      {
                        imageUrl?<Button onClick={()=>{this.setState({imageUrl:undefined})}} className="delet-img" size="small">删除<Icon type="delete" /></Button>:''
                      }
                    </FormItem>
                  </Form>
                  <FormItem
                    className="textArea"
                    label="专辑简介"
                    labelCol={{ span: 6 }}
                    wrapperCol={{ span: 18}}
                    hasFeedback
                    required={true}
                  >
                    <TextArea value = {intro} onChange={(value)=>{this.setState({intro:value.target.value});}} autosize={true}/>
                  </FormItem>
                  <FormItem
                    label="学习有效期"
                    labelCol={{ span: 6 }}
                    wrapperCol={{ span: 18}}
                    hasFeedback
                    required={true}
                  >
                    <RangePicker defaultValue={[startDate, endDate]} value={[startDate, endDate]} disabledDate={this.disabledRangeDate} onChange={(val)=>this.setTime(val)}/>
                  </FormItem>
                  <FormItem
                    label="收费类型"
                    labelCol={{ span: 6 }}
                    wrapperCol={{ span: 18}}
                    hasFeedback
                    required={true}
                  >
                    <RadioGroup onChange={(vel)=>{this.setState({priceType:vel.target.value})}}>
                      <Radio checked={priceType===1} value={1}>免费</Radio>
                      <Radio checked={priceType===2} value={2}>收费</Radio>
                    </RadioGroup>
                  </FormItem>
                  {
                    priceType===2?<FormItem
                      label="课程费用"
                      labelCol={{ span: 6 }}
                      wrapperCol={{ span: 18}}
                      hasFeedback
                      required={true}
                    >
                      <InputNumber value = {price} onChange={(val)=>{this.setState({price:val});}}  min={0.01} formatter={value => `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}/>
                    </FormItem>:''
                  }
                  <FormItem
                    label="课程学分"
                    labelCol={{ span: 6 }}
                    wrapperCol={{ span: 18}}
                    hasFeedback
                    required={false}
                  >

                    <InputNumber value={credit} onChange={(val)=>{this.setState({credit:val});}} precision={0}   min={1} step={1}  placeholder="请填写学分"/>
                  </FormItem>
                </div>
                <Button className="next-btn" type="primary" size="large" onClick={()=>this.confirm()}>下一步</Button>
              </div>:<AddSpecial{...this.props} resource={this.state} setCurent={()=>this.setCurrent()}/>
            }
          </div>
      </div>
    )
  }
}
const RegistrationForm = Form.create()(CreatResourceForm);

export default RegistrationForm;

