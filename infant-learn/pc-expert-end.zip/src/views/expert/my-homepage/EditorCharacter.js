import React from 'react'
import PropTypes from 'prop-types'
import { Input, Icon, Button } from 'antd'
import './editorCharacterStyle.scss'
const TextArea = Input.TextArea

export default class EditorCharacter extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            editStatus: false,
            value: props.value,
        }
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.value !== this.props.value) {
            this.setState({ value: nextProps.value })
        }
    }

    handleChange(value) {
        this.setState({ value })
    }

    handleClick = () => {
        this.setState({ editStatus: false })
        this.props.onChange(this.state.value)
    }

    handleEdit = () => {
        this.setState({ editStatus: true })
    }

    render() {
        const { title } = this.props
        const { editStatus, value } = this.state
        const element = editStatus ?
            <div>
                <TextArea
                    value={value}
                    rows={3}
                    onChange={(e) => this.handleChange(e.target.value)}
                    style={{ marginBottom: '5px' }}
                />
                <Button type='primary' onClick={this.handleClick}>确认</Button>
            </div> :
            <p>{value}<a href='javascript:void(0)' onClick={this.handleEdit}><Icon type="edit" /></a></p>
        return (
            <div className='achieve' title={title}>
                <span >{title}</span>
                {element}
            </div>
        )
    }
}

//限定控件传入的属性类型
EditorCharacter.propTypes = {
    title: PropTypes.string.isRequired,
    // children: PropTypes.string,
    onChange: PropTypes.func,
}

//设置默认属性
EditorCharacter.defaultProps = {
    children: '内容',
    onChange: f => f,
}