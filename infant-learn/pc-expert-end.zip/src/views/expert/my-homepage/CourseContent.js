import React from 'react'
import PropTypes from 'prop-types'
import { message, Pagination } from 'antd'
import api from '../../../api'
import { TimeShow } from '../../../components'
const NO_MESSAGE = '暂无内容'
export default class CourseContent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            pIndex: 1,
            pSize: 10,
            TotalRecords: 0,
            ViewModelList: [],
        }
    }

    componentDidMount() {
        this.getPageByLecturerID()
    }

    // 根据讲课老师获取课程列表
    getPageByLecturerID(pIndex = this.state.pIndex) {
        const { courseTypeID } = this.props
        const { pSize } = this.state
        api.MyHomepage.getPageByLecturerID({ pIndex, pSize, courseTypeID }).then(res => {
            if (!res) {
                return message.error('res为空')
            }
            if (res.Ret === 0) {
                this.setState({ ...res.Data })
            } else {
                message.info(res.Msg)
            }
        })
    }
    //切换页面
    handlePageChange = (pIndex) => {
        this.state.pIndex = pIndex
        this.getPageByLecturerID()
    }
    render() {
        const { pIndex, pSize, TotalRecords, ViewModelList } = this.state
        return (
            <div>
                {
                    ViewModelList && ViewModelList.length ? ViewModelList.map(({ ID, CoverImg, Name, TeachWayDesc, TeachWay, TrainPlanID, TrainPlanName, LecturerID, LecturerName, Credit, AuditSTDesc, AuditST, PassRate, CourseCatalogs, SDate }, index) => {
                        return (
                            <div className='courses' key={index}>
                                <img className='icon' src={CoverImg} />
                                <dl>
                                    <dt>{Name}</dt>
                                    <dd><span>共有{CourseCatalogs}节课</span><span>学分{Credit}</span></dd>
                                    <dd><span>开课时间：</span><span>{TimeShow(SDate)}</span></dd>
                                </dl>
                                <div className='teach-way'>授课方式：{TeachWayDesc}</div>
                                {TrainPlanName && <div className='train-plan'>所属培训项目：{TrainPlanName}</div>}
                            </div>
                        )
                    }) : NO_MESSAGE
                }
                <div style={{ textAlign: 'right' }}>
                    <Pagination
                        total={TotalRecords}
                        current={pIndex}
                        pageSize={pSize}
                        onChange={this.handlePageChange}
                        showTotal={(total, range) => `共 ${total} 条`}
                    />
                </div>
            </div>
        )
    }
}

//限定控件传入的属性类型
CourseContent.propTypes = {

}

//设置默认属性
CourseContent.defaultProps = {

}
