import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import { Card, Spin, Icon, Tabs, message } from 'antd'
import './style.scss'
import api from '../../../api'
import HomeInfo from './HomeInfo'
import CourseContent from './CourseContent'

const TabPane = Tabs.TabPane;
const NO_MESSAGE = '暂无内容'
export default class MyHomePage extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: false,
      homeInfo: null,
      tabs: [{ Text: "全部", Value: "0", }]
    }
  }
  componentDidMount() {
    this.getLecturerHomeInfo()
    this.getCourseTypeList()
  }

  //课程类型
  getCourseTypeList() {
    api.MyHomepage.getCourseTypeList().then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({ tabs: [...this.state.tabs, ...res.Data] })

      } else {
        message.info(res.Msg)
      }
    })
  }

  //获取主页讲师信息
  getLecturerHomeInfo() {
    api.MyHomepage.getLecturerHomeInfo().then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({ homeInfo: res.Data })
      } else {
        message.info(res.Msg)
      }
    })
  }

  // 更新讲师 简介 成就
  handleHomeInfoChange = (data) => {
    const body=data
    api.MyHomepage.updateLecturerHomeInfo({body}).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({ homeInfo: { ...this.state.homeInfo, ...data } })
        console.log({ ...this.state.homeInfo, ...data })
      } else {
        message.info(res.Msg)
      }
    })
  }

  handleTabsChange = (value) => {
    console.log(value)
  }

  render() {
    const { tabs } = this.state
    return (
      <Spin spinning={this.state.loading}>
        <HomeInfo {...this.state.homeInfo} onChange={this.handleHomeInfoChange} />
        <div className='my-course'>
          <div className='title'>我开设的课程</div>
          <Link className='details' to='/my-course/0'>点击详情可编辑课程<Icon type="double-right" /></Link>
        </div>
        <Card className='homePageCard'>
          {
            tabs && tabs.length ? <Tabs defaultActiveKey={tabs[0].Value} onChange={this.handleTabsChange}>
              {
                tabs.map(({ Text, Value }) => <TabPane tab={Text} key={Value}><CourseContent courseTypeID={Value} /></TabPane>)
              }
            </Tabs> : NO_MESSAGE
          }
        </Card>
      </Spin>
    )
  }
}

//限定控件传入的属性类型
MyHomePage.propTypes = {

}

//设置默认属性
MyHomePage.defaultProps = {

}
