import React from 'react'
import { Card } from 'antd'
import EditorCharacter from './EditorCharacter'
export default function ({ ID, Name, AreaName, LecturerLevelDesc, Instro, HeadPic, Achieve, onChange }) {
    return (
        <div>
            <Card className='homePageCard'>
                <div className='header-homePageCard'>
                    <div className='icon'>
                        <img src={HeadPic} />
                    </div>
                    <div className='content'>
                        <div className='top'>
                            <span className='name'>{Name}</span>
                            <span className='job'>{LecturerLevelDesc}</span>
                        </div>
                        <div>
                            <span>{AreaName}</span>
                        </div>
                    </div>
                </div>
            </Card>
            <Card className='homePageCard'>
                <EditorCharacter title='个人成就：' onChange={(achieve) => { onChange({ lecturerID: ID, achieve, instro: Instro }) }} value={Achieve} />
                <EditorCharacter title='个人简介:' onChange={(instro) => { onChange({ lecturerID: ID, instro, achieve: Achieve }) }} value={Instro} />
            </Card>
        </div>
    )
}
