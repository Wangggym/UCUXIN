import React from 'react'
import {Row, Col, message} from 'antd'
import {TimeShow} from '../../../../components'
import './CourseItem.scss'
import api from '../../../../api'

export default class CourseItem extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }


  componentDidMount() {
    this.getMyCoursePage()
  }

  // 我的课程列表
  getMyCoursePage() {
    api.MyCourse.getMyCourseStudyInfo({courseID: this.props.courseID}).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({...res.Data})
      } else {
        message.info(res.Msg)
      }
    })
  }

  render() {
    const {
      ID, Name, CoverImg, TeachWayDesc,
      TeachWay, TrainPlanID, TrainPlanName, LecturerID, LecturerName,
      Credit, AuditSTDesc, AuditST, CourseCatalogs, SDate, CDate
    } = this.state
    return (
      <div className='courses-item'>
                <span span={12}>
                    <img className='icon' src={CoverImg}/>
                    <dl>
                        <dt>{Name}</dt>
                        <dd><span>共有{CourseCatalogs}节课</span><span>学分{Credit}</span></dd>
                        <dd><span>创建时间：</span>{SDate && <span>{TimeShow(SDate)}</span>}{CDate &&
                        <span>{TimeShow(CDate)}</span>}</dd>
                    </dl>
                  {TrainPlanName && <div className='train-plan'>所属培训项目：{TrainPlanName}</div>}
                </span>
        <span className='teach-way' span={12}>
                    <div className='type'>
                        {/*<span>授课方式：{TeachWayDesc}</span>*/}
                        <span className='status'>状态：{AuditSTDesc}</span>
                    </div>
                </span>
      </div>
    )
  }
}
