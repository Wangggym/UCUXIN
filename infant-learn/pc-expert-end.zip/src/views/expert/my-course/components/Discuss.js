import React from 'react'
import PropTypes from 'prop-types'
import './Discuss.scss'
import {Rate} from 'antd'
import {TimeShow} from '../../../../components'
import {Input, Button, message} from 'antd'

const TextArea = Input.TextArea
const initState = () => {
  return {visible: false, value: ''}
}

class Discuss extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      ...initState()
    }
  }

  handleClick = () => {
    this.setState({visible: true})
  }

  handleConfirm = () => {
    const {value} = this.state
    const formatValue = value.trim()
    if (!formatValue) return message.info('内容不能为空')
    this.setState({...initState()}, () => this.props.onClick(formatValue))
  }

  handleValueChange = (e) => {
    this.setState({value: e.target.value})
  }

  hnadleCancel = () => {
    this.setState({...initState()})
  }

  render() {
    const {onClick, ID, RID, Name, CDate, Cnt, StarCount, DisType, ReDiscussInfo, HeadPic} = this.props
    const {visible, value} = this.state
    return (
      <div className='discuss'>
        <div className='person'>
          <div className='content'>
            <div className='icon'>
              <img src={HeadPic}/>
            </div>
            <div className='record'>
              <span className='name'>{Name}</span>
              <span className='rate'><span>打分</span><Rate allowHalf value={StarCount} disabled/></span>
            </div>
          </div>
          <div className='data'>
            <span className='time'>{TimeShow(CDate, null, 'MM-DD HH:mm')}</span>
            {/*<span>{ReDiscussInfo.UID == 0 && <a href='javascript:void(0)' onClick={this.handleClick}>回复</a>}</span>*/}
          </div>
        </div>
        <div className='foot'>
          <a href='javascript:void(0)' className="line-feed">评论：{Cnt}</a>
        </div>
        {ReDiscussInfo.UID != 0 && <div className='reply'>
          <a href='javascript:void(0)' className="line-feed">{ReDiscussInfo.Name}：{ReDiscussInfo.Cnt}</a>
        </div>}
        {visible && <div className='reply-input'>
          <TextArea value={value} rows={4} onChange={this.handleValueChange}/>
          <Button onClick={this.handleConfirm} type='primary'>确认</Button>
          <span style={{padding: '0 2.5px'}}></span>
          <Button onClick={this.hnadleCancel}>取消</Button>
        </div>}
      </div>
    )
  }
}

export default Discuss
