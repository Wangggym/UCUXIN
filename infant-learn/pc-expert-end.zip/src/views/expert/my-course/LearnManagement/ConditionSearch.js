import React from 'react'
import PropTypes from 'prop-types'
import { Form, Input, message, Select,Button } from 'antd'
import api from '../../../../api'
const Option = Select.Option
const FormItem = Form.Item
const Search = Input.Search;
const enumStudySTType = ['全部', '未开始', '学习中', '待考试', '考试合格', '待补考']
class ConditionSearch extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            courseTypeID: [],
            teachWay: [],
          searchName:""
        }
    }

    componentDidMount() {
        this.checkLoadingStatusFirstChange()
    }

    handleSearch = () => {
        this.props.onChange({ studyName: this.state.searchName.trim() })
    }

    checkLoadingStatusFirstChange() {
        this.props.onChange(this.props.form.getFieldsValue())
    }

    getArrayNodes(array) {
        const newArray = []
        array.forEach((item, index) => {
            newArray.push(<Option value={index-1} key={index}>{item}</Option>)
        })
        return newArray
    }

    render() {
        const { getFieldDecorator } = this.props.form
        return (
            <Form layout="inline" className={this.props.className}>
                <FormItem label={'学习状态'} >
                    {getFieldDecorator(`studyST`, { initialValue: -1 })(
                        <Select style={{ width: 200 }}>
                            {this.getArrayNodes(enumStudySTType)}
                        </Select>
                    )}
                </FormItem>
                <FormItem label='学员姓名'>
                    {/*<Search*/}
                        {/*placeholder="输入学员姓名查询"*/}
                        {/*style={{ width: 200 }}*/}
                        {/*onSearch={this.handleSearch}*/}
                    {/*/>*/}
                  <Input placeholder="输入学员姓名查询" style={{width: 200}}
                         onChange={(e) => this.setState({searchName: e.target.value})}/>
                  <Button type="primary" style={{marginLeft: 8}} onClick={()=>this.handleSearch()}>查询</Button>
                </FormItem>
            </Form>
        )
    }
}

//限定控件传入的属性类型
ConditionSearch.propTypes = {

}

//设置默认属性
ConditionSearch.defaultProps = {

}

export default Form.create({
    onValuesChange: (props, values) => {
        props.onChange(values)
    }
})(ConditionSearch)
