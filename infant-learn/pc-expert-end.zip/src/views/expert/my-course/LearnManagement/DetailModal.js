import React from 'react'
import {Modal, Button, message, Icon} from 'antd';
import api from '../../../../api'
import {TimeShow, CourseResourceDetail} from '../../../../components'
import './DetailModal.scss'

export default class DetailModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false
    }
  }

  // 我的课程列表
  getMyStudyDetail() {
    const {uid, courseID} = this.props
    api.MyCourse.getMyStudyDetail({uid, courseID}).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({...res.Data})
      } else {
        message.info(res.Msg)
      }
    })
  }

  showModal = () => {
    this.getMyStudyDetail()
    this.setState({visible: true})
  }
  handleOk = (e) => {
    this.setState({
      visible: false,
    });
  }
  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  }

  render() {
    const {ID, Name, CDate, StudyDesc, StudyTime, Score, ExamCount, ExamSTDesc, Point, CourseCatalogs = [], IsExam} = this.state
    return (
      <a onClick={this.showModal} href='javascript:void(0);'>
        {this.props.children}
        <Modal
          width={700}
          title="详情"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          footer={null}
        >
          <div className='learnManagementDetial'>
            <div className='line'>学员姓名:<span className='blank-sm'/>{Name}</div>
            <div className='line'>报名时间:<span className='blank-sm'/>{TimeShow(CDate, null)}</div>
            <div className='line'>学习状态:<span className='blank-sm'/>{StudyDesc} <span className='blank'>{Point}</span>
            </div>
            {CourseCatalogs && CourseCatalogs.length && CourseCatalogs.map(({ID, CourseID, PID, Name, Level, Sort, CourseResourceDetails}, index) => {
              return (
                <dl className='contant-small' key={index}>
                  <dt><span className='order'>第{index + 1}讲</span>{Name}</dt>
                  {
                    CourseResourceDetails && CourseResourceDetails.length && CourseResourceDetails.map((item, index) => {
                      return <dd key={index}><CourseResourceDetail data={item}/></dd>
                    })
                  }
                </dl>
              )
            })}
            {IsExam && <div>
              <div className='line'>考试得分:<span className='blank-sm'/>{Score}分</div>
              <div className='line'>补考:<span className='blank-sm'/>{ExamCount}</div>
              <div className='line'>考试状态:<span className='blank-sm'/>{ExamSTDesc}</div>
            </div>}
            {/* <div className='line'>学分获得情况:<span className='blank-sm' />已获得</div> */}
          </div>
        </Modal>
      </a>
    );
  }
}
