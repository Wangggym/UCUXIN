import React from 'react'
import PropTypes from 'prop-types'
import {message, Pagination, Table,Button} from 'antd'
import CourseItem from '../components/CourseItem'
import './LearnManagement.scss'
import api from '../../../../api'
import ConditionSearch from './ConditionSearch'
import {TimeShow} from '../../../../components'
import DetailModal from './DetailModal'

export default class LearnManagement extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      ViewModelList: [],
      PageSize: 10,
      TotalRecords: 0,
      PageIndex: 1,
      Pages: 0,
      firstTotalRecords: 0,
      firstStatus: false
    }
    this.conditionSearchValue = {studyST: 0, studyName: ''}
  }


  handleConditionSearch = (value) => {
    this.conditionSearchValue = {...this.conditionSearchValue, ...value}
    this.getMyStudyInfoPage()
  }

  // 我的课程列表
  getMyStudyInfoPage(pIndex = this.state.PageIndex) {
    const pSize = this.state.PageSize
    api.MyCourse.getMyStudyInfoPage({
      courseID: this.props.match.params.courseID,
      pIndex,
      pSize, ...this.conditionSearchValue
    }).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        const {ViewModelList} = res.Data
        ViewModelList.forEach((item, index, array) => {
          array[index].key = item.ID
          array[index].index = index + 1
          array[index].CDate = TimeShow(item.CDate, null)
        })
        const {firstStatus} = this.state
        if (!firstStatus) {
          this.setState({firstStatus: true, firstTotalRecords: res.Data.ViewModelList.length})
        }
        this.setState({...res.Data, ViewModelList})
      } else {
        message.info(res.Msg)
      }
    })
  }

  handlePageSizeChange = (PageIndex) => {
    this.setState({PageIndex}, () => this.getMyStudyInfoPage(PageIndex))
  }


  handleClickDetail = () => {

  }

  render() {
    const columns = [
      {
        title: '编号',
        dataIndex: 'index',
        key: 'index',
      },
      {
        title: '学生名称',
        dataIndex: 'Name',
        key: 'Name',
      },
      {
        title: '学习报名时间',
        dataIndex: 'CDate',
        key: 'CDate',
      },
      {
        title: '学习状态',
        dataIndex: 'StudyDesc',
        key: 'StudyDesc',
      },
      {
        title: '学习总时长',
        dataIndex: 'StudyTime',
        key: 'StudyTime',
        render: (text) => text + '分'
      },
      {
        title: '考试得分',
        dataIndex: 'Score',
        key: 'Score',
        render: (text) => text ? text : '-'
      },
      {
        title: '进度',
        dataIndex: 'Point',
        key: 'Point',
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        render: (text, {UID}) => <DetailModal courseID={this.props.match.params.courseID} uid={UID}>详情</DetailModal>
      },
    ]
    return (
      <div>
        <div style={{textAlign:"right"}}>
          <Button onClick={()=>this.props.history.goBack()}>返回</Button>
        </div>
        <CourseItem courseID={this.props.match.params.courseID}/>
        <div className='discuss-title'>
          共有{this.state.firstTotalRecords}人报名学习该课程
        </div>
        <div className='learnManagement'>
          <ConditionSearch onChange={this.handleConditionSearch} className='conditionSearch'/>
          <Table dataSource={this.state.ViewModelList} columns={columns} pagination={false}/>
          <div style={{paddingTop: 20, textAlign: 'right'}}>
            <Pagination
              showTotal={total => `共 ${total} 条`}
              total={this.state.TotalRecords}
              current={this.state.PageIndex}
              pageSize={this.state.PageSize}
              onChange={this.handlePageSizeChange}
              showQuickJumper={this.state.TotalRecords > 10}
            />
          </div>
        </div>
      </div>

    )
  }
}

//限定控件传入的属性类型
LearnManagement.propTypes = {}

//设置默认属性
LearnManagement.defaultProps = {}


