import React from 'react'
import PropTypes from 'prop-types'
import { Rate, message, Pagination } from 'antd'
import CourseItem from '../components/CourseItem'
import Discuss from '../components/Discuss'
import './DiscussManagement.scss'
import api from '../../../../api'
export default class DiscussManagement extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      ViewModelList: [],
      PageSize: 3,
      TotalRecords: 0,
      PageIndex: 1,
      Pages: 0,
    }
  }
  componentDidMount() {
    this.getMyStudyDiscussInfoPage()
  }

  // 我的课程列表
  getMyStudyDiscussInfoPage(pIndex = this.state.PageIndex) {
    const pSize = this.state.PageSize
    api.MyCourse.getMyStudyDiscussInfoPage({ courseID: this.props.match.params.courseID, pIndex, pSize }).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({ ...res.Data })
      } else {
        message.info(res.Msg)
      }
    })
  }

  handlePageSizeChange = (PageIndex) => {
    this.setState({ PageIndex }, () => this.getMyStudyDiscussInfoPage(PageIndex))
  }


  handleClick = (Cnt, RID) => {
    const body = { Cnt, RID, DisType: 2 }
    api.MyCourse.addDiscussInfo({ body }).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        console.log(res)
        // this.setState({ ...res.Data })
      } else {
        message.info(res.Msg)
      }
      this.getMyStudyDiscussInfoPage()
    })

  }

  render() {
    const { ViewModelList } = this.state
    return (
      <div>
        <CourseItem courseID={this.props.match.params.courseID} />
        <div className='discuss-title'>
          该课程共收到{this.state.TotalRecords}条评论：
          </div>
        {ViewModelList && ViewModelList.length ? ViewModelList.map((item, index) => <Discuss {...item} key={index} onClick={(value) => this.handleClick(value, item.ID)} />) : null}
        <div style={{ paddingTop: 20, textAlign: 'right' }}>
          <Pagination
            showTotal={total => `共 ${total} 条`}
            total={this.state.TotalRecords}
            current={this.state.PageIndex}
            pageSize={this.state.PageSize}
            onChange={this.handlePageSizeChange}
            showQuickJumper={this.state.TotalRecords > 10}
          />
        </div>
      </div>
    )
  }
}

//限定控件传入的属性类型
DiscussManagement.propTypes = {

}

//设置默认属性
DiscussManagement.defaultProps = {

}