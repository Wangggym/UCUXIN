import React from 'react'
import {Icon} from 'antd'
import './details-content.scss'
import {CourseResourceDetail} from '../../../components/index'

const DetialsContent = (props) => {
  const {
    checkVisible,
    ID,
    Name,
    TeachWayDesc,
    TeachWay,
    TrainPlanID,
    TrainPlanName,
    LecturerID,
    LecturerName,
    AuditSTDesc,
    AuditST,
    RejectCnt,
    CoverImg,
    Instro,
    Credit,
    CDate,
    CourseCatalogs,
  } = props
  return (
    <div className='details' style={{marginLeft: '20%', marginBottom: 20}}>
      <div className='header clearfix'>
        <div className='icon'>
          <img src={CoverImg}/>
        </div>
        <dl className='contant'>
          <dt>{Name}</dt>
          <dd>授课方式:{TeachWayDesc}<span className='blank'>共{CourseCatalogs ? CourseCatalogs.length : 0}节课</span></dd>
          <dd>授课讲师:{LecturerName}<span className='blank'>学分：{Credit}</span></dd>
          {TrainPlanName && <dd>培训项目：{TrainPlanName}</dd>}
        </dl>
      </div>
      <div className='main'>
        {CourseCatalogs && CourseCatalogs.length ? <h6>包含的{CourseCatalogs.length}节课：</h6> : null}
        {CourseCatalogs && CourseCatalogs.length ? CourseCatalogs.map(({ID, CourseID, PID, Name, Level, Sort, CourseResourceDetails}, index) => {
          return (
            <dl className='contant-small' key={index}>
              <dt><span className='order'>第{index + 1}讲</span>{Name}</dt>
              {
                CourseResourceDetails && CourseResourceDetails.length ? CourseResourceDetails.map((item, index) => {
                  return <dd key={index}><CourseResourceDetail data={item}/></dd>
                }) : null
              }
            </dl>
          )
        }) : null}
      </div>
      {/* <div className='status'>
                <p>课程提交时间：{CDate}</p>
                <p>审核状态：{AuditSTDesc}</p>
            </div> */}
    </div>

  )
}
export default DetialsContent
