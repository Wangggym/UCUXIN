import React from 'react'
import PropTypes from 'prop-types'
import {Card, Button, message, Spin, Pagination, Row, Col} from 'antd'
import {Link} from 'react-router-dom'
import ConditionSearch from './ConditionSearch'
import DetailsModal from './DetailsModal'
import QRcodeModal from './QRcodeModal'
import './style.scss'
import api from '../../../api'
import {TimeShow} from '../../../components'

const AuditSTType = {
  10: ['']
}
export default class MyCourse extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      PageSize: 10,
      TotalRecords: 0,
      PageIndex: 1,
      Pages: 0,
      ViewModelList: [],
      loading: false,
      courseTypeID: '0'
    }
    this.conditionSearchValue = {courseTypeID: '', teachWay: '0', name: ''}
  }

  handleConditionSearch = (value) => {
    const {courseTypeID} = value
    if (courseTypeID == '4') {
      this.conditionSearchValue.teachWay = '0'
    }
    this.setState({courseTypeID})
    this.conditionSearchValue = {...this.conditionSearchValue, ...value}
    this.getMyCoursePage()
  }

  // 我的课程列表
  getMyCoursePage() {
    const {PageSize, PageIndex} = this.state
    this.setState({loading: true})
    api.MyCourse.getMyCoursePage({...this.conditionSearchValue, pSize: PageSize, pIndex: PageIndex}).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({...res.Data})
      } else {
        message.info(res.Msg)
      }
      this.setState({loading: false})
    })
  }

  //切换页面
  handlePageChange = (PageIndex) => {
    this.state.PageIndex = PageIndex
    this.getMyCoursePage()
  }

  //删除
  handleDelete = (courseID) => {
    api.MyCourse.getCourseByID({courseID}).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.getMyCoursePage()
      } else {
        message.info(res.Msg)
      }
      this.setState({loading: false})
    })
  }

  handleClick(offerCourse, ID, CourseType) {
    if (CourseType && CourseType == '4') {
      return this.props.history.push({
        pathname: `/organize-resource/${ID}`,
      });
    }
    if (this.conditionSearchValue.courseTypeID == 4) {
      if (offerCourse.step == 1) {
        sessionStorage.setItem('current', 1);
      }
      this.props.history.push({
        pathname: `/organize-resource/${ID}`,
      });
    } else {
      this.props.history.push({
        pathname: `/start-courses`,
        state: {offerCourse}
      });
    }

  }

  render() {
    const {ViewModelList, TotalRecords} = this.state
    const title = (
      <div className='title'>
        <span>我开设的课程：共{TotalRecords}个</span>
        {/* <Link to='' >待创建试卷<span>3</span></Link> */}
      </div>
    )
    const origin = '/my-course'
    const pass = AuditST => AuditST === 10 || AuditST === 40
    const noPass = AuditST => AuditST === 20 || AuditST === 50
    return (
      <div>
        <Card title={title} className='card' extra={<Button onClick={() => this.props.history.goBack()}>返回</Button>}>
          <ConditionSearch onChange={this.handleConditionSearch} initCourseType={this.props.location.state || 0}/>
        </Card>
        <Card className='card'>
          <Spin spinning={this.state.loading}>
            {
              ViewModelList && ViewModelList.length ? ViewModelList.map((item, index) => {
                const {
                  ID, Name, CoverImg, TeachWayDesc,
                  TeachWay, TrainPlanID, TrainPlanName, LecturerID, LecturerName,
                  Credit, AuditSTDesc, AuditST, CourseCatalogs, SDate, IsExam, EDate, CourseType,
                } = item;
                return (
                  <Row className='courses' key={ID}>
                    <Col span={12}>
                      <img className='icon' src={CoverImg}/>
                      <dl>
                        <dt>{Name}</dt>
                        <dd><span>共有{CourseCatalogs}节课</span><span>学分{Credit}</span></dd>
                        <dd><span>学习时间：</span><span>{TimeShow(SDate)}至{TimeShow(EDate)}</span></dd>
                      </dl>
                      {TrainPlanName && <div className='train-plan'>所属培训项目：{TrainPlanName}</div>}
                    </Col>
                    <Col className='teach-way' span={12}>
                      <div className='type'>
                        {this.state.courseTypeID !== '4' ? <span>授课方式：{TeachWayDesc}</span> : null}
                        <span className='status'>状态：{AuditSTDesc}</span>
                      </div>
                      {
                        pass(AuditST) && <div className='button-group'>
                          <DetailsModal title='查看详情' courseID={ID}>
                            <Button>查看详情</Button>
                          </DetailsModal>
                          <Button
                            onClick={() => this.handleClick({
                              step: 0,
                              trainPlanID: TrainPlanID,
                              courseID: ID,
                              origin
                            }, ID, CourseType)}>编辑信息</Button>
                          {CourseType!=4 && <Button
                            onClick={() => this.handleClick({
                              step: 1,
                              trainPlanID: TrainPlanID,
                              courseID: ID,
                              origin
                            }, ID)}>添加课程</Button>}

                          {
                            AuditST === 10 && IsExam && <Button
                              onClick={() => this.handleClick({
                                step: 2,
                                trainPlanID: TrainPlanID,
                                courseID: ID,
                                origin
                              })}>添加试卷</Button>
                          }
                          <Button onClick={() => this.handleDelete(ID)}>删除</Button>
                        </div>
                      }
                      {
                        (AuditST === 30) && <div className='button-group'>
                          <DetailsModal title='查看详情' courseID={ID}>
                            <Button>查看详情</Button>
                          </DetailsModal>
                        </div>
                      }

                      {
                        noPass(AuditST) && <div className='button-group'>
                          <DetailsModal title='查看详情' courseID={ID}>
                            <Button>查看详情</Button>
                          </DetailsModal>
                          {TeachWay === 3 && <QRcodeModal title={Name + '二维码'} courseID={ID}>
                            <Button>查看二维码</Button>
                          </QRcodeModal>}
                          <Button><Link to={'/learn-managemanet/' + ID}>学习管理</Link></Button>
                          <Button><Link to={'/discuss-managemanet/' + ID}>评论管理</Link></Button>
                          {/*<Button onClick={() => this.handleClick({ step: 1, trainPlanID: TrainPlanID, courseID: ID, origin })}>添加课程</Button>*/}
                          {/*<Button onClick={() => this.handleClick({ step: 2, trainPlanID: TrainPlanID, courseID: ID, origin })}>创建试卷</Button>*/}
                        </div>
                      }
                    </Col>
                  </Row>
                )
              }) : '暂无课程'
            }
            <div style={{textAlign: 'right'}}>
              <Pagination
                total={this.state.TotalRecords}
                current={this.state.PageIndex}
                pageSize={this.state.PageSize}
                onChange={this.handlePageChange}/>
            </div>
          </Spin>
        </Card>
      </div>
    )
  }
}

//限定控件传入的属性类型
MyCourse.propTypes = {}

//设置默认属性
MyCourse.defaultProps = {}
