import React from 'react'
import PropTypes from 'prop-types'
import {Modal, Spin, message} from 'antd'
import api from '../../../api'
import DetialsContent from './DetialsContent'

export default class DetailsModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      loading: false,
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.onOff !== undefined && nextProps.onOff !== this.props.onOff) {
      this.setState({visible: nextProps.onOff})
      if (nextProps.onOff) {
        api.MyCourse.getLecturerByID({courseID: this.props.courseID}).then(res => {
          if (!res) {
            return message.error('res为空')
          }
          if (res.Ret === 0) {
            this.setState({course: res.Data})
          } else {
            message.info(res.Msg)
          }
          this.setState({loading: false})
        })
      }
    }
  }

  toggle(boolean) {
    const {changeOnOff} = this.props
    changeOnOff ? changeOnOff(boolean) : this.setState({visible: boolean})
  }

  showModal = () => {
    this.setState({loading: true})
    api.MyCourse.getLecturerByID({courseID: this.props.courseID}).then(res => {
      if (!res) {
        return message.error('res为空')
      }
      if (res.Ret === 0) {
        this.setState({course: res.Data})
      } else {
        message.info(res.Msg)
      }
      this.setState({loading: false})
    })
    this.toggle(true)
  }


  handleOk = () => {
    this.toggle(false)
  }

  handleCancel = () => {
    this.toggle(false)
  }


  render() {
    const {title} = this.props;
    return (
      <a href='javascript:void(0)' onClick={this.showModal}>
        <Modal onOk={this.handleOk} onCancel={this.handleCancel} visible={this.state.visible} title={title} width={800}
               footer={null}>
          <Spin spinning={this.state.loading}>
            <DetialsContent {...this.state.course}/>
          </Spin>
        </Modal>
        {this.props.children}
      </a>
    );
  }
}


//限定控件传入的属性类型
DetailsModal.propTypes = {}

//设置默认属性
DetailsModal.defaultProps = {}
