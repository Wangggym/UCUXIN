import React from 'react'
import PropTypes from 'prop-types'
import {Modal, Spin, message} from 'antd'
import QRCode from 'qrcode.react'

export default class QRcodeModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      loading: false,
      QRcodeValue: 'http://h.test.ucuxin.com/InLeSpa/sign-in/' + props.courseID,
    }
  }

  componentDidMount() {

  }

  showModal = () => {
    this.setState({visible: true});
    console.log(this.state.QRcodeValue)
  }


  handleOk = () => {
    this.setState({visible: false})
  }

  handleCancel = () => {
    this.setState({visible: false})
  }


  render() {
    const {title} = this.props
    return (
      <a href='javascript:void(0);' onClick={this.showModal}>
        <Modal onOk={this.handleOk} onCancel={this.handleCancel} visible={this.state.visible} title={title} width={800}>
          <Spin spinning={this.state.loading}>
            <div className='qrcode-wrapper'>
              <QRCode value={this.state.QRcodeValue} size={200}/>
            </div>
          </Spin>
        </Modal>
        {this.props.children}
      </a>
    );
  }
}


//限定控件传入的属性类型
QRcodeModal.propTypes = {}

//设置默认属性
QRcodeModal.defaultProps = {}
