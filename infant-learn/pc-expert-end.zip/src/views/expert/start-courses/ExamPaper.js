/**
 * Created by QiHan Wang on 2017/9/6.
 * ExamPaper
 */

import React, {Component} from 'react';
import {Token} from '../../../utils';
import Api from '../../../api';
// -- Ant Design
import {
  Button,
  Modal,
  Table,
  Tabs,
  Card,
  Form,
  Input,
  InputNumber,
  Icon,
  message
} from 'antd';

const TabPane = Tabs.TabPane;
const FormItem = Form.Item;
const token = Token();

class ExamPaper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      courseData: {},
      courseID: '',
      examPaper: undefined,
      pagination: {
        current: 1,
        pageSize: 10
      },
      dataResource: [],      // 试卷列表资源
      selectedResource: [],  // 选中的试卷资源
      rowSelection: {
        type: 'radio',
        selectedRowKeys: [],
        onSelect: this.handleRowSelect
      },
      visible: false
    };

    this.columns = [
      {
        title: '名称',
        dataIndex: 'Name',
        width: '60%'
      },
      {
        title: '题数',
        dataIndex: 'Count',
        width: '40%',
      }
    ];
  }

  componentWillMount() {
    this.setState({courseID: this.props.location.state.offerCourse.courseID})
  }

  componentDidMount() {

    (async () => {
      try {
        const course = await this.getCourse();
        const resource = await this.getResource();

        this.handleCourse(course);
        this.handleResource(resource)

      } catch (err) {
        message.error(err.Msg)
      }
    })();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.submit && nextProps.submit !== this.props.submit) {
      this.handleSubmit();
    }
  }


  // 根据课程ID获取课程信息
  getCourse = () => Api.StartCourses.getCourse({token, courseID: this.state.courseID});

  handleSubmit = () => {
    const {form, onSubmit} = this.props;
    const {examPaper, courseData} = this.state;

    if (!(examPaper && examPaper.ID)) {
      onSubmit(false);
      message.error('请选选择试卷或创建试卷！');
      return;
    }
    form.validateFields((err, values) => {
      if (!err) {
        if(!(+values.passScore)){
          message.error('合格分数不能为0！');
          return;
        }
        Api.StartCourses.saveCoursePaper({
          token, body: {
            ID: courseData.CoursePaper ? courseData.CoursePaper.ID : 0,
            CourseID: courseData.ID,
            ResourceID: examPaper.ID,
            UpCount: values.upCount,
            UpExamFee: values.upExamFee,
            ExamCount: values.examCount,
            PassScore: values.passScore
          }
        }).then(res => {
          if (res.Ret === 0) {
            Api.StartCourses.updateCourseStatus({token,courseID: courseData.ID}).then(res=> {
              if(res.Ret ===0){
                onSubmit(true);
              }else{
                message.error(res.Msg);
                onSubmit(false);
              }
            });
          } else {
            message.error(res.Msg);
            onSubmit(false);
          }
        })
      } else {
        message.error('请将表单填写完整！');
        onSubmit(false);
      }
    })
  }

// 获取试卷资源
  getResource = (page) => {
    const {pagination} = this.state;
    return Api.StartCourses.getMyResource({
      token,
      type: 4,
      pIndex: page || pagination.current,
      pSize: pagination.pageSize
    });
  };
  // 课程
  handleCourse = (res) => {
    if (res.Ret === 0) {
      const courseData = res.Data;
      const {CoursePaper} = courseData;
      if (CoursePaper) {
        this.setState({
          courseData, examPaper: {
            ID: CoursePaper.ID,
            Count: CoursePaper.QtyQuestions,
            Name: CoursePaper.ResourceName,
            ResourceID: CoursePaper.ResourceID,
            ResourceType: 4
          }
        }, () => {
          this.props.form.setFieldsValue({
            upCount: CoursePaper.UpCount,
            upExamFee: CoursePaper.UpExamFee,
            examCount: CoursePaper.ExamCount,
            passScore: CoursePaper.PassScore
          })
        });
      } else {
        this.setState({courseData});
      }

      // 更新步骤状态
      this.props.onCtrlStepBar(courseData.IsExam);
    } else {
      message.error(res.Msg);
    }
  };

  // 试卷资源处理
  handleResource = (res) => {
    const {pagination, rowSelection} = this.state;
    const {location, history, form} = this.props;
    if (res.Ret === 0) {
      const {PageIndex, TotalRecords, ViewModelList} = res.Data;
      pagination.current = PageIndex;
      pagination.total = TotalRecords;

      // 是否由创建试卷返回
      if (location.state && location.state.startCourse) {
        const {startCourse} = location.state;
        if (startCourse.step === 2) {
          const selectedResource = ViewModelList.filter(item => startCourse.examID === item.ID);
          this.setState({
            ...this.state,
            examPaper: selectedResource[0],
            selectedResource,
            rowSelection: {
              ...rowSelection,
              selectedRowKeys: [startCourse.examID]
            }
          }, () => {
            location.state.startCourse.examInfo && form.setFieldsValue(location.state.startCourse.examInfo);

            Reflect.deleteProperty(location.state, 'startCourse');
            history.replace({state: location.state});
          });
        }
      }

      this.setState({
        dataResource: ViewModelList,
        pagination
      })
    } else {
      message.error(res.Msg)
    }
  };

  // Table
  handleTableChange = (pagination, filters, sorter) => {
    const pager = {...this.state.pagination};
    pager.current = pagination.current;

    const {rowSelection, selectedResource} = this.state;
    this.setState({
      pagination: pager,
      rowSelection: {...rowSelection, selectedRowKeys: selectedResource.map(item => item.ID)}
    });

    this.getResource(pagination.current).then(this.handleResource);
  };

  // 单项选择
  handleRowSelect = (record, selected, selectedRows) => {
    let {rowSelection} = this.state;
    this.setState({
      selectedResource: [record],
      rowSelection: {...rowSelection, selectedRowKeys: [record.ID]}
    });
  };

  handleOk = () => {
    this.setState({visible: false, examPaper: this.state.selectedResource[0]});
  };
  handleSelectTestPaper = () => {
    this.setState({visible: true});
    this.getResource().then(this.handleResource);
  }
  handleCancelSelect = () => this.setState({visible: false});

  // 创建试卷
  handleCreateTestPaper = () => {
    const {location, history, form} = this.props;
    const startCourse = {
      courseID: this.state.courseID,
      step: 2,
      origin: location.pathname
    };

    if (this.state.examPaper) {
      startCourse.examInfo = form.getFieldsValue();
    }

    history.push({
      pathname: '/editor-test',
      state: {
        ...location.state,
        startCourse
      }
    });
  };

  render() {
    const {dataResource, pagination, rowSelection, visible, examPaper} = this.state;
    const operations = <Button icon="plus" onClick={this.handleCreateTestPaper}>创建试卷</Button>;
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: {span: 24},
        sm: {span: 6},
      },
      wrapperCol: {
        xs: {span: 24},
        sm: {span: 14},
      },
    };
    return (
      <div className="exam-paper">
        {
          examPaper ?
            <div className="exam-paper-card">
              <Card title="考试信息" bordered={false} noHovering={true}>
                <Form>
                  <FormItem {...formItemLayout} label="考试次数" hasFeedback extra="课程学习完成后正常能考试的次数" style={{display:"none"}}>
                    {getFieldDecorator('examCount', {initialValue: '1000', rules: [
                      {required: true, message: '请填写考试次数！'},
                      {pattern: /^\d+$/, message: '考试次数应为正整数'}
                      ]})(
                      <InputNumber min={0} style={{width:'100%'}}/>
                    )}
                  </FormItem>
                  <FormItem{...formItemLayout} label="合格分数" hasFeedback extra="合格分数为不为0的正整数！">
                    {getFieldDecorator('passScore', {rules: [{required: true, message: '请填写合格分数！'}]})(
                      <InputNumber min={0} style={{width:'100%'}}/>
                    )}
                  </FormItem>
                  <FormItem {...formItemLayout} label="补考次数" hasFeedback extra="正常考试次数用完后，缴纳补考费用能考试的次数"  style={{display:"none"}}>
                    {getFieldDecorator('upCount', {initialValue:'1000', rules: [
                      {required: true, message: '请填写补考次数！'},
                      {pattern: /^\d+$/, message: '补考次数应为正整数'}
                      ]})(
                      <InputNumber min={0} style={{width:'100%'}}/>
                    )}
                  </FormItem>
                  <FormItem {...formItemLayout} label="补考费用" hasFeedback style={{display:"none"}}>
                    {getFieldDecorator('upExamFee', {initialValue: '0',rules: [{required: true, message: '请填写补考费用！'}]})(
                      <InputNumber min={0}
                                   formatter={value => `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')} style={{width:'100%'}}/>
                    )}
                  </FormItem>
                </Form>
              </Card>
              <Card title="试卷信息" bordered={false} noHovering={true}
                    extra={<Button onClick={this.handleSelectTestPaper}>更换试卷</Button>}>
                <Form>
                  <FormItem
                    {...formItemLayout}
                    label="试卷名称"
                  >
                    <span className="ant-form-text">{examPaper.Name}</span>
                  </FormItem>
                  <FormItem
                    {...formItemLayout}
                    label="题目数量"
                    hasFeedback
                  >
                    <span className="ant-form-text">共{examPaper.Count}道题</span>
                  </FormItem>
                </Form>
              </Card>
            </div> :
            <div className="exam-btn-choose">
              <Button type="dashed" icon="select" onClick={this.handleSelectTestPaper}>选择试卷</Button>
              <Button type="dashed" icon="plus" onClick={this.handleCreateTestPaper}>创建试卷</Button>
              <div className="exam-btn-desc">请选择您要创建课程试卷的方式，<br/><b>选择试卷</b>：从已创建的试卷库中选择试卷。<br/><b>创建试卷</b>：创建一套新的试卷。
              </div>
            </div>
        }

        <Modal
          title={<div><Icon type="file-text" style={{marginRight: 8}}/>选择试卷</div>}
          width={680}
          visible={visible}
          onCancel={this.handleCancelSelect}
          maskClosable={false}
          footer={null}
        >
          <Tabs tabBarExtraContent={operations}>
            <TabPane tab="我的试卷" key="1">
              {
                dataResource && dataResource.length ?
                  <Table rowKey="ID"
                         columns={this.columns}
                         rowSelection={rowSelection}
                         dataSource={dataResource}
                         pagination={pagination}
                         onChange={this.handleTableChange}
                         size="small"/> :
                  <div className="no-course">没有可用试卷哦~！去<a onClick={this.handleCreateTestPaper}>创建试卷</a>？</div>
              }
              <div>
                {dataResource && dataResource.length ?
                  <Button type="primary" onClick={this.handleOk}>确定</Button> : null}
                {/* <Button style={{marginLeft: 8}} onClick={this.handleReset}>重选</Button>*/}
              </div>
            </TabPane>
          </Tabs>

        </Modal>
      </div>
    )
  }
}

export default Form.create()(ExamPaper)
