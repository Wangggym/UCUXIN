/**
 * Created by QiHan Wang on 2017/8/29.
 * index
 */

import React, {Component} from 'react';
import './start-courses.scss';
// -- Custom Page Components
import BasicInfo from './BasicInfo';
import CourseContent from './CourseContent';
import ExamPaper from './ExamPaper';

// -- Ant Design
import {Modal, Steps, Button, message} from 'antd';

const Step = Steps.Step;

class StartCourses extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0,
      isSubmit: false,
      loading: false,
      previewVisible: false,
      stepBar: []
      //stepBar: ['创建课程信息', '添加课程内容']
    };
  }

  componentWillMount() {
    const {state} = this.props.location;
    //(state && state.startCourse) && this.setState({current: state.startCourse.step})
    (state && state.offerCourse) && this.setState({current: state.offerCourse.step});
  }

  handleNext = () => {
    this.setState({isSubmit: true, loading: true});
  };

  handlePrev = () => {
    const current = this.state.current - 1;
    this.setState({current});
    this.handleStep(current);
  };


  handlePreview = () => {
    //message.success('Preview!')
    this.setState({previewVisible: true})
  };
  handleCancelPreview = () => this.setState({previewVisible: false});

  handleSubmit = (isSubmit) => {
    if (isSubmit) {
      if (this.state.current === this.state.stepBar.length - 1) {
        const {location, history} = this.props;
        message.success('课程开设成功！');
        this.setState({isSubmit: !isSubmit, loading: false});
        history.push({pathname: location.state.offerCourse.origin || '/my-course'});
      } else {
        const current = this.state.current + 1;
        this.setState({current, isSubmit: !isSubmit, loading: false});
        this.handleStep(current);
      }
    } else {
      this.setState({isSubmit: isSubmit, loading: false});
    }
  };

  // 更新步骤
  handleStep = (current) => {
    const {location, history} = this.props;
    history.replace({
      state: {
        ...location.state,
        offerCourse: {
          ...location.state.offerCourse,
          step: current,
        }
      }
    })
  };

  // 处理步骤Bar
  handleStepBar = (isExam) => {
    const {location, history} = this.props;
    const state = location.state || {};
    const offerCourse = state.offerCourse || {};

    // 若state存在则更新state值，不存在，表示新增，不作任何处理
    if(location.state){
      history.replace({
        state: {
          ...state,
          offerCourse: {
            ...offerCourse,
            isExam
          }
        }
      });
    }
    this.setState({isExam, stepBar: isExam ? ['创建课程信息', '添加课程内容', '创建课程试卷'] : ['创建课程信息', '添加课程内容']});
  };

  // 切换内容页面
  renderStepContent = (current) => {
    const {isSubmit, previewVisible} = this.state;
    switch (current) {
      case 0: // 创建课程信息
        return <BasicInfo
          submit={isSubmit}
          onSubmit={this.handleSubmit}
          onCtrlStepBar={this.handleStepBar}
          {...this.props}
        />;
      case 1: // 添加课程内容
        return <CourseContent
          submit={isSubmit}
          previewVisible={previewVisible}
          onSubmit={this.handleSubmit}
          onCancelPreview={this.handleCancelPreview}
          onCtrlStepBar={this.handleStepBar}

          {...this.props}/>;
      case 2: // 创建试卷
        return <ExamPaper
          submit={isSubmit}
          onSubmit={this.handleSubmit}
          onCtrlStepBar={this.handleStepBar}
          {...this.props}/>;
      default:
        return <BasicInfo submit={isSubmit} onSubmit={this.handleSubmit}/>;
    }
  };

  render() {
    const {current, stepBar} = this.state;
    return (
      <div className="start-course">
        <Steps current={current} style={stepBar.length <= 2 ? {width: 600} : {}}>
          {
            stepBar.map(step => <Step key={step} title={step}/>)
          }
        </Steps>

        <div className="steps-content">
          {this.renderStepContent(current)}
        </div>

        <div className="steps-action">

          {
            current > 0 && <Button onClick={this.handlePrev}>上一步</Button>
          }
          {/*{
            current === 1 &&
            <Button type="primary" style={{marginLeft: 8}} shape="circle" ghost={true} icon="eye-o" title="预览"
                    onClick={this.handlePreview}/>
          }*/}
          {
            current < stepBar.length - 1 &&
            <Button type="primary" onClick={this.handleNext} loading={this.state.loading}>下一步</Button>
          }

          {
            current === stepBar.length - 1 &&
            <Button type="primary" onClick={this.handleNext}>完成</Button>
          }
        </div>
      </div>
    )
  }
}

export default StartCourses;
