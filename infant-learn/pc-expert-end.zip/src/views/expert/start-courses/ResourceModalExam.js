/**
 * Created by QiHan Wang on 2017/8/31.
 * ResourceModal
 */

import React, {Component} from 'react';
import {Token} from '../../../utils';
import Api from '../../../api';

// -- Ant Design
import {
  Button,
  Modal,
  Table,
  Tabs,
  Icon,
  message
} from 'antd';

const TabPane = Tabs.TabPane;
const token = Token();

class ResourceModalExam extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 10
      },
      dataResource: [],
      selectedResource: [],
      rowSelection: {
        selectedRowKeys: [],
        onSelect: this.handleRowSelect,
        onSelectAll: this.handleRowSelectAll,
      },
      activeKey: '1'
    };

    this.columns = [
      {
        title: '名称',
        dataIndex: 'Name',
        width: '60%'
      },
      {
        title: '题数',
        dataIndex: 'Count',
        width: '40%',
      }
    ];
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.visible) {
      this.getResource(1);
    }
  }

  // 获取试卷资源
  getResource = (page) => {
    const {pagination} = this.state;
    this.setState({resourceLoading: true});
    Api.StartCourses.getMyResource({
      token,
      type: 4,
      pIndex: page || pagination.current,
      pSize: pagination.pageSize
    }).then(res => {

      let dataResource;
      if (res.Ret === 0) {
        const {PageIndex, TotalRecords, ViewModelList} = res.Data;
        pagination.current = PageIndex;
        pagination.total = TotalRecords;
        dataResource = ViewModelList;
      } else {
        message.error(res.Msg)
      }
      this.setState({resourceLoading: false, pagination, dataResource: dataResource ? dataResource : []});
    });
  }

  // 添加选中资源到目录下
  handleOk = () => {
    const {visible, onOk, catalog} = this.props;
    const {selectedResource, rowSelection} = this.state;
    const catalogResourceList = [];
    // 重组提交数据modal
    selectedResource.map(item => {
      catalogResourceList.push({
        ID: 0,
        ResourceID: item.ID,
        CourseCatalogID: catalog.ID
      })
    });
    //onOk(!visible, selectedResource);

    if (!selectedResource.length) {
      message.error('请先选择要添加的试卷！');
      return;
    }
    // 选择我的资源添加到课程目录下
    Api.StartCourses.saveCatalogResource({
      token, body: {
        CourseCatalogID: catalog.ID,
        CourseID: catalog.CourseID,
        CatalogResourceList: catalogResourceList
      }
    }).then(res => {
      if (res.Ret === 0) {
        const nextSelectedResource = [...selectedResource];
        res.Data.map(item => {
          nextSelectedResource.map(sr => {
            if (sr.ID === item.ResourceID) {
              sr.ID = item.ID;
              sr.ResourceID = item.ResourceID;
              sr.ResourceName = sr.Name;

              Reflect.deleteProperty(sr, 'Name')
            }
          });
        });

        onOk(!visible, nextSelectedResource);
        this.setState({rowSelection: {...rowSelection, selectedRowKeys: []}, selectedResource: []});
        message.success('添加成功！');
      } else {
        message.error(res.Msg)
      }
    });

  };
  handleCancel = () => {
    const {visible, onCancel} = this.props;
    onCancel(!visible)
  };

  // Table
  handleTableChange = (pagination, filters, sorter) => {
    const pager = {...this.state.pagination};
    pager.current = pagination.current;

    const {rowSelection, selectedResource} = this.state;
    this.setState({
      pagination: pager,
      rowSelection: {...rowSelection, selectedRowKeys: selectedResource.map(item => item.ID)}
    });

    this.getResource(pagination.current);
  };

  // 单项选择
  handleRowSelect = (record, selected, selectedRows) => {
    let {rowSelection, selectedResource} = this.state;
    let selectedRowKeys = rowSelection.selectedRowKeys;
    if (selected) {
      this.setState({
        selectedResource: [...selectedResource, record],
        rowSelection: {...rowSelection, selectedRowKeys: [...selectedRowKeys, record.ID]}
      });
    } else {
      selectedRowKeys = selectedRowKeys.filter(sk => sk !== record.ID);
      selectedResource = selectedResource.filter(sr => sr.ID !== record.ID);
      this.setState({rowSelection: {...rowSelection, selectedRowKeys}, selectedResource})
    }
  };

  // 表格当前页面全选
  handleRowSelectAll = (selected, selectedRows, changeRows) => {
    let {rowSelection, selectedResource} = this.state;
    let selectedRowKeys = rowSelection.selectedRowKeys;

    if (selected) {
      changeRows.map(item => {
        if (selectedRowKeys.findIndex(sk => sk === item.ID) < 0) selectedRowKeys.push(item.ID);
        if (selectedResource.findIndex(sr => sr.ID === item.ID) < 0) selectedResource.push(item)
      });
      this.setState({
        selectedResource: [...selectedResource],
        rowSelection: {...rowSelection, selectedRowKeys}
      });
    } else {
      changeRows.map(item => {
        selectedRowKeys = selectedRowKeys.filter(sk => sk !== item.ID);
        selectedResource = selectedResource.filter(sr => sr.ID !== item.ID);
      });
      this.setState({rowSelection: {...rowSelection, selectedRowKeys}, selectedResource})
    }
  };

  // 创建试卷
  handleCreateTestPaper = () => {
    const {location, history, catalog} = this.props;

/*    console.log({
      ...location.state,
      startCourse: {
        courseID: catalog.CourseID,
        catalogID: catalog.ID,
        step: 1,
        isAddExam: true,
        origin: location.pathname
      }
    })*/
    history.push({
      pathname: '/editor-test',
      state: {
        ...location.state,
        startCourse: {
          courseID: catalog.CourseID,
          catalogID: catalog.ID,
          step: 1,
          isAddExam: true,
          origin: location.pathname
        }
      }
    });
  };

  render() {
    const {visible} = this.props;
    const {dataResource, pagination, rowSelection, resourceLoading} = this.state;
    const operations = <Button icon="plus" onClick={this.handleCreateTestPaper}>创建试卷</Button>;
    return (
      <Modal
        title={<div><Icon type="file-text" style={{marginRight: 8}}/>添加试卷</div>}
        width={680}
        visible={visible}
        onCancel={this.handleCancel}
        maskClosable={false}
        footer={null}
      >
        <Tabs tabBarExtraContent={operations}>
          <TabPane tab="我的试卷" key="1">
            <Table rowKey="ID"
                   locale={{
                     emptyText: <span><Icon type="frown-o"/>没有可用试卷哦~！去<a onClick={this.handleCreateTestPaper}>创建试卷</a>？</span>
                   }}
                   columns={this.columns}
                   rowSelection={rowSelection}
                   dataSource={dataResource}
                   pagination={pagination}
                   onChange={this.handleTableChange}
                   loading={resourceLoading}
                   size="small"/>
            <div style={{textAlign: 'center'}}>
              {dataResource && dataResource.length ? <Button type="primary" onClick={this.handleOk}>确定</Button> : null}
              {/* <Button style={{marginLeft: 8}} onClick={this.handleReset}>重选</Button>*/}
            </div>
          </TabPane>
        </Tabs>

      </Modal>
    )
  }
}

export default ResourceModalExam;
