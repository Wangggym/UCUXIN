/**
 * Created by QiHan Wang on 2017/8/28.
 * SaveLecturer
 */


import React, {Component} from 'react';
import {withRouter} from 'react-router-dom'
import PropTypes from 'prop-types';
import moment from 'moment';
import {StorageService, Token, AppToken} from '../../../utils';
import Config from '../../../config';
import Api from '../../../api';

// -- AntDesign Components
import {
  Form,
  Input,
  InputNumber,
  Button,
  Icon,
  Radio,
  Checkbox,
  Cascader,
  Select,
  Upload,
  Modal,
  DatePicker,
  Switch,
  message
} from 'antd';

const FormItem = Form.Item;
const TextArea = Input.TextArea;
const RadioGroup = Radio.Group;
const CheckboxGroup = Checkbox.Group;
const RangePicker = DatePicker.RangePicker;


const dateFormat = 'YYYY-MM-DD';
const token = Token();


class BasicInfo extends Component {

  static propTypes = {
    submit: PropTypes.bool,
    onSubmit: PropTypes.func,
    onCtrlStepBar: PropTypes.func
  };

  constructor(props) {
    super(props);
    this.state = {
      nationalTrain: false,
      baseInfo: {},
      IsCharge: false, //课程费用是否收费
      isLimiteNum: false,  //设置参培人数
      RaidoIsLimiteNue: false  //限定人数按钮
    };
  }

  componentWillMount() {
    // 验证是否为国培计划
    const state = this.props.location.state;
    if (state && +state.offerCourse.trainPlanID) this.setState({nationalTrain: true});
  }

  componentDidMount() {
    this.getViewBasic().then(res => {

      this.setState({...res, cover: res.baseInfo && res.baseInfo.CoverImg});

      const {lecturerInfo, baseInfo, desPeopleList, trainPlan} = res;
      // 綁定專家介紹信息
      if (lecturerInfo) {
        this.props.form.setFieldsValue({
          lecturerIntro: lecturerInfo.Instro
        })
      }

      // 国培计划

      if (trainPlan) {
        this.props.form.setFieldsValue({
          credit: trainPlan.SumCredit,
          //crowds: (desPeopleList.filter(item => (+item.Value & trainPlan.DestPeople) > 0)).map(item => item.Value),
          crowds: trainPlan.DestPeople.filter(item => item.IsCheck).map(item => item.ID),
          trainNumber: trainPlan.QtyLimit,   // 参培人数限定 当为国培时只能修改为小于最初值
          mode: trainPlan.TeachWay.toString(),
          effectiveTime: [moment(trainPlan.TrainSDate, dateFormat), moment(trainPlan.TrainEDate, dateFormat)]
        });

        // 禁用参培人群对象
        desPeopleList.map(item => {
          item.disabled = false;
        });

        trainPlan.DestPeople.map(item => {
          if (!item.IsCheck) {
            item.disabled = true;
          }
        });
        this.setState({desPeopleList: trainPlan.DestPeople});
      }

      // 綁定課程數據
      if (baseInfo) {
        //有限定人数的时候，默认设置为可见（未修改trainPlan中的人数限定）
        if (baseInfo.QtyLimit && baseInfo.QtyLimit !== "0") {
          this.setState({
            isLimiteNum: true
          }, () => this.props.form.setFieldsValue(Object.assign({
            trainNumber: baseInfo.QtyLimit,   // 参培人数限定 当为国培时只能修改为小于最初值
          })))
        }
        //有课程费用的时候，默认设置为可见
        if (baseInfo.Price && baseInfo.Price !== 0) {
          this.setState({
            IsCharge: true
          }, () => this.props.form.setFieldsValue(Object.assign({
            price: baseInfo.Price,   // 参培人数限定 当为国培时只能修改为小于最初值
          })))
        }
        this.props.form.setFieldsValue(Object.assign({
          courseName: baseInfo.Name,
          mode: baseInfo.TeachWay.toString(),
          isExam: baseInfo.IsExam,
          cover: baseInfo.CoverImg,
          courseIntro: baseInfo.Instro,
          credit: baseInfo.Credit,
          //crowds: (desPeopleList.filter(item => (+item.Value & baseInfo.DestPeople) > 0)).map(item => item.Value),
          crowds: baseInfo.DestPeople.filter(item => item.IsCheck).map(item => item.ID),
          effectiveTime: [moment(baseInfo.SDate), moment(baseInfo.EDate)],
          lecturerIntro: baseInfo.LecturerInstro,

          //TrainPlanID: 0, // 培训计划编号 0-为自主课程 非0-关联的培训计划(国培)
        }, !trainPlan ? {
          courseType: baseInfo.CourseType.toString(),  // 课程类型 1-培训课程(国培) 2-专家讲座 3-名师课程
          // 非国培才有后面两字段
          price: baseInfo.Price,
          youCoin: baseInfo.YoungCoin,
          learnOrder: baseInfo.IsSortLearn,
        } : {}));

        this.setState({baseInfo});
      }

      // 需求变更
      // 变更时间：2017-11-01
      // 变更需求：所有类型课程类型的线下面授都不需要考试

      // 旧功能
      // 是否有考试功能  国培，省培与市培中线下面授不需要考试
      /*if ((trainPlan && (baseInfo && baseInfo.TeachWay === 3))) {
        this.props.onCtrlStepBar(false);
      } else {
        if (baseInfo) {
          this.props.onCtrlStepBar(baseInfo.IsExam);
        } else {
          this.props.onCtrlStepBar(true);
        }
      }*/
      // 新功能
      if ((baseInfo && baseInfo.TeachWay === 3) || (trainPlan && trainPlan.TeachWay === 3)) {
        this.props.onCtrlStepBar(false);
      } else {
        if (baseInfo) {
          if (baseInfo.TeachWay !== 3) this.props.onCtrlStepBar(baseInfo.IsExam);
        } else {
          this.props.onCtrlStepBar(true);
        }
      }
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.submit && nextProps.submit !== this.props.submit) {
      this.handleSubmit();
    }
  }

  // 数据获取完整后对数据处理
  handleAsyncData = (target) => {
    /*const result = new Proxy(target, {
      get: function (target, key, receiver) {
        if (target.Ret !== 0) {
          console.error(target.Msg)
        } else {
          return Reflect.get(target, key, receiver);
        }
      }
    });
    return result.Data;*/

    if (target.Ret === 0) {
      return target.Data;
    } else {
      console.error(target.Msg);
    }
  };

// 獲取頁面數據
  getViewBasic = async () => {
    const [teachWayList, courseTypeList, desPeopleList, lecturerInfo] = await Promise.all([
      Api.StartCourses.getTeachWayList({token}),    // 授課方式
      Api.StartCourses.getCourseTypeList({token}),  // 課程類型
      Api.StartCourses.getCrowd({token, mTypeID: 11, phase: 30010, isGetManager: false}),  // 適用對象
      Api.StartCourses.getLecturerInfo({token})     // 講師基本信息
    ]).catch(err => console.error(err));

    const viewData = {
      teachWayList: this.handleAsyncData(teachWayList) || [],
      courseTypeList: this.handleAsyncData(courseTypeList) || [],
      desPeopleList: this.handleAsyncData(desPeopleList) || [],
      lecturerInfo: this.handleAsyncData(lecturerInfo),
    };


    // 根据课程ID获取课程基本信息
    const {state} = this.props.location;
    if (state && +state.offerCourse.courseID) {
      //const baseInfo =  await this.getCourseBaseInfo(state.offerCourse.courseID);
      const baseInfo = await Api.StartCourses.getCourseBaseInfo({
        token,
        courseID: state.offerCourse.courseID
      }).catch(err => console.log(err));
      viewData.baseInfo = baseInfo.Ret === 0 ? baseInfo.Data : undefined;
    }

    // 获取培训计划信息
    if (state && +state.offerCourse.trainPlanID) {
      const trainPlan = await Api.StartCourses.getPlanSimple({
        token,
        planID: state.offerCourse.trainPlanID
      }).catch(err => console.log(err));

      viewData.trainPlan = trainPlan.Ret === 0 ? trainPlan.Data : undefined;
    }

    return viewData;
  };

// ===================================================================================================================
// 封面上传部分
// 封面上传前验证
  beforeUpload = (file) => {
    const mimeType = ['image/gif', 'image/png', 'image/jpeg', 'image/bmp', 'image/webp'];
    const isJPG = mimeType.includes(file.type);
    if (!isJPG) {
      message.error('您只能上传图片类型为jpg、png、bmp、webp、gif的图片');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('图片大小必须小于2M！');
    }
    return isJPG && isLt2M;
  };

  // 自定义封面上传
  handleCustomRequest = (options, callback) => {
    // 获取应用Token
    AppToken().then(res => {
      if (typeof res === 'string') {
        callback(options.file, res);
      } else {
        let token = res.Data.Token;
        StorageService('session').set('AppToken', token);
        Config.setToken({name: 'appToken', value: token});
        callback(options.file, token);
      }
    })
  };

// 上传封面
  handleUploadHeadPic = (file, token) => {
    const fd = new FormData();
    fd.append('filename', file);
    const attachmentStr = '{"Path": "youls","AttachType": 1, "ExtName": ".jpg","ResizeMode": 1,"SImgResizeMode": 2, "CreateThumb": true, "Width": 100, "Height": 100,"SHeight": 50,"SWidth": 50 }';
    this.setState({uploadPicLoading: true});
    Api.Base.upload({
      token,
      attachmentStr,
      body: fd
    }).then(res => {
      if (res.Ret === 0) {
        this.handleBase64(file, imageUrl => this.setState({cover: imageUrl}));
        this.props.form.setFieldsValue({cover: res.Data.Url});
      } else {
        message.error('上传失败！');
        this.props.form.setFieldsValue({cover: undefined});
      }
      this.setState({uploadPicLoading: false});
    })
  };
  // 将图像转为base64
  handleBase64 = (img, callback) => {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result));
    reader.readAsDataURL(img);
  };

  // 授课方式切换
  handleChangeMode = (e) => {
    // 需求变更
    // 变更时间：2017-11-01
    // 变更需求：所有类型课程类型的线下面授都不需要考试
    /*
     * 旧功能代码
    const {nationalTrain} = this.state;
    const mode = e.target.value;
    const isExam = !(mode === '3' && nationalTrain);
    if (isExam) {
      const selectedExam = this.props.form.getFieldValue('isExam');
      this.props.onCtrlStepBar(typeof selectedExam === 'undefined' ? true : selectedExam);
    } else {
      this.props.onCtrlStepBar(isExam);
    }*/

    //  新功能
    const mode = e.target.value;
    const isExam = !(mode === '3');
    switch (mode) {
      case "1":
        this.setState({isLimiteNum: false});
        break;
      case "2":
        this.setState({isLimiteNum: true});
        break;
      case "3":
        this.setState({isLimiteNum: true});
        break;
      default:
        this.setState({isLimiteNum: false})
    }
    if (isExam) {
      const selectedExam = this.props.form.getFieldValue('isExam');
      this.props.onCtrlStepBar(typeof selectedExam === 'undefined' ? true : selectedExam);
    } else {
      this.props.onCtrlStepBar(isExam);
    }

  };

// ===================================================================================================================
//  提交讲师信息
  handleSubmit = () => {
    const {location, form, onSubmit} = this.props;
    const {lecturerInfo, trainPlan, desPeopleList} = this.state;
    form.validateFields((err, values) => {
      if (!err) {
        // 更新人群选中状态
        desPeopleList.map(item => {
          item.IsCheck = false;
          values.crowds.map(cr => {
            if (cr === item.ID) item.IsCheck = true;
          })
        });

        Api.StartCourses.saveCourseInfo({
          token, body: {
            ID: location.state ? location.state.offerCourse.courseID : 0,
            Name: values.courseName,
            TeachWay: values.mode,
            IsExam: values.isExam || false,
            CoverImg: values.cover,
            Instro: values.courseIntro,
            Credit: values.credit,
            DestPeople: desPeopleList,
            SDate: moment(values.effectiveTime[0]).format(dateFormat),
            EDate: moment(values.effectiveTime[1]).format(dateFormat),

            LecturerID: lecturerInfo.ID,
            LecturerInstro: values.lecturerIntro,

            TrainPlanID: location.state ? location.state.offerCourse.trainPlanID : 0, // 培训计划编号 0-为自主课程 非0-关联的培训计划(国培)
            QtyLimit: values.trainNumber,        // 参培人数限定 当为国培时只能修改为小于最初值
            CourseType: values.courseType || 1,  // 课程类型 1-培训课程(国培) 2-专家讲座 3-名师课程

            // 非国培才有后面两字段
            Price: values.price || 0,
            YoungCoin: values.youCoin || 0,

            IsSortLearn: values.learnOrder,
            AreaID: trainPlan ? trainPlan.AreaID : 0  // 国培区域
          }
        }).then(res => {
          if (res.Ret === 0) {
            const {location, history} = this.props;
            if (location.state && location.state.offerCourse) {
              history.replace({
                state: {
                  offerCourse: {
                    ...location.state.offerCourse,
                    courseID: res.Data,
                    isExam: values.isExam,
                  }
                }
              })
            } else {
              history.replace({
                state: {
                  offerCourse: {
                    step: 0,
                    trainPlanID: '',
                    courseID: res.Data,
                    isExam: values.isExam,
                    origin: ''
                  }
                }
              });
            }
            onSubmit(true);
          } else {
            message.error(res.Msg);
            onSubmit(false);
          }
        })
      } else {
        message.error('请将表单填写完整！');
        onSubmit(false);
      }
    });
  };

  // ===  国培计划  ====================================================================================================
  renderIsExam = (formItemLayout, getFieldDecorator) => {
    const mode = this.props.form.getFieldValue('mode');

    // 需求变更
    // 变更时间：2017-11-01
    // 变更需求：所有类型课程类型的线下面授都不需要考试

    // 旧
    /*const {nationalTrain} = this.state;
    const isExam = !(mode === '3' &&  nationalTrain);*/

    // 新 移除国培验证
    const isExam = !(mode === '3');
    if (isExam) {
      return (
        <FormItem {...formItemLayout} label="是否考试">
          {getFieldDecorator(`isExam`, {initialValue: true, rules: [{required: true, message: '请选择是否需要考试'}]})(
            <RadioGroup onChange={(e) => {
              this.props.onCtrlStepBar(e.target.value);
            }}>
              <Radio value={true}>是</Radio>
              <Radio value={false}>否</Radio>
            </RadioGroup>
          )}
        </FormItem>
      )
    }
  };

  // 培训名称
  renderTrainNameField = (formItemLayout) => {
    const {nationalTrain, trainPlan} = this.state;
    if (nationalTrain) {
      return <FormItem {...formItemLayout} label={'培训名称'}>
        <span className="ant-form-text">{trainPlan && trainPlan.Name}</span>
      </FormItem>
    }
  };

  //是否收费
  changeIsCharge(e) {
    // if (!e.target.value) {
    //   this.props.form.setFieldsValue({
    //     "AccordingScore": 0,
    //     "AccordingTrain": 0,
    //   })
    // }
    this.setState({
      IsCharge: e.target.value
    })
  }

  //是否限制参陪人数
  changeisLimiteNum(e) {
    this.setState({isLimiteNum: e.target.value})
  }

  // 课程类型、费用、幼学币
  renderNotNationalTrainFields = (formItemLayout, getFieldDecorator) => {
    const {nationalTrain, courseTypeList} = this.state;
    if (!nationalTrain) {
      return (
        <div>
          <FormItem {...formItemLayout} label="课程类型">
            {getFieldDecorator(`courseType`, {rules: [{required: true, message: '请选择课程类型'}]})(
              <RadioGroup>
                {
                  courseTypeList &&
                  courseTypeList.map(item => <Radio value={item.Value} key={item.Value}>{item.Text}</Radio>)
                }
              </RadioGroup>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label={'课程费用'}>
            {getFieldDecorator(`IsCharge`, {rules: [{required: true}], initialValue: this.state.IsCharge})(
              <RadioGroup onChange={(e) => this.changeIsCharge(e)}>
                <Radio value={false}>免费</Radio>
                <Radio value={true}>收费</Radio>
              </RadioGroup>
            )}
          </FormItem>
          {
            this.state.IsCharge && <FormItem {...formItemLayout} label={'费用金额'}>
              {getFieldDecorator(`price`)(<InputNumber min={0} precision={2}
                                                       formatter={value => `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}/>)}
            </FormItem>
          }
          <FormItem {...formItemLayout} label={'幼学币'}>
            {getFieldDecorator(`youCoin`)(<InputNumber min={0}/>)}
          </FormItem>
        </div>
      )
    }
  };
//限制学习有效日期
  disabledRangeDate = (current) => {
    return current && current.valueOf() < Date.now() - 24 * 60 * 60 * 1000;
  };

  render() {
    const {getFieldDecorator, getFieldValue} = this.props.form;
    const {desPeopleList, teachWayList, cover, trainPlan, uploadPicLoading, baseInfo, nationalTrain} = this.state;
    const formItemLayout = {
      labelCol: {
        xs: {span: 24},
        sm: {span: 7},
      },
      wrapperCol: {
        xs: {span: 24},
        sm: {span: 10},
      },
    };

    return (
      <div className="lecturer">
        <Form layout="horizontal">
          {this.renderTrainNameField(formItemLayout, getFieldDecorator)}
          <FormItem {...formItemLayout} label={'课程名称'}>
            {getFieldDecorator(`courseName`, {rules: [{required: true, message: '请填写课程名称'}]})(<Input
              placeholder="请填写课程名称"/>)}
          </FormItem>
          <FormItem {...formItemLayout} label="授课方式">
            {getFieldDecorator(`mode`, {rules: [{required: true, message: '请选择授课方式'}]})(
              <RadioGroup onChange={this.handleChangeMode}>
                {
                  teachWayList &&
                  teachWayList.map(item =>
                    <Radio value={item.Value} key={item.Value}
                           disabled={(baseInfo.ID && +item.Value !== +getFieldValue('mode')) || (nationalTrain && +item.Value !== +getFieldValue('mode'))}>
                      {item.Text}
                    </Radio>)
                }
              </RadioGroup>
            )}
          </FormItem>
          {this.renderIsExam(formItemLayout, getFieldDecorator)}
          <FormItem
            {...formItemLayout}
            label="课程封面"
            extra="课程封面格式为jpg, png, gif, webp, bmp且大小不超过2M，画面清晰"
          >{getFieldDecorator(`cover`, {rules: [{required: true, message: '请上传课程封面'}]})(
            <Upload
              className="avatar-uploader"
              name="avatar"
              showUploadList={false}
              beforeUpload={this.beforeUpload}
              customRequest={(options) => this.handleCustomRequest(options, (file, token) => this.handleUploadHeadPic(file, token))}
              accept="image/gif,image/png,image/jpeg,image/bmp,image/webp"
            >
              {
                cover ?
                  <img src={cover} alt="" className="avatar"/> :
                  <div className="avatar-uploader-trigger"><Icon
                    type={uploadPicLoading ? 'loading' : 'plus'}/><br/>{uploadPicLoading ? '正在上传...' : '上传封面'}</div>
              }
            </Upload>
          )}
            {
              cover ? <Button onClick={() => {
                this.setState({cover: undefined})
              }} className="delet-img" size="small">删除<Icon type="delete"/></Button> : ""
            }
          </FormItem>
          <FormItem {...formItemLayout} label={'课程学分'}>
            {getFieldDecorator(`credit`, {
              rules: [{
                required: true,
                validator: (rule, value, callback) => {
                  if (value <= 0) {
                    callback('课程学分只能是大于0的正整数')
                  }
                  if (!value) {
                    callback('请填写课程学分')
                  }
                  callback();
                }
              }]
            })(
              <InputNumber min={0} precision={0}/>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label={'参培人数'} extra={trainPlan && `培训计划人数最多${trainPlan.QtyLimit}人`}>
            {/*{getFieldDecorator(`trainNumber`, {*/}
            {/*rules: [*/}
            {/*{required: true, message: '请填写参培人数'},*/}
            {/*{pattern: /^\d+$/, message: '参培人数应为正整数'}*/}
            {/*]*/}
            {/*})(*/}
            {/*<InputNumber min={0} max={trainPlan && trainPlan.QtyLimit}/>*/}
            {/*)}*/}

            {/*将参培人数设置为可选*/}

            {getFieldDecorator(`isLimiteNum`, {initialValue: this.state.isLimiteNum})(
              <RadioGroup onChange={(e) => this.changeisLimiteNum(e)}>
                <Radio disabled={this.state.isLimiteNum} value={false}>不限定</Radio>
                <Radio value={true}>限定</Radio>
              </RadioGroup>
            )}
          </FormItem>
          {
            this.state.isLimiteNum && <FormItem {...formItemLayout} label={'人数设定'}>
              {getFieldDecorator(`trainNumber`, {rules: [{required: true, message: '请填写限定人数'}]})(
                <InputNumber min={0} max={trainPlan && trainPlan.QtyLimit} precision={0}/>
              )}
            </FormItem>
          }

          <FormItem {...formItemLayout} label="适用对象">
            {getFieldDecorator(`crowds`, {rules: [{required: true, message: '请选择讲师身份'}]})(
              <CheckboxGroup>
                {
                  desPeopleList &&
                  desPeopleList.map(item => <Checkbox value={item.ID} key={item.ID}
                                                      disabled={item.disabled}>{item.Name}</Checkbox>)
                }
              </CheckboxGroup>
            )}
          </FormItem>

          {this.renderNotNationalTrainFields(formItemLayout, getFieldDecorator)}

          <FormItem {...formItemLayout} label={'学习顺序设置'}>
            <span className="ant-form-text">按照学习内容顺序进行学习</span>
            {getFieldDecorator(`learnOrder`, {initialValue: false, valuePropName: 'checked'})(<Switch/>)}
          </FormItem>
          <FormItem {...formItemLayout} label={'学习有效日期'}>
            {getFieldDecorator(`effectiveTime`, {rules: [{required: true, message: '请选择学习有效日期'}]})(
              <RangePicker disabledDate={this.disabledRangeDate} disabled={nationalTrain}/>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="课程简介">
            {getFieldDecorator(`courseIntro`, {rules: [{required: true, message: '请填写课程简介'}]})(<TextArea
              autosize={{minRows: 2, maxRows: 6}}
              placeholder="简要描述课程内容，便于用户做出购买决策"/>)}
          </FormItem>
          <FormItem {...formItemLayout} label="讲师简介">
            {getFieldDecorator(`lecturerIntro`)(<TextArea autosize={{minRows: 2, maxRows: 6}}/>)}
          </FormItem>
        </Form>
      </div>
    )
  }
}

export default Form.create()(BasicInfo)
