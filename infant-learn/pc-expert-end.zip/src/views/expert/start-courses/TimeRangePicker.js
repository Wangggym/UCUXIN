/**
 * Created by QiHan Wang on 2017/9/8.
 * TimeRangePicker
 */
import React, {Component} from 'react';
import moment from 'moment';
import {TimePicker} from 'antd';

class TimeRangePicker extends Component {
  constructor(props) {
    super(props);
    const value = this.props.value || {};
    this.state = {
      startTime: value.startTime || undefined,
      endTime: value.endTime || undefined,
    };
  }

  componentWillReceiveProps(nextProps) {
    // Should be a controlled component.
    if ('value' in nextProps) {
      const value = nextProps.value;
      if (value) {
        this.setState({...value});
      } else {
        this.setState({
          startTime: undefined,
          endTime: undefined,
        });
      }

    }
  }

  handleEndTimeChange = (endTime) => {
    if (!('value' in this.props)) {
      this.setState({endTime});
    }
    this.triggerChange({endTime});
  };
  handleStartTimeChange = (startTime) => {
    if (!('value' in this.props)) {
      this.setState({startTime});
    }
    this.triggerChange({startTime});
  };
  triggerChange = (changedValue) => {
    // Should provide an event to pass value to Form.
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(Object.assign({}, this.state, changedValue));
    }
  };

  // 时间可选区域控制
  range = (start, end) => {
    const result = [];
    for (let i = start; i < end; i++) {
      result.push(i);
    }
    return result;
  };

  disabledHours = () => {
    const {startTime} = this.state;
    const hours = this.range(0, 60);
    hours.splice(moment(startTime).hour());
    return hours;
  };

  disabledMinutes = (h) => {
    const {startTime} = this.state;
    if (h === moment(startTime).hour()) {
      return this.range(0, moment(startTime).minute());
    }
    return [];
  };
//控制直播时间在当前时间之后
  startisabledHours=()=>{
    let nowDate = new Date()
    let endHour=moment(nowDate).hour()
    const hours = this.range(0,endHour)
    return hours
  };
  startDisabledMinutes=()=>{
    let nowDate = new Date()
    let endMinute=moment(nowDate).minute()
    const minute = this.range(0,endMinute)
    return minute
  };
  render() {
    const {format} = this.props;
    const {startTime, endTime} = this.state;
    return (
      <div className="time-range-picker">
        <TimePicker
          value={startTime}
          format={format}
          placeholder="开始时间"
          disabledHours={this.startisabledHours}
          disabledMinutes={this.startDisabledMinutes}
          onChange={this.handleStartTimeChange}/>
        <span style={{margin: "0 8px"}}>~</span>
        <TimePicker
          value={endTime}
          format={format}
          placeholder="结束时间"
          onChange={this.handleEndTimeChange}
          disabledHours={this.disabledHours}
          disabledMinutes={this.disabledMinutes}
        />
      </div>
    )
  }
}

export default TimeRangePicker;
