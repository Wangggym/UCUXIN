/**
 * Created by QiHan Wang on 2017/8/30.
 * CourseContent
 */

import React, {Component} from 'react';
import {Token} from '../../../utils';
import Config from '../../../config';
import Api from '../../../api';
import './course-content.scss';

// -- Custom Component
import Catalog from './Catalog';                        // 目录操作
import Resource from './Resource';                      // 资源展示
import ResourceModalVideo from './ResourceModalVideo';  // 录播课程
import ResourceModalExam from './ResourceModalExam';    // 试卷资源
import ResourceModalFile from './ResourceModalFile';    // 文件资源
import ResourceModalLive from './ResourceModalLive';    // 在线直播
import ResourceModalFace from './ResourceModalFace';    // 线下面授

// -- Ant Design
import {
  Row,
  Col,
  Button,
  Input,
  Modal,
  message
} from 'antd';

const token = Token();

class CourseContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      courseData: {},
      courseID: '',
      examModalVisible: false,
      fileModalVisible: false,
      videoModalVisible: false,
      faceModalVisible: false,
      liveModalVisible: false,

      catalogSelected: undefined  // 添加资源的目录
    }
  }

  componentWillMount() {
    this.setState({courseID: this.props.location.state.offerCourse.courseID});
  }

  componentDidMount() {
    this.getCourse();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.submit && nextProps.submit !== this.props.submit) {
      this.handleSubmit();
    }
  }

  // 恢复试卷添加后回返状态
  updateBackInfo = () => {
    // 获取state信息 验证是否为回跳页面
    const {location} = this.props;
    const {courseData} = this.state;
    if (location.state) {
      const startCourse = location.state.startCourse;
      if (startCourse && startCourse.step === 1) {
        this.setState({
          examModalVisible: startCourse.isAddExam,
          resourceType: 'exam',
          catalogSelected: courseData.CourseCatalogs.filter(item => item.ID === startCourse.catalogID)[0]
        });
      }
    }
  };

  // 课程内容创建完成
  handleSubmit = () => {
    // 此处还需验证目录中内容是否为为与目录是否存在
    const {courseData} = this.state;
    const {CourseCatalogs} = courseData;
    const {onSubmit} = this.props;
    if (CourseCatalogs && CourseCatalogs.length) {
      const crdArr = [];
      CourseCatalogs.forEach(cc => {
        if (!(cc.CourseResourceDetails && cc.CourseResourceDetails.length)) {
          crdArr.push(cc.Name)
        }
      });
      // 判断目录是否
      if (crdArr.length) {
        message.error(<span>请为课程目录{crdArr.map((crd, i) => <b>{i > 0 ? '、' : ''}{crd}</b>)}添加资源！</span>);
        onSubmit(false);

      } else {
        // 下一步前先验证目前资源内容是否完整
        Api.StartCourses.validateCourse({token, courseID: courseData.ID}).then(res=> {
          if(res.Ret === 0){
            if(!courseData.IsExam){
              Api.StartCourses.updateCourseStatus({token, courseID: courseData.ID}).then(res=> {
                if(res.Ret === 0){
                  onSubmit(true);
                }else{
                  message.error(res.Msg);
                  onSubmit(false);
                }
              });
            }else{
              onSubmit(true);
            }
          }else{
            message.error(res.Msg);
            onSubmit(false);
          }
        });
      }
    } else {
      message.error('请添加课程目录！');
      onSubmit(false);
    }
  };

  // 根据课程ID获取课程信息
  getCourse = () => {
    Api.StartCourses.getCourse({token, courseID: this.state.courseID}).then(res => {
      if (res.Ret === 0) {
        this.setState({courseData: res.Data}, this.updateBackInfo);

        // 更新步骤状态
        this.props.onCtrlStepBar(res.Data.IsExam);
      } else {
        message.error(res.Msg)
      }
    });
  };

  // 目录相关
  // 新增修改课程目录
  saveCourseCatalog = () => {
    Api.StartCourses.saveCourseCatalog({token, body: {}}).then(res => {
      if (res.Ret === 0) {
        message.error('目录添加成功！');
      } else {
        message.error(res.Msg)
      }
    })
  };

  // 新增目录结构
  handleAddCatalog = () => {
    const catalog = {
      ID: 0,
      CourseID: this.state.courseID,
      Name: undefined,
      PID: 0,
      Level: 1,
      Sort: 0,
      edit: true
    };
    let {CourseCatalogs} = this.state.courseData;
    if (Array.isArray(CourseCatalogs) && CourseCatalogs.length) {
      catalog.Name = `${CourseCatalogs.length + 1}.`;
      catalog.Sort = CourseCatalogs[CourseCatalogs.length - 1].Sort + 1;
      CourseCatalogs.push(catalog);
    } else {
      catalog.Name = '1.';
      catalog.Sort = 1;
      CourseCatalogs = [catalog];
    }
    this.setState({
      courseData: {...this.state.courseData, CourseCatalogs}
    })
  };

  // 目录信息更新
  handleUpdateCatalog = (data, index) => {
    const {courseData} = this.state;
    if (data && data.ID) {
      this.setState({
        courseData: {
          ...courseData, CourseCatalogs: [
            ...courseData.CourseCatalogs.slice(0, index),
            data,
            ...courseData.CourseCatalogs.slice(index + 1)
          ]
        }
      })
    } else {
      this.setState({
        courseData: {
          ...courseData, CourseCatalogs: [
            ...courseData.CourseCatalogs.slice(0, index),
            ...courseData.CourseCatalogs.slice(index + 1)
          ]
        }
      })
    }

  };
  // ===================================================================================================================

  // 资源相关 删除及更新资源，功能与目前新增编辑类似
  handleUpdateResource = (data, cIndex, rIndex) => {
    // data 为空则为删除数据
    const {courseData} = this.state;
    if (!data) {
      // 删除资源
      const selectedCatalog = courseData.CourseCatalogs[cIndex];
      selectedCatalog.CourseResourceDetails = [
        ...selectedCatalog.CourseResourceDetails.slice(0, rIndex),
        ...selectedCatalog.CourseResourceDetails.slice(rIndex + 1),
      ];
      courseData.CourseCatalogs = [
        ...courseData.CourseCatalogs.slice(0, cIndex),
        selectedCatalog,
        ...courseData.CourseCatalogs.slice(cIndex + 1),
      ];
      this.setState({courseData});
    }
  };

  // ===================================================================================================================
  // 添加资源（试卷 || 文件 || 视频）
  handleAddResource = (type, data) => this.setState({
    [`${type}ModalVisible`]: true,
    resourceType: type,
    catalogSelected: data
  });

  // 资源添加成功后数据更新（试卷 || 文件 || 视频）
  handleChangeCatalogResource = (visible, selectedOptions) => {
    //console.log(selectedOptions)
    const {courseData, catalogSelected, resourceType} = this.state;

    // 更新资源数据
    if (catalogSelected.CourseResourceDetails && Array.isArray(catalogSelected.CourseResourceDetails)) {
      selectedOptions.map(item => {
        const index = catalogSelected.CourseResourceDetails.findIndex(cd => cd.ID === item.ID);
        if (index >= 0) {
          catalogSelected.CourseResourceDetails = [
            ...catalogSelected.CourseResourceDetails.slice(0, index),
            item,
            ...catalogSelected.CourseResourceDetails.slice(index + 1),
          ]
        } else {
          catalogSelected.CourseResourceDetails.push(item)
        }
      });
    } else {
      catalogSelected.CourseResourceDetails = selectedOptions;
    }


    // 更新目录数据
    const cIndex = courseData.CourseCatalogs.findIndex(item => item.ID === catalogSelected.ID);

    if (cIndex >= 0) {
      courseData.CourseCatalogs = [
        ...courseData.CourseCatalogs.slice(0, cIndex),
        catalogSelected,
        ...courseData.CourseCatalogs.slice(cIndex + 1),
      ]
    } else {
      courseData.CourseCatalogs.push(catalogSelected)
    }

    this.setState({
      [`${resourceType}ModalVisible`]: visible,
      courseData
    });

    // 移出当前条目状态值
    this.handleClearStartCourse();
  };

  // 资源添加取消（试卷 || 文件 || 视频）
  handleCancelAddResource = (visible) => {
    // 关闭弹出层
    const {resourceType} = this.state;
    this.setState({[`${resourceType}ModalVisible`]: visible});

    // 移出当前条目状态值
    this.handleClearStartCourse();
  };

  // 清除开课程的创建试卷记录
  handleClearStartCourse = () => {
    const {location, history} = this.props;
    const {state} = location;
    if (state && state.startCourse) {
      Reflect.deleteProperty(state, 'startCourse');
      history.replace({state})
    }
  };

  // 生成预览
  renderPreview = () => {
    const {location} = this.props;
    if (location.state && location.state.offerCourse) {
      return(
        <Modal width={407} visible={this.props.previewVisible} footer={null} onCancel={this.props.onCancelPreview}>
          <iframe style={{width: 375, height: 667, border: 0, overflow: 'hidden'}}
                  src={`${Config.ownerAddress}InLeSpa/course-detail/${this.props.location.state.offerCourse.courseID}?preview=pc&token=${Token()}`}/>
        </Modal>
      )
    }
  };

  render() {
    const {courseData, examModalVisible, fileModalVisible, videoModalVisible, liveModalVisible, faceModalVisible, catalogSelected} = this.state;
    return (
      <div className="course-content">
        {/* 课程信息介绍 */}
        <header className="course-header">
          <Row>
            <Col span={18}>
              <div className="course-pic" style={{backgroundImage: `url(${courseData.CoverImg})`}}><img
                src={courseData.CoverImg} alt=""/></div>
              <h3 className="course-name">{courseData.Name}</h3>
              <div className="course-basic-info">
                <span>共有<b>{courseData.CourseCatalogs ? courseData.CourseCatalogs.length : 0}</b>节课</span><span>学分：{courseData.Credit}</span><span>讲师：{courseData.LecturerName || '未知'}</span>
              </div>
              <div className="course-basic-desc">{courseData.Instro}</div>
            </Col>
            <Col span={6}>
              <Button icon="plus" className="course-add-catalog" onClick={this.handleAddCatalog}>添加目录</Button>
            </Col>
          </Row>
          <div className="course-desc">点击<b>【+课程目录】</b>，创建课程目录。
          </div>
          {/*<div className="course-desc">点击<b>【+课程目录】</b>，你可以按照 <b>“章 > 节 > 课时”</b>
            的结构创建课程目录，可以根据需要自由设置，也可以不设置目录结构。拖动章节标题可以移位置
          </div>*/}
        </header>

        {/* 目录 资源 */}
        <div className="course-catalog course-list bordered">
          {
            courseData.CourseCatalogs &&
            courseData.CourseCatalogs.map((catalog, ci) =>
              <div className="course-list-item" key={catalog.ID + ci}>
                <Catalog
                  type={courseData.TeachWay}
                  data={catalog}
                  onChange={(data) => this.handleUpdateCatalog(data, ci)}
                  onAddVideo={() => this.handleAddResource('video', catalog)}
                  onAddFile={() => this.handleAddResource('file', catalog)}
                  onAddExam={() => this.handleAddResource('exam', catalog)}
                  onAddFace={() => this.handleAddResource('face', catalog)}
                  onAddLive={() => this.handleAddResource('live', catalog)}
                />
                <div className="course-list">
                  {
                    catalog.CourseResourceDetails &&
                    catalog.CourseResourceDetails.map((cr, ri) =>
                      <Resource
                        key={cr.ID + ri}
                        data={cr}
                        onChange={(data) => this.handleUpdateResource(data, ci, ri)}
                      />
                    )
                  }
                </div>
              </div>)
          }
        </div>

        {/* 添加试卷 */}
        <ResourceModalExam
          visible={examModalVisible}
          onOk={this.handleChangeCatalogResource}
          onCancel={this.handleCancelAddResource}
          catalog={catalogSelected}
          history={this.props.history}
          location={this.props.location}
        />
        {/* 添加视频 */}
        <ResourceModalVideo
          visible={videoModalVisible}
          onOk={this.handleChangeCatalogResource}
          onCancel={this.handleCancelAddResource}
          catalog={catalogSelected}
        />
        {/* 添加文档 */}
        <ResourceModalFile
          visible={fileModalVisible}
          onOk={this.handleChangeCatalogResource}
          onCancel={this.handleCancelAddResource}
          catalog={catalogSelected}
        />

        {/* 在线直播 */}
        <ResourceModalLive
          visible={liveModalVisible}
          onOk={this.handleChangeCatalogResource}
          onCancel={this.handleCancelAddResource}
          catalog={catalogSelected}
        />

        {/* 线下面授 */}
        <ResourceModalFace
          visible={faceModalVisible}
          onOk={this.handleChangeCatalogResource}
          onCancel={this.handleCancelAddResource}
          catalog={catalogSelected}
        />
        {/* 预览 */}
        {this.renderPreview()}

      </div>
    )
  }
}

export default CourseContent;
