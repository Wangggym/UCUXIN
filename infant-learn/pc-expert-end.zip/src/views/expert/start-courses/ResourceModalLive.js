/**
 * Created by QiHan Wang on 2017/9/8.
 * ResourceModalFile
 */

import React, {Component} from 'react';
import moment from 'moment';
import {Token} from '../../../utils';
import Api from '../../../api';

import TimeRangePicker from './TimeRangePicker';
// -- Ant Design
import {
  Button,
  Form,
  Input,
  Modal,
  DatePicker,
  Icon,
  message
} from 'antd';

const FormItem = Form.Item;
const TextArea = Input.TextArea;

const token = Token();

class ResourceModalFile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isSubmit: false
    };

  }

  // 添加选中资源到目录下
  handleOk = () => {
    const {visible, onOk, catalog} = this.props;
    this.props.form.validateFields((err, value) => {
      if (err) {
        message.error('请将表单填写完整！');
        return;
      }
      const body = {
        ID: 0,
        CourseCatalogID: catalog.ID,
        Name: value.name,
        SDate: [moment(value.date).format('YYYY-MM-DD'), moment(value.time.startTime).format('HH:mm:ss')].join(' '),
        EDate: [moment(value.date).format('YYYY-MM-DD'), moment(value.time.endTime).format('HH:mm:ss')].join(' '),
        Desc: value.desc,
      };

      this.setState({isSubmit: true});
      Api.StartCourses.saveResourceLive({token, body}).then(res => {
        if (res.Ret === 0) {

          body.ResourceName = body.Name;
          Reflect.deleteProperty(body, 'Name');
          Reflect.deleteProperty(body, 'Desc');

          onOk(!visible, [{...body, ID: res.Data, ResourceType: 3}]);
          message.success('添加成功！');

          this.props.form.resetFields();
        } else {
          message.error(res.Msg);
        }
        this.setState({isSubmit: false});
      });
    })
  };
  handleCancel = () => {
    const {visible, onCancel} = this.props;
    onCancel(!visible)
  };

  render() {
    const {visible} = this.props;
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: {span: 24},
        sm: {span: 6},
      },
      wrapperCol: {
        xs: {span: 24},
        sm: {span: 14},
      },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        xs: {
          span: 24,
          offset: 0,
        },
        sm: {
          span: 14,
          offset: 6,
        },
      },
    };
    const format = 'HH:mm';
    return (
      <Modal
        title={<div><Icon type="laptop" style={{marginRight: 8}}/>发布直播信息</div>}
        width={680}
        visible={visible}
        onCancel={this.handleCancel}
        maskClosable={false}
        footer={null}
      >
        <Form>
          <FormItem{...formItemLayout} label="名称">
            {getFieldDecorator('name', {rules: [{required: true, message: '请填写直播名称'}]})(
              <Input placeholder="名称"/>
            )}
          </FormItem>
          <FormItem{...formItemLayout} label="直播日期">
            {getFieldDecorator('date', {rules: [{required: true, message: '请选择直播日期'}]})(
              <DatePicker disabledDate={(current) => current && current.valueOf() < moment().subtract(1, 'days')}/>
            )}
          </FormItem>
          <FormItem{...formItemLayout} label="直播时间">
            {getFieldDecorator('time', {
              rules: [{
                required: true, message: '请选择直播时间', validator: (rule, value, callback) => {
                  if (value && value.startTime && value.endTime) {
                    callback();
                    return;
                  }
                  if (value) {
                    if (!value.startTime) rule.message = '请选择直播开始时间';
                    if (!value.endTime) rule.message = '请选择直播结束时间';
                  }
                  callback('请选择直播时间');
                }
              }]
            })(
              <TimeRangePicker format={format}/>
            )}
          </FormItem>
          <FormItem{...formItemLayout} label="描述">
            {getFieldDecorator('desc', {rules: [{required: true, message: '请填写直播描述'}]})(
              <TextArea placeholder="描述" autosize={{ minRows: 2, maxRows: 6 }}/>
            )}
          </FormItem>
          <FormItem {...tailFormItemLayout}>
            <Button type="primary" loading={this.state.isSubmit} onClick={this.handleOk}>确定</Button>
          </FormItem>
        </Form>
      </Modal>
    )
  }
}

export default Form.create()(ResourceModalFile);
