/**
 * Created by QiHan Wang on 2017/8/31.
 * Catalog
 */
import React, {Component} from 'react';
import PropTypes from 'prop-types'

import {Token} from '../../../utils';
import Api from '../../../api';

// -- Ant Design
import {
  Row,
  Col,
  Button,
  Tooltip,
  Input,
  Popconfirm,
  message
} from 'antd';

const token = Token();

export default class Catalog extends Component {
  static defaultProps = {
    catalog: {},
    type: 1,
    onAddVideo() {
    },
    onAddLive() {
    },
    onAddFile() {
    },
    onAddExam() {
    },
    onAddFace() {
    }
  }

  static propTypes = {
    catalog: PropTypes.object,
    type: PropTypes.number,
    onAddVideo: PropTypes.func,
    onAddLive: PropTypes.func,
    onAddFile: PropTypes.func,
    onAddExam: PropTypes.func,
    onAddFace: PropTypes.func,
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  componentWillMount() {
    this.setState({catalog: this.props.data, cacheCatalog: {...this.props.data}})
  }

  // 保存
  handleSave = () => {
    const {catalog} = this.state;
    if(catalog.Name.length > 30){
      message.error('目录名称最多30个字符！');
      return;
    }
    Api.StartCourses.saveCourseCatalog({token, body: catalog}).then(res => {
      if (res.Ret === 0) {
        // 调取保存接口
        catalog.edit = false;
        catalog.ID = res.Data;
        this.setState({catalog});
        this.props.onChange(catalog)
      } else {
        message.error(res.Msg)
      }
    })

  };
  // 取消
  handleCancel = () => {
    const {cacheCatalog} = this.state;
    cacheCatalog.edit = false;
    this.setState({catalog: cacheCatalog});
    this.props.onChange(cacheCatalog);
  };
  // 删除目录
  handleDel = () => {
    Api.StartCourses.delCourseCatalog({token, courseCatalogID: this.state.catalog.ID}).then(res => {
      if (res.Ret === 0) {
        this.props.onChange();
      } else {
        message.error(res.Msg)
      }
    })
  };

  // 编辑目录
  handleEdit = () => {
    const {catalog} = this.state;
    this.setState({catalog: {...catalog, edit: true}, cacheCatalog: {...catalog}})
  };

  // 修改目录名称
  handleChangeName = (e) => {
    this.setState({catalog: {...this.state.catalog, Name: e.target.value}});
  };

  handlerTeachWay = () => {
    const {type, onAddVideo, onAddLive, onAddFace} = this.props;
    switch (type) {
      case 2:
        return <Tooltip title="发布直播信息"><Button icon="laptop" size="small" onClick={onAddLive}/></Tooltip>;
      case 3:
        return <Tooltip title="发布上课信息"><Button icon="schedule" size="small" onClick={onAddFace}/></Tooltip>;
      case 1:
      default:
        return <Tooltip title="视频"><Button icon="video-camera" size="small" onClick={onAddVideo}/></Tooltip>;
    }
  };


  render() {
    const {catalog} = this.state;
    const {onAddFile, onAddExam} = this.props;
    return (
      <div className="course-list-item">
        <div className="course-list-hd">目录名称：</div>
        <div className="course-list-bd">
          {
            catalog.edit ?
              <Input defaultValue={catalog.Name} onChange={this.handleChangeName}/> : catalog.Name
          }
        </div>
        <div className="course-list-ft">
          <div className="course-list-opr">
            {
              catalog.edit ?
                <div style={{display: 'inline'}}>
                  <Tooltip title="保存"><Button icon="save" size="small" onClick={this.handleSave}/></Tooltip>
                  <span className="ant-divider"/>
                  <Tooltip title="取消"><Button icon="close-circle-o" size="small" onClick={this.handleCancel}/></Tooltip>
                </div> :
                <div style={{display: 'inline'}}>
                  {this.handlerTeachWay()}
                  < span className="ant-divider"/>
                  <Tooltip title="试卷"><Button icon="file-text" size="small" title="试卷"
                                                  onClick={onAddExam}/></Tooltip>
                  <span className="ant-divider"/>
                  <Tooltip title="文件"><Button icon="paper-clip" size="small" title="文件"
                                                  onClick={onAddFile}/></Tooltip>
                  <span className="ant-divider"/>
                  <Tooltip title="编辑"><Button icon="edit" size="small" onClick={this.handleEdit}/></Tooltip>
                </div>
            }
            {
              catalog.ID ?
                <div style={{display: 'inline'}}>
                  <span className="ant-divider"/>
                  <Popconfirm title="确定要删除该条目录吗？" onConfirm={this.handleDel} okText="确定" cancelText="取消">
                    <Tooltip title="删除"><Button icon="delete" size="small" type="danger"/></Tooltip>
                  </Popconfirm>
                </div>
                : null
            }
          </div>
        </div>
      </div>
    )
  }
}
