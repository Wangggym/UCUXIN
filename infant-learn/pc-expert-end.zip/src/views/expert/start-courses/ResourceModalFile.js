/**
 * Created by QiHan Wang on 2017/8/31.
 * ResourceModal
 */

import React, {Component} from 'react';
import {Token} from '../../../utils';
import oss from '../../../utils/oss/';
import Api from '../../../api';

// -- Ant Design
import {
  Row,
  Col,
  Button,
  Form,
  Input,
  Modal,
  Table,
  Upload,
  Icon,
  Tabs,
  message
} from 'antd';

const FormItem = Form.Item;
const TextArea = Input.TextArea;
const TabPane = Tabs.TabPane;
const token = Token();

const videoFormat = ['webm', 'mp4', 'ogg', 'avi', 'rmvb', 'rm', 'asf', 'divx', 'mpg', 'mpeg', 'mpe', 'wmv', 'mkv', 'vob'];

class ResourceModalFile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 10
      },
      resourceLoading: false,
      dataResource: [],
      selectedResource: [],
      rowSelection: {
        selectedRowKeys: [],
        onSelect: this.handleRowSelect,
        onSelectAll: this.handleRowSelectAll,
      },
      activeKey: "1",

      uploading: false,
      fileList: [],
    };

    this.columns = [
      {
        title: '名称',
        dataIndex: 'Name',
        width: '40%'
      },
      {
        title: '大小',
        dataIndex: 'Size',
        width: '30%',
        render: text => `${(+text / Math.pow(1024,2)).toFixed(2)}M`
      },
      {
        title:'类型',
        dataIndex:'SuffixName',
        width: '30%',
      }
    ];
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.visible && nextProps.visible !== this.props.visible) {
      this.getResourceFile(1);
    }
  }

  // 获取视频资源
  getResourceFile = (page) => {
    const {pagination} = this.state;
    this.setState({resourceLoading: true});
    Api.StartCourses.getMyResource({
      token,
      type: 1,
      pIndex: page || pagination.current,
      pSize: pagination.pageSize
    }).then(res => {
      let dataResource;
      if (res.Ret === 0) {
        const {PageIndex, TotalRecords, ViewModelList} = res.Data;
        pagination.current = PageIndex;
        pagination.total = TotalRecords;
        dataResource = ViewModelList;
      } else {
        message.error(res.Msg)
      }
      this.setState({resourceLoading: false, pagination, dataResource: dataResource ? dataResource : []});
    });
  }

  // 添加选中资源到目录下
  handleOk = () => {
    const {visible, onOk, catalog} = this.props;
    const {selectedResource, rowSelection} = this.state;
    const catalogResourceList = [];
    // 重组提交数据modal
    selectedResource.map(item => {
      catalogResourceList.push({
        ID: 0,
        ResourceID: item.ID,
        CourseCatalogID: catalog.ID
      })
    });
    //onOk(!visible, selectedResource);

    if (!selectedResource.length) {
      message.error('请先选择要添加的文件！');
      return;
    }
    // 选择我的资源添加到课程目录下
    Api.StartCourses.saveCatalogResource({
      token, body: {
        CourseCatalogID: catalog.ID,
        CourseID: catalog.CourseID,
        CatalogResourceList: catalogResourceList
      }
    }).then(res => {
      if (res.Ret === 0) {
        const nextSelectedResource = [...selectedResource];
        res.Data.map(item => {
          nextSelectedResource.map(sr => {
            if (sr.ID === item.ResourceID) {
              sr.ID = item.ID;
              sr.ResourceID = item.ResourceID;
              sr.ResourceName = sr.Name;

              Reflect.deleteProperty(sr, 'Name')
            }
          });
        });

        onOk(!visible, nextSelectedResource);
        this.setState({rowSelection: {...rowSelection, selectedRowKeys: []}, selectedResource: []});
        message.success('添加成功！');
      } else {
        message.error(res.Msg)
      }
    });

  };
  handleCancel = () => {
    const {visible, onCancel} = this.props;
    onCancel(!visible)
  };

  // Table
  handleTableChange = (pagination, filters, sorter) => {
    const pager = {...this.state.pagination};
    pager.current = pagination.current;

    const {rowSelection, selectedResource} = this.state;
    this.setState({
      pagination: pager,
      rowSelection: {...rowSelection, selectedRowKeys: selectedResource.map(item => item.ID)}
    });
    this.getResourceFile(pagination.current);
  };

  // 单项选择
  handleRowSelect = (record, selected, selectedRows) => {
    let {rowSelection, selectedResource} = this.state;
    let selectedRowKeys = rowSelection.selectedRowKeys;
    if (selected) {
      this.setState({
        selectedResource: [...selectedResource, record],
        rowSelection: {...rowSelection, selectedRowKeys: [...selectedRowKeys, record.ID]}
      });
    } else {
      selectedRowKeys = selectedRowKeys.filter(sk => sk !== record.ID);
      selectedResource = selectedResource.filter(sr => sr.ID !== record.ID);
      this.setState({rowSelection: {...rowSelection, selectedRowKeys}, selectedResource});
    }
  };

  // 表格当前页面全选
  handleRowSelectAll = (selected, selectedRows, changeRows) => {
    let {rowSelection, selectedResource} = this.state;
    let selectedRowKeys = rowSelection.selectedRowKeys;

    if (selected) {
      changeRows.map(item => {
        if (selectedRowKeys.findIndex(sk => sk === item.ID) < 0) selectedRowKeys.push(item.ID);
        if (selectedResource.findIndex(sr => sr.ID === item.ID) < 0) selectedResource.push(item);
      });
      this.setState({
        selectedResource: [...selectedResource],
        rowSelection: {...rowSelection, selectedRowKeys}
      });
    } else {
      changeRows.map(item => {
        selectedRowKeys = selectedRowKeys.filter(sk => sk !== item.ID);
        selectedResource = selectedResource.filter(sr => sr.ID !== item.ID);
      });
      this.setState({rowSelection: {...rowSelection, selectedRowKeys}, selectedResource})
    }
  };

  // 上传文件类型检测
  beforeUpload = (file) => {
    const isVideo = videoFormat.includes(file.name.slice(file.name.lastIndexOf('.') + 1).toLowerCase());
    if (isVideo) {
      message.error(`请选择非视频文件`);
    }
    const isLtSize = file.size / 1024 / 1024 < 50;
    if (!isLtSize) {
      message.error('上传文件最大不能超过50M！');
    }
    return !isVideo && isLtSize;
  };

  // 文件上传组件值更新时
  handleUploadChange = (info) => {
    let fileList = info.fileList;

    // 1. Limit the number of uploaded files
    //    Only to show two recent uploaded files, and old ones will be replaced by the new
    fileList = fileList.slice(-1);

    // 2. read from response and show file link
    fileList = fileList.map((file) => {
      if (file.response) {
        // Component will show file.url as link
        file.url = file.response.url;
      }
      return file;
    });

    // 3. filter successfully uploaded files according to response from server
    fileList = fileList.filter((file) => {
      if (file.response) {
        return file.response.res.status === 200;
      }
      return true;
    });
    this.setState({fileList});
  };

  // 文件组件自定义上传
  handleCustomRequest = (options) => oss.ali.uploader(options.file, 'k12', options);

  handleUpload = () => {
    const {onOk, form, visible} = this.props;
    form.validateFields((err, values) => {
      const {catalog} = this.props;
      const file = this.state.fileList.slice(-1)[0];
      if (err) {
        message.error('请将表单填写完整！');
        return
      }
      this.setState({uploading: true});

      const body = {
        ID: 0,
        SuffixName: file.name.slice(file.name.lastIndexOf('.') + 1).toLowerCase(),
        Url: file.url,
        Length: file.size,
        Type: 1,
        Name: values.name,
        Desc: values.description,
        CourseCatalogID: catalog.ID,
      };

      Api.StartCourses.saveResourceFile({token, body}).then(res => {
        if (res.Ret === 0) {
          message.success('上传成功！');
          onOk(!visible, [{...body, ID: res.Data, ResourceName: body.Name, ResourceType: 1, Size: body.Length}]);
          this.props.form.resetFields();
          this.setState({fileList:[]});
        } else {
          message.error(res.Msg);
        }
        this.setState({uploading: false});
      })
    })
  };

  render() {
    const {visible} = this.props;
    const {dataResource, pagination, rowSelection, resourceLoading, fileList, uploading} = this.state;
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: {span: 24},
        sm: {span: 6},
      },
      wrapperCol: {
        xs: {span: 24},
        sm: {span: 14},
      },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        xs: {
          span: 24,
          offset: 0,
        },
        sm: {
          span: 14,
          offset: 6,
        },
      },
    };
    return (
      <Modal
        title={<div><Icon type="paper-clip" style={{marginRight: 8}}/>添加文件</div>}
        width={680}
        visible={visible}
        onCancel={this.handleCancel}
        maskClosable={false}
        footer={null}
      >
        <Tabs activeKey={this.state.activeKey} onChange={(activeKey) => this.setState({activeKey})}>
          <TabPane tab="我的文件" key="1">
            {
              <Table
                locale={{
                  emptyText: <span><Icon type="frown-o"/>暂时没有可用文件哦~！去<a onClick={() => this.setState({activeKey: '2'})}>上传文件</a>？</span>
                }}
                rowKey="ID"
                columns={this.columns}
                rowSelection={rowSelection}
                dataSource={dataResource}
                pagination={pagination}
                loading={resourceLoading}
                onChange={this.handleTableChange}
                size="small"/>
            }
            <div style={{textAlign:'center'}}>
              {dataResource && dataResource.length ? <Button type="primary" onClick={this.handleOk}>确定</Button> : null}
              {/* <Button style={{marginLeft: 8}} onClick={this.handleReset}>重选</Button>*/}
            </div>
          </TabPane>
          <TabPane tab="上传本地文件" key="2">
            <Form>
              <FormItem {...formItemLayout} label="文件名称" hasFeedback>
                {getFieldDecorator('name', {rules: [{required: true, message: '请填写文件名称！'}]})(
                  <Input/>
                )}
              </FormItem>
              <FormItem {...formItemLayout} label="文件描述" hasFeedback>
                {getFieldDecorator('description', {rules: [{required: true, message: '请填写文件描述信息！'}]})(
                  <TextArea/>
                )}
              </FormItem>
              <FormItem {...formItemLayout} label="上传文件" extra="请选择小于50M的非视频文件">
                {getFieldDecorator('file', {rules: [{required: true, message: '请上传文件！'}]})(
                  <Upload
                    name='file'
                    onChange={this.handleUploadChange}
                    customRequest={this.handleCustomRequest}
                    beforeUpload={this.beforeUpload}
                    fileList={fileList}
                  >
                    <Button><Icon type="upload"/> 点击上传</Button>
                  </Upload>
                )}
              </FormItem>
              <FormItem {...tailFormItemLayout}>
                <Button type="primary"
                        onClick={this.handleUpload}
                        loading={uploading}
                >{uploading ? '上传中...' : '开始上传'}</Button>
              </FormItem>
            </Form>
          </TabPane>
          {/*<TabPane tab="上传网络文件" key="3">网络资源上传</TabPane>*/}
        </Tabs>
      </Modal>
    )
  }
}

export default Form.create()(ResourceModalFile);
