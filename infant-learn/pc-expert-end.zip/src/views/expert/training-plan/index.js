/**
 * Created by xj on 2017/8/30.
 */
import React, {Component} from "react";
import {withRouter} from 'react-router-dom';
import {Form, Input, Button, Select, DatePicker, Table, message, Modal, Row, Col} from 'antd';
import moment from 'moment';
import Api from '../../../api';
import {Token} from "../../../utils";
import './training-plan.scss';

const FormItem = Form.Item;
const Option = Select.Option;
const Search = Input.Search;
const {RangePicker} = DatePicker;

const dateFormat = 'YYYY-MM-DD';

const token = Token();

class TrainingPlan extends Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,//模态框显示
      loading: false,
      dataSource: {
        ViewModelList: []
      },
      pagination: {pageSize: 10, current: 1},
      queryFields: {
        ST: 0,    //计划状态
        name: "",//计划名称
        eDate: moment(new Date()).format("YYYY-MM-DD"), //公告开始日期（默认当前年的第一天）
        sDate: moment(new Date(new Date().getFullYear(), 0, 1)).format("YYYY-MM-DD"),//公告结束日期（默认当前日期）
      },
      DetailData: {},//查看详情
    }
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',

      },
      {
        title: '培训名称',
        dataIndex: 'Name',

      },
      {
        title: '适用角色',
        dataIndex: 'DestPeople',

      },
      {
        title: '授课讲师',
        dataIndex: 'QtyLecturer',

      },
      {
        title: '学分',
        dataIndex: 'SumCredit',

      },
      {
        title: '参训名额限定',
        dataIndex: 'QtyLimit',

      },
      {
        title: '开课截至时间',
        dataIndex: 'EndDate',

      },
      {
        title: '开课状态',
        dataIndex: 'CourseSTName',

      },
      {
        title: '发布时间',
        dataIndex: 'UDate',

      },
      {
        title: '操作',
        dataIndex: 'Operation',
        render: (text, record, index) => (
          (
            <div className="btn-group">
              <Button type="primary" onClick={() => this.searchDetail(record)}>查看详情</Button>
              <Button type="primary" style={{marginLeft: "0.5rem"}}
                      onClick={() => this.offerCourse(record)} disabled={record.IsOverdue||(record.CourseST!==1&&record.CourseST!==4)}>
                {
                  record.CourseST==4?"编辑课程":(record.IsOverdue?"已截止":"开设课程")
                }
              </Button>
            </div>
          )
        )
      }
    ]
  }

  componentDidMount() {
    this.setState({
      loading: true
    })
//获取开课状态
    Api.TrainingPlan.GetCourseSTList({token}).then(res => {
      if (res.Ret === 0) {
        this.setState({
          CourseState: res.Data,
        })
      }
    });
    //默认获取分页数据
    this.getPageData()
  }

  //获取分页数据
  getPageData() {
    const {pageSize, current} = this.state.pagination;
    let NewViewModelList = [];
    Api.TrainingPlan.GetProfessionalPlanPage(this.state.queryFields, current, pageSize, token).then(res => {
      if (res.Ret === 0) {
        if(res.Data){
          const pagination = {...this.state.pagination};
          pagination.total = res.Data.TotalRecords;
          pagination.current = res.Data.PageIndex;
          //处理数据
          res.Data.ViewModelList.forEach((item, index) => {
            let obj = {
              ID: item.ID,
              Name: item.Name,
              CourseST:item.CourseST,
              DestPeople: item.DestPeople,
              CourseID:item.CourseID,
              QtyLecturer: item.QtyLecturer+"人",
              SumCredit: item.SumCredit,
              QtyLimit: item.QtyLimit,
              EndDate: item.EndDate,
              CourseSTName: item.CourseSTName,
              UDate: item.UDate,
              AreaID: item.AreaID,
              TrainSDate: item.TrainSDate,
              TrainEDate: item.TrainEDate,
              index: index + 1,
              IsOverdue:item.IsOverdue
            }
            NewViewModelList.push(obj)
          })
          this.setState({
            dataSource: Object.assign({}, this.state.dataSource, {
              ViewModelList: NewViewModelList
            }),
            pagination,
            loading: false
          })
        }else{
          this.setState({dataSource:"", loading:false})
        }
      }else{
        message.warn(res.Msg)
        this.setState({
          loading:false
        })
      }
    })
  }

//分页改变时触发
  onChangePage(pagination, filters, sorter) {

    const pager = {...this.state.pagination};
    pager.current = pagination.current;
    this.setState({pagination: pager, loading: true}, () => this.getPageData(pager.current));
  }

//查询
  handleSearch = (e) => {
    this.setState({loading: true})
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
      this.setState({
        queryFields: Object.assign({}, this.state.queryFields, {
          ST: values.CoureseState||0,
          name: values.Keyword || "",
          sDate: moment(values.TrainSEDate[0]).format(dateFormat),
          eDate: moment(values.TrainSEDate[1]).format(dateFormat),
        }),
        pagination:Object.assign({},this.state.pagination,{
          current:1
        })
      }, () => this.getPageData(this.state.queryFields))
    });
  }

//查看详情
  searchDetail(record) {
    this.setState({
      visible: true,
      IsOverdue:record.IsOverdue
    });
    const data = {
      planID: record.ID,
    }
    Api.TrainingPlan.GetProfessionalPlanByID(data, token).then(res => {
      if (res.Ret === 0) {
        this.setState({
          DetailData: res.Data
        })
      }
    });
  }
  //处理培训范围
  handleRangList(RangList) {
    if (!RangList) return;
    let nameList = [];
    RangList.forEach(item => {
      nameList.push(item.GName?item.GName:item.AreaName)
    })
    return nameList.join(",")
  }

  //处理适用对象
  handleDestPeople(peopleLlist){
    let newPeople = [];
    if(peopleLlist){
      peopleLlist.map(item=>{
        if(item.IsCheck)
          newPeople.push(item.Name)
      })
    }
    return newPeople.join('、')
  }

  //处理授课讲师
  handleTeacher(LecturerList) {
    if (!LecturerList) return;
    let nameList = [];
    LecturerList.forEach(item => {
      nameList.push(item.Name)
    })
    return nameList.join(",")

  }

//取消显示模态框
  handleCancel() {
    this.setState({
      visible: false
    })
  }

  //开设课程
  offerCourse(record) {
    this.props.history.push({
      pathname: `/start-courses`, state: {
        offerCourse: {
          step: 0,
          trainPlanID: record.ID,
          courseID:record.CourseID,
          origin: this.props.location.pathname
        }

      }
    })
  }

  render() {
    const {CourseState, DetailData} = this.state;
    const {sDate, eDate} = this.state.queryFields
    let SearchSEDate = [moment(sDate), moment(eDate)];
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {span: 8},
      wrapperCol: {span: 16},
    };
    const width = 2//模态框行宽
    return (
      <div className="training-plan">
        <Form layout="inline" className="form-search-group" onSubmit={this.handleSearch}>
          <FormItem {...formItemLayout} label={'开课状态'}>
            {getFieldDecorator(`CoureseState`,{initialValue: "0"})(
              <Select
                style={{width: 150}}
                optionFilterProp="children"
                onChange={() => {
                }}
                filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                <Option value="0" key={0}>全部</Option>
                {
                  CourseState && CourseState.length && CourseState.map((item, key) => {
                    return (
                      <Option value={item.Value} key={key}>{item.Text}</Option>
                    )
                  })
                }
              </Select>
            )}
          </FormItem>

          <FormItem {...formItemLayout} style={{marginLeft: "2.2rem"}} label="培训名称">
            {getFieldDecorator(`Keyword`)(
              <Input placeholder="请输入培训名称"/>
            )}

          </FormItem>

          <FormItem {...formItemLayout} label="开课截止日期">
            {getFieldDecorator(`TrainSEDate`, {initialValue: SearchSEDate})(<RangePicker format={dateFormat}/>)}
          </FormItem>
          <FormItem>
            <Button type="primary" style={{marginLeft: 8}} htmlType="submit">查询</Button>
          </FormItem>
          <Table rowKey="ID" bordered columns={this.columns}
                 style={{marginTop: "0.5rem"}}
                 loading={this.state.loading}
                 pagination={this.state.pagination}
                 dataSource={this.state.dataSource.ViewModelList}
                 onChange={(pagination, filters, sorter) => {
                   this.onChangePage(pagination, filters, sorter)
                 }}
          />
        </Form>
        <Modal
          className="searchDetail"
          width="50%"
          visible={this.state.visible}
          title="查看详情"
          onOk={this.handleOk}
          onCancel={() => this.handleCancel()}
          footer={[
            <Button key="submit" disabled={this.state.IsOverdue} type="primary" size="large" onClick={() => this.offerCourse(DetailData)}>
              开设课程
            </Button>
          ]}
        >
          <Row>
            <Col span={width}/>
            <Col span={2}>
              培训名称:
            </Col>
            <Col span={20}>
              {DetailData.Name}
            </Col>
          </Row>
          <Row>
            <Col span={width}/>
            <Col span={2}>
              培训对象:
            </Col>
            <Col span={20}>
              {this.handleDestPeople(DetailData.DestPeople)}
            </Col>
          </Row>
          <Row>
            <Col span={width}/>
            <Col span={2}>
              培训内容:
            </Col>
            <Col span={20}>
              {DetailData.Cnt}
            </Col>
          </Row>
          <Row>
            <Col span={width}/>
            <Col span={2}>
              区域指派情况:
            </Col>
            <Col span={20}>
              {this.handleRangList(DetailData.RangeIndcatorList)}
            </Col>
          </Row>
          <Row>
            <Col span={width}/>
            <Col span={2}>
              学校指派情况:
            </Col>
            <Col span={20}>
              {this.handleRangList(DetailData.RangList)}
            </Col>
          </Row>
          <Row>
            <Col span={width}/>
            <Col span={2}>
              授课讲师：
            </Col>
            <Col span={20}>
              {this.handleTeacher(DetailData.LecturerList)}
            </Col>
          </Row>

          <Row>
            <Col span={width}/>
            <Col span={2}>
              培训总学分:
            </Col>
            <Col span={20}>
              {DetailData.SumCredit}
            </Col>
          </Row>

          <Row>
            <Col span={width}/>
            <Col span={3}>
              课程提交截至时间:
            </Col>
            <Col span={18}>
              {DetailData.EndDate}
            </Col>
          </Row>

          <Row>
            <Col span={width}/>
            <Col span={2}>
              附件：
            </Col>
            <Col span={20}>
              <a href={DetailData.AttachUrl} target="_Blank">{DetailData.AttachName}</a>
            </Col>
          </Row>

          <Row>
            <Col span={width}/>
            <Col span={2}>
              发布时间：
            </Col>
            <Col span={10}>
              {DetailData.UDate}
            </Col>
          </Row>
        </Modal>
      </div>

    )
  }
}

export default withRouter(Form.create()(TrainingPlan));
