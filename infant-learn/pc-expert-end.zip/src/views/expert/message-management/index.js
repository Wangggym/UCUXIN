/**
 * Created by xj on 2017/8/31.
 */
import React, {Component} from "react";
import {withRouter} from 'react-router-dom';
import {Form, Input, Button, Select, DatePicker, Table, message, Modal, Row, Col} from 'antd';
import DetailsModal from '../my-course/DetailsModal';


import {Token} from "../../../utils";
import Api from '../../../api';
import "../training-plan/training-plan.scss";

const token = Token();
const FormItem = Form.Item;
const Option = Select.Option;
const Search = Input.Search;
const {RangePicker} = DatePicker;

class MessageManagement extends Component {
  constructor(props) {
    super(props)
    this.state = {
      modalText: false,//文本弹框
      modalPlan: false,//培训计划弹框
      modalCourse: false,//课程弹框
      loading: false,
      messageType: [],
      TextDetailData: {},//文本详情数据
      PlanDetailData: {},//培训计划详情数据
      CourseDetailData: {},//课程详情数据
      pagination: {pageSize: 10, current: 1},
      queryFields: {
        messageType: 0,//消息类型
        IsRead: false,//阅读状态
        cnt: "",//内容关键字
      },
      dataSource: {},
    }

    this.columns = [
      {
        title: '内容',
        dataIndex: 'Cnt',

      },
      {
        title: '时间',
        dataIndex: 'CDate',

      },
      {
        title: '消息类型',
        dataIndex: 'MessageTypeDesc',

      },
      {
        title: '状态',
        dataIndex: 'IsRead',

      },
      {
        title: '操作',
        dataIndex: 'Operation',
        render: (text, record, index) => (
          (
            <div className="btn-group">
              <Button type="primary" onClick={() => this.searchDetail(record)}>查看</Button>
              <Button type="primary" style={{marginLeft: "0.5rem"}} onClick={() => this.delCurrent(record)}>删除</Button>
            </div>
          )
        )
      }
    ]
  }

  componentDidMount() {
    this.setState({
      loading: true
    })
    //获取消息类型
    Api.MessageManagement.GetMessageTypeList({token}).then(res => {
      if (res.Ret === 0) {
        this.setState({
          messageType: res.Data
        })
      }
    });
    //默认获取分页数据
    this.getPageData()
  }

  //获取分页数据
  getPageData() {
    const {pageSize, current} = this.state.pagination;
    let NewViewModelList = [];
    Api.MessageManagement.GetMessageList(this.state.queryFields, current, pageSize, token).then(res => {
      if (res.Ret === 0) {
        if (res.Data) {
          const pagination = {...this.state.pagination};
          pagination.total = res.Data.TotalRecords;
          pagination.current = res.Data.PageIndex;
          //处理数据
          res.Data.ViewModelList.forEach((item, index) => {
            let obj = {
              ID: item.ID,
              MessageType: item.MessageType,
              MessageTypeDesc: item.MessageTypeDesc,
              Cnt: item.Cnt,
              CDate: item.CDate,
              IsRead: item.IsRead ? "已读" : "未读",
              IsReadState: item.IsRead,
              RID: item.RID,
            }
            NewViewModelList.push(obj)
          })
          this.setState({
            dataSource: Object.assign({}, this.state.dataSource, {
              ViewModelList: NewViewModelList
            }),
            pagination,
            loading: false
          })
        } else {
          setTimeout(() => this.setState({loading: false}), 10000)
        }

      }
    })
  }

  //分页改变时触发
  onChangePage(pagination, filters, sorter) {
    const pager = {...this.state.pagination};
    pager.current = pagination.current;
    this.setState({pagination: pager, loading: true}, () => this.getPageData(pager.current));
  }

//查询
  handleSearch = (e) => {
    this.setState({loading: true})
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
      this.setState({
        queryFields: Object.assign({}, this.state.queryFields, {
          messageType: values.MessageType || 0,
          IsRead: values.ReadState,
          cnt: values.Name || ""
        }),
        pagination: Object.assign({}, this.state.pagination, {
          current: 1
        })
      }, () => this.getPageData(this.state.queryFields))
    });
  }

  //查看
  searchDetail(record) {
    let data = {
      MessageID: record.ID,
      token
    };

    this.getTextDetail(data)
  }

  //获取文本详情数据(三个类型都会调用此接口，用于修改阅读状态，获取文本数据的时候不用再调取另外的接口，另外两种需要再调取另外的接口)
  //此处后台接口要求文本类型不用再调取接口
  getTextDetail = (data) => {
    Api.MessageManagement.GetMessageDetailByID(data).then(res => {
      if (res.Ret === 0) {
        //重新获取分页列表数据（改变阅读状态显示）
        this.getPageData();
        this.setState({
          TextDetailData: res.Data
        }, () => this.getDetail(this.state.TextDetailData))
      }
    })
  };
  //根据类型获取详情
  getDetail = (DetailData) => {
    switch (DetailData.MessageType) {  // 1-文本消息 2-培训计划 3-课程通知
      case 1:
        this.setState({modalText: true});
        break;
      case 2:
        this.getPlanDetail(DetailData.RID);
        break;
      case 3:
        this.getCourseDetail(DetailData.RID)
        break;
    }
  };
  //获取培训计划详情数据
  getPlanDetail = (RID) => {
    const data = {
      planID: RID,
    };
    Api.TrainingPlan.GetProfessionalPlanByID(data, token).then(res => {
      if (res.Ret === 0) {
        this.setState({
          PlanDetailData: res.Data
        }, () => this.setState({modalPlan: true}))
      }
    })
  };
  //获取课程详情数据
  getCourseDetail = (RID) => {
    const data = {
      courseID: RID,
      token
    };
    Api.MessageManagement.messageGetCourseByID(data).then(res => {
      if (res.Ret === 0) {
        this.setState({
          CourseDetailData: res.Data,
          courseID:RID
        }, () => this.setState({modalCourse: true}))
      }
    })
  };

  //处理适用对象
  handleDestPeople(peopleLlist) {
    let newPeople = [];
    if (peopleLlist) {
      peopleLlist.map(item => {
        if (item.IsCheck)
          newPeople.push(item.Name)
      })
    }
    return newPeople.join('、')
  }

  //处理培训范围
  handleRangList(RangList) {
    if (!RangList) return;
    let nameList = [];
    RangList.forEach(item => {
      nameList.push(item.GName)
    })
    return nameList.join(",")
  }

//处理授课讲师
  handleTeacher(LecturerList) {
    if (!LecturerList) return;
    let nameList = [];
    LecturerList.forEach(item => {
      nameList.push(item.Name)
    })
    return nameList.join(",")

  }

  //删除
  delCurrent(record) {
    console.log(record)
    const {ViewModelList} = this.state.dataSource;
    let data = {
      MessageID: record.ID,
      token
    };
    Api.MessageManagement.DelMessageByID(data).then(res => {
      if (res.Ret === 0) {
        ViewModelList.forEach((item, index) => {
          if (item.ID === record.ID) {
            this.setState({
              dataSource: Object.assign({}, this.state.dataSource, {
                ViewModelList: [
                  ...ViewModelList.slice(0, index),
                  ...ViewModelList.slice(index + 1)
                ]
              })
            }, () => message.info("删除成功"))
          }
        })
      }
    })
  }

  //取消文本显示模态框
  handleCancelText() {
    this.setState({
      modalText: false
    })
  }
  //取消培训计划模态
  handlePlanCancel=()=>{
    this.setState({
      modalPlan:false
    })
  }

//开设课程
  offerCourse(record) {
    this.props.history.push({
      pathname: `/start-courses`, state: {
        offerCourse: {
          step: 0,
          trainPlanID: record.ID,
          courseID: record.CourseID,
          origin: this.props.location.pathname
        }

      }
    })
  }

  render() {
    const {messageType, modalText, modalPlan, modalCourse, TextDetailData, PlanDetailData, CourseDetailData} = this.state;
    const {getFieldDecorator} = this.props.form;
    const formItemLayout = {
      labelCol: {span: 8},
      wrapperCol: {span: 16},
    };
    let width = 2;
    return (
      <div className="message-management">
        <Form layout="inline" className="form-search-group" onSubmit={this.handleSearch}>
          <FormItem {...formItemLayout} label={'消息类型'}>
            {getFieldDecorator(`MessageType`)(
              <Select
                style={{width: 150}}
                placeholder="消息类型"
                optionFilterProp="children"
                onChange={() => {
                }}
                filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                {
                  messageType.map((item, key) => {
                    return (
                      <Option value={item.Value} key={key}>{item.Text}</Option>
                    )
                  })
                }
              </Select>
            )}
          </FormItem>

          <FormItem {...formItemLayout} label={'阅读状态'}>
            {getFieldDecorator(`ReadState`, {initialValue: "false"})(
              <Select
                style={{width: 150}}
                placeholder="阅读状态"
                optionFilterProp="children"
                onChange={() => {
                }}
                filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
              >
                <Option value={"true"}>已读</Option>
                <Option value={"false"}>未读</Option>

              </Select>
            )}
          </FormItem>

          <FormItem style={{marginLeft: "2.2rem"}} label="名称">
            {getFieldDecorator(`Name`)(
              <Input placeholder="请输入名称"/>
            )}
          </FormItem>
          <FormItem>
            <Button type="primary" style={{marginLeft: 8}} htmlType="submit">查询</Button>
          </FormItem>

          <Table rowKey="ID" bordered columns={this.columns}
                 style={{marginTop: "0.5rem"}}
                 loading={this.state.loading}
                 pagination={this.state.pagination}
                 dataSource={this.state.dataSource.ViewModelList}
                 onChange={(pagination, filters, sorter) => {
                   this.onChangePage(pagination, filters, sorter)
                 }}
          />
          {/*文本消息弹框*/}
          <Modal
            className="searchDetail"
            width="50%"
            visible={modalText}
            title="查看详情"
            onOk={this.handleOk}
            onCancel={() => this.handleCancelText()}
            footer={[
              <Button key="submit" size="large" onClick={() => this.handleCancelText()}>
                取消
              </Button>
            ]}
          >
            <Row>
              <Col span={width}/>
              <Col span={2}>
                接收人名称:
              </Col>
              <Col span={20}>
                {TextDetailData.Rname}
              </Col>
            </Row>

            <Row>
              <Col span={width}/>
              <Col span={2}>
                内容:
              </Col>
              <Col span={20}>
                {TextDetailData.Cnt}
              </Col>
            </Row>
            <Row>
              <Col span={width}/>
              <Col span={2}>
                消息类型 :
              </Col>
              <Col span={20}>
                {TextDetailData.MessageTypeDesc}
              </Col>
            </Row>
            <Row>
              <Col span={width}/>
              <Col span={2}>
                创建日期:
              </Col>
              <Col span={20}>
                {TextDetailData.CDate}
              </Col>
            </Row>

          </Modal>
          {/*培训计划弹框*/}
          <Modal
            className="searchDetail"
            width="50%"
            visible={modalPlan}
            title="查看详情"
            onOk={this.handleOk}
            onCancel={() => this.handlePlanCancel()}
            footer={null}
          >
            <Row>
              <Col span={width}/>
              <Col span={2}>
                培训名称:
              </Col>
              <Col span={20}>
                {PlanDetailData.Name}
              </Col>
            </Row>
            <Row>
              <Col span={width}/>
              <Col span={2}>
                培训对象:
              </Col>
              <Col span={20}>
                {this.handleDestPeople(PlanDetailData.DestPeople)}
              </Col>
            </Row>
            <Row>
              <Col span={width}/>
              <Col span={2}>
                培训内容:
              </Col>
              <Col span={20}>
                {PlanDetailData.Cnt}
              </Col>
            </Row>
            <Row>
              <Col span={width}/>
              <Col span={2}>
                培训范围:
              </Col>
              <Col span={20}>
                {this.handleRangList(PlanDetailData.RangList)}
              </Col>
            </Row>
            <Row>
              <Col span={width}/>
              <Col span={2}>
                授课讲师：
              </Col>
              <Col span={20}>
                {this.handleTeacher(PlanDetailData.LecturerList)}
              </Col>
            </Row>

            <Row>
              <Col span={width}/>
              <Col span={2}>
                培训总学分:
              </Col>
              <Col span={20}>
                {PlanDetailData.SumCredit}
              </Col>
            </Row>

            <Row>
              <Col span={width}/>
              <Col span={3}>
                课程提交截至时间:
              </Col>
              <Col span={18}>
                {PlanDetailData.EndDate}
              </Col>
            </Row>

            <Row>
              <Col span={width}/>
              <Col span={2}>
                附件：
              </Col>
              <Col span={20}>
                <a href={PlanDetailData.AttachUrl} target="_Blank">{PlanDetailData.AttachName}</a>
              </Col>
            </Row>

            <Row>
              <Col span={width}/>
              <Col span={2}>
                发布时间：
              </Col>
              <Col span={10}>
                {PlanDetailData.UDate}
              </Col>
            </Row>
          </Modal>
          {/*课程通知弹框 */}
          {
            this.state.courseID&&<DetailsModal courseID={this.state.courseID}  onOff={modalCourse} changeOnOff={(modalCourse) => this.setState({modalCourse})}/>
          }
        </Form>
      </div>
    )
  }
}

export default withRouter(Form.create()(MessageManagement));

