

import ServiceAsync from './service';
import { Token } from '../utils';
export default {
    // 我的课程列表
    getMyCoursePage: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyCoursePage', { token: Token(), ...data }),
    // 根据ID获取课程详情
    getLecturerByID: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetCourseByID', { token: Token(), ...data }),
    // 删除我的课程
    getCourseByID: (data) => ServiceAsync('POST', 'YouLS/v3/CourseWeb/DelMyCourseByID', { token: Token(), ...data }),


    //评论管理=====================
    // 专家端》我的课程 学习课程详情信息
    getMyCourseStudyInfo: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyCourseStudyInfo', { token: Token(), ...data }),
    
    // 专家端》我的课程 我的评论
    getMyStudyDiscussInfoPage: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyStudyDiscussInfoPage', { token: Token(), ...data }),
    // 新增评论
    addDiscussInfo: (data) => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddDiscussInfo', { token: Token(), ...data }),



    //学习管理
    // 专家端》我的课程 学习课程信息列表
    getMyStudyInfoPage: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyStudyInfoPage', { token: Token(), ...data }),
    // 专家端》我的课程 学习该课程详情
    getMyStudyDetail: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyStudyDetail', { token: Token(), ...data }),
}