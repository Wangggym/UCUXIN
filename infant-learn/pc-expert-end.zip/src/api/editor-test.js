import ServiceAsync from './service';
import { Token } from '../utils';
export default {
    // 授课方式
    getTeachWayList: (data) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetTeachWayList', { token: Token(), ...data }),
    // 新增试卷
    addResourceByPaper: (data) => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByPaper', { token: Token(), ...data }),
  //根据查询条件获取题目列表的接口
  GetMyQuestions: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyQuestionsNew', {...data}),
}
