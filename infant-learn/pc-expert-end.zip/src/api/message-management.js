import ServiceAsync from './service';

export default {
  //获取开课状态
  GetMessageTypeList: (token) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetMessageTypeList', token),

  //专家端--获取消息列表
  GetMessageList: (data, pIndex, pSize, token) => ServiceAsync('GET', 'YouLS/v3/MessageWeb/GetPageByCondition',
    {...data, pIndex, pSize, token}),

  //删除消息
  DelMessageByID: (data) => ServiceAsync('POST', 'YouLS/v3/MessageWeb/DelMessageByID', {...data}),//token已加

  //专家端--根据ID获取消息详情
  GetMessageDetailByID: (data) => ServiceAsync('GET', 'YouLS/v3/MessageWeb/GetMessageDetailByID', {...data}),//token已加
//根据ID获取课程详情--区域课程管理
  messageGetCourseByID: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetCourseByID', {...data}),//token已加

}
