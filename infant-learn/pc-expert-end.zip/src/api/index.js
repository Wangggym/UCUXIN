/**
 * Created by QiHan Wang on 2017/8/15.
 * index
 */
import Base from './base';
import Basics from './basics' //公共接口 枚举接口
import MyHomepage from './my-homepage'
import MyCourse from './my-course'
import StartCourses from './start-courses';
import Resource from './resource'                 // 资源模块， 试题 试卷
import TrainingPlan from './training-plan';
import MessageManagement from './message-management';
import EditorTest from './editor-test'

export default {
  Base,
  MyHomepage,
  Basics,
  MyCourse,
  StartCourses,
  TrainingPlan,
  MessageManagement,
  EditorTest,
  Resource
}
