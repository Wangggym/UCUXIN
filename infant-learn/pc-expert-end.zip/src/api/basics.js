import ServiceAsync from './service';

export default {
    // 授课方式
    getTeachWayList: (data) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetTeachWayList', data),
}