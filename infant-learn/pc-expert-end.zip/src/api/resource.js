/**
 * Created by QiHan Wang on 2017/8/30.
 * start-courses
 */
import ServiceAsync from './service';

export default {
  // 新增选择题
  addChoiceQuestion: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByChoice', data),

  // 新增判断题
  addJudgeQuestion: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByJudge', data),
  // 新增题
  addQuestion: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByQuestion', data),
  // 获取题难易
  getDifficulty: (data) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetDifficultyList', data),
  // 获取题类型
  getQuestionType: (data) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetQuestionTypeList', data),
  //获取我的资源列表(带引用量)
  GetMyResourceInfoByType: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyResourceInfoByType', data),
  //获取我的资源列表(带引用量)的详情
  GetMyResourceDetail: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyResourceDetail', data),
//获取试卷列表
  GetYLSPapersByQuery: (data) => ServiceAsync('GET', 'YouLS/v3/PaperWeb/GetYLSPapersByQuery', data),
  //根据试卷获取题目的接口（有答案）
  GetPaperByPaperIDNew: (data) => ServiceAsync('GET', 'YouLS/v3/PaperWeb/GetPaperByPaperIDNew', data),
//查看试题详情
  GetQuestionDetailByIDNew: (data) => ServiceAsync('POST', 'Resource/v3/QuePap/GetQuestionDetailByIDNew', data),

}
