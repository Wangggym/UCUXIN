import ServiceAsync from './service';

export default {
  //获取开课状态
  GetCourseSTList: (token) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetCourseStartSTList',token),
  //专家端--获取培训计划分页
  GetProfessionalPlanPage: (data, pIndex, pSize,token) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetProfessionalPlanPage',
    {...data, pIndex, pSize,token}),
  //专家端--根据培训计划获取培训详情
  GetProfessionalPlanByID: (data,token) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetProfessionalPlanByID',{...data,token}),

}
