/**
 * Created by QiHan Wang on 2017/8/30.
 * start-courses
 */
import ServiceAsync from './service';

export default {
  // 授课方式
  getTeachWayList: (data) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetTeachWayList', data),

  // 课程类型
  getCourseTypeList: data => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetCourseTypeListByUID', data),

  // 适用对角
  getDestPeopleList: data => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetDestPeopleList', data),
  getCrowd: data => ServiceAsync('GET', 'sns/v3/Web/GetBusinessMemberRoles', data),

  // 根据ID获取计划信息 --用于开课
  getPlanSimple: data=> ServiceAsync('GET', 'YouLS/v3/TrainPlanWeb/GetPlanSimpleByID', data),

  // 获取讲师基本信息
  getLecturerInfo: data => ServiceAsync('GET', 'YouLS/v3/LecturerWeb/GetLecturerHomeInfo', data),

  // 获取课程详情--基本信息---编辑课程
  getCourseBaseInfo: data => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetCourseDetailByCourseID', data),

  // 获取我的相关资源（我的文件、我的视频、我的试卷、我的试题）
  getMyResource: data=> ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetMyResourceByType', data),

  // 根据ID获取课程详情
  getCourse: data => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetCourseByID', data),

  // 获取区域 省市县
  getAreaList: data => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetRegion', data),

  // 获取视频上传认证信息
  getVideoToken: data=> ServiceAsync('GET', 'Resource/v3/Video/GetTokenSign', data),

  // 创建课程信息
  saveCourseInfo: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddOrUpdateCourse', data),

  // 新增修改课程目录
  saveCourseCatalog: data=>ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddOrUpdateCourseCatalog', data),
  updateCourseAlbum: data=>ServiceAsync('POST', 'YouLS/v3/CourseWeb/UpdateCourseAlbum', data),

  // 删除课程目录
  delCourseCatalog: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/DeleteCourseCatalog', data),


  // 向录播课程目录中添加内容（文件、视频、试卷、试题需要与资源平台对接，
  // 直播和线下面授资源没有
  // 资源中心添加资源，获取到resourceID后再调用此接口）
  // 调用资源中心接口说明：新增文件需要返回：名称、大小；
  // 新增视频需要返回：名称、时长；试卷需要返回：名称、题目数
  //saveCourseResourceFile: data => ServiceAsync('GET', 'YouLS/v3/CourseWeb/AddResourceByFile', data)

  // 选择我的资源添加到课程目录下
  saveCatalogResource: data => ServiceAsync('POST','YouLS/v3/CourseWeb/AddResourceByMyResource', data),

  // 删除目录下的资源
  delCatalogCourse: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/DeleteCourseResource', data),

  // 新增课程对应的试卷
  saveCoursePaper: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddOrUpdateCoursePaper', data),

  // 新增直播课程
  saveResourceLive: data => ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByOnLive', data),

  // 新增线下面授
  saveResourceFace: data=> ServiceAsync('POST','YouLS/v3/CourseWeb/AddResourceByOffLive', data),

  // 新增文件资源
  saveResourceFile: data=> ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByFile', data),

  // 新增视频资源
  saveResourceVideo: data=> ServiceAsync('POST', 'YouLS/v3/CourseWeb/AddResourceByVideo', data),

  // 修改课程后，将状态置为待审核
  updateCourseStatus: data=> ServiceAsync('POST', 'YouLS/v3/CourseWeb/FinishEditCourse', data),

  // 课程第二步点击下一步的时候用来检查课程下的资源是否符合要求
  validateCourse: data => ServiceAsync('GET', 'YouLS/v3/CourseWeb/CheckCourse', data),

}
