import ServiceAsync from './service';
import {Token} from '../utils';

export default {
  //获取主页讲师信息
  getLecturerHomeInfo: (data) => ServiceAsync('GET', 'YouLS/v3/LecturerWeb/GetLecturerHomeInfo', {token: Token(), ...data}),
  // 课程类型
  getCourseTypeList: (data) => ServiceAsync('GET', 'YouLS/v3/EnumWeb/GetCourseTypeList', {token: Token(), ...data}),
  // 根据讲课老师获取课程列表
  getPageByLecturerID: (data) => ServiceAsync('GET', 'YouLS/v3/CourseWeb/GetPageByLecturerID', {token: Token(), ...data}),
  // 更新讲师 简介 成就
  updateLecturerHomeInfo: (data) => ServiceAsync('POST', 'YouLS/v3/LecturerWeb/UpdateLecturerHomeInfo', {token: Token(), ...data}),


}
