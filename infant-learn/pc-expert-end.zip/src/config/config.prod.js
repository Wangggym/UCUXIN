/**
 * Created by QiHan Wang on 2017/5/27.
 * 用于生产环境下环境常量
 */
export const ConfigProd = {
  api: 'http://api.ucuxin.com/',
  appAddress: 'http://m.ucuxin.com',
  token: sessionStorage['Token'],
  appSecret: '7c198e9b76504ec889b6ba17de485bfe',
  ownerAddress: 'http://h.ucuxin.com/'
};


