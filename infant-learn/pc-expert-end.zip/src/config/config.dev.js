/**
 * Created by QiHan Wang on 2017/5/27.
 * 用于开发环境下环境常量
 */

export const ConfigDev = {
  api: 'http://api.test.ucuxin.com/',
  //api:'http://10.10.12.178:5284',
  // token: 'd423772b1bfb4defa0285969e331739a',// 王宇
  token: 'fd120a0b10c240b8a77c049567935be6',// 剔
  // token:'d56993aef139471f811293cf967086df',// 冉
  //token: 'f52afa0eb4634aa5af811971657e78a1', //麒
  //token: '711f202b4de1455e950658d7c0093fa5', //棋
  appSecret: '4a66e4e53bcd4c5e9e43241c711698ba', //1016
  //appSecret: 'dh12340238c04rtyb379t23a42ed535r', // 204

  appAddress: 'http://m.test.ucuxin.com',
  ownerAddress: 'http://h.test.ucuxin.com/'
};
