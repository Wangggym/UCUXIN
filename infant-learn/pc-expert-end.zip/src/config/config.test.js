/**
 * Created by QiHan Wang on 2017/5/27.
 * 用于生产环境下环境常量
 */
// Test
export const ConfigTest = {
  api: 'http://api.test.ucuxin.com/',
  appAddress: 'http://m.test.ucuxin.com',
  token: sessionStorage['Token'],
  appSecret: '4a66e4e53bcd4c5e9e43241c711698ba', // 1016
  ownerAddress: 'http://h.test.ucuxin.com/'
};

