# 江西禁毒知识竞赛
### react+ant-moblie+fetch+echarts
------

