/**
 * Created by QiHan Wang on 2017/9/12.
 * index
 */
import ali from './ali';
import qiniu from './qiniu';

export default {
  ali,
  qiniu
}
